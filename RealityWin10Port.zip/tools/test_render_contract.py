#!/usr/bin/env python3
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
data = (ROOT / 'ssyneng.rehost').read_bytes()
magic, ver, nobj, nfix = struct.unpack_from('<8sIII', data, 0)
assert magic.startswith(b'SSYNRH1') and ver == 1 and nobj >= 1
off = 20
sizes = []
for _ in range(nobj):
    size, = struct.unpack_from('<I', data, off)
    off += 4
    sizes.append(size)
obj1 = data[off:off + sizes[0]]

# The only direct original call to AA9B0 loads WORD [engine+14] for arg2.
assert obj1[0x96927:0x9692e] == bytes.fromhex('66 8b 4a 14 51 6a 00'), obj1[0x96927:0x9692e].hex()
assert obj1[0x9692e] == 0xE8
rel, = struct.unpack_from('<i', obj1, 0x9692f)
assert 0x96933 + rel == 0xAA9B0, hex(0x96933 + rel)

# AA9B0 reads arg2 as a loop bound and divides its total output byte span by it
# before advancing the destination pointer for the next slice.
assert obj1[0xAAA3B:0xAAA3E] == bytes.fromhex('8b 45 0c')
assert obj1[0xAAB09:0xAAB13] == bytes.fromhex('33 d2 8b 35 00 00 00 00 f7 f1')

host = (ROOT / 'src/engine/ssyneng_host.cpp').read_text()
cpu = (ROOT / 'src/engine/host_cpu_accounting.cpp').read_text()
seq = (ROOT / 'src/compat/seqplay_native.cpp').read_text()
assert 'ReadObjectU32(0x2090A)' in host
assert 'ResolveNativeCallbackBytes' in host and 'perSliceFrames' in host and 'engine + 0xA6u' in host
assert 'callbackSlices' in host and 'callbackBytes' in host and 'renderScratch_' in host
assert 'audioOp == 0x0Bu' in host and 'DeactivateModernAudio' in host
assert 'channel-diff' in host and 'channelDiffSeen_' in (ROOT / 'src/engine/ssyneng_host.h').read_text()
assert 'RenderWithHostCpuAccounting(renderScratch_, callbackSlices, callbackFrames' in host
assert '(buffer,callbackSlices)' in cpu
for token in ('8200', '8300', '8400', '8500', '8600', 'MirrorSequenceMessage', 'REALITY_SEQ_UI_MIRROR'):
    assert token in seq, f'missing UI mirror token {token}'
print('OK v13.2 AA9B0 native callback span + synchronized DirectSound handoff + opt-in UI mirror')
print('pack objects:', sizes, 'fixups:', nfix)
