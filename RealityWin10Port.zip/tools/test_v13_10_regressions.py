#!/usr/bin/env python3
"""v13.10: preserve v13.8 44-kHz pitch path while enabling the 22->44 bus fold."""
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
host = (ROOT / 'src/engine/ssyneng_host.cpp').read_text()
hdr = (ROOT / 'src/engine/ssyneng_host.h').read_text()
compat = (ROOT / 'src/compat/reality_compat.cpp').read_text()

assert ('CleanRehost-v13.10-split-rate-mixer-pitch-fix-20260913' in compat or
        'CleanRehost-v13.16-midi-input-engine-rate-guard-20260916' in compat or
        'CleanRehost-v13.17-midi-input-lifecycle-fix-20260916' in compat)
for tok in (
    'ConfigureModernRateMixerBridge',
    'const uint32_t selector = (rate == 44100u) ? 0u',
    'const uint32_t desiredCompare = (rate == 44100u) ? 0u : 44100u',
    'Ptr(1, 0x8D0A5)',
    'SSYNENG modern rate mixer bridge transportRate=',
    'ConfigureModernRateMixerBridge(rate, bits, channels, "IOCTL 7002 op=0A")',
):
    assert tok in (host + hdr), tok
assert 'PublishLegacyOutputFormat(rate, bits, channels, "IOCTL 7002 op=0A")' not in host

# The raw VxD image must still contain the original 8CD20 compare against 44100;
# the host changes only its immediate in the relocated copy at runtime.
b=(ROOT/'ssyneng.rehost').read_bytes()
magic,ver,n,nf=struct.unpack_from('<8sIII',b,0); assert magic==b'SSYNRH1\0' and ver==1
sizes=struct.unpack_from('<'+'I'*n,b,20); pos=20+4*n
obj1=b[pos:pos+sizes[0]]
assert obj1[0x8D09F:0x8D0A5] == bytes.fromhex('81 3d 55 00 00 00')
assert struct.unpack_from('<I',obj1,0x8D0A5)[0] == 44100
assert obj1[0x8D0A9:0x8D0AF] == bytes.fromhex('0f 85 b0 00 00 00')
print('OK v13.10 split output-rate selector / 22->44 fold compatibility bridge')
