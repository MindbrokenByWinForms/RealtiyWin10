#!/usr/bin/env python3
import argparse, pathlib, struct, csv, re
VMM={
0x0000:'Get_VMM_Version',0x0001:'Get_Cur_VM_Handle',0x0003:'Get_Sys_VM_Handle',0x000E:'Schedule_Global_Event',0x000F:'Schedule_VM_Event',
0x0025:'Create_Semaphore',0x0026:'Destroy_Semaphore',0x0027:'Wait_Semaphore',0x0028:'Signal_Semaphore',
0x0031:'Set_Execution_Focus',0x003A:'Call_When_Idle',0x003C:'Set_Global_Time_Out',0x003E:'Cancel_Time_Out',0x003F:'Get_System_Time',
0x0048:'Simulate_Far_Call',0x004D:'Simulate_Push',0x004F:'_HeapAllocate',0x0051:'_HeapFree',0x0052:'_HeapGetSize',
0x0053:'_PageAllocate',0x0055:'_PageFree',0x0056:'_PageLock',0x0057:'_PageUnLock',0x005A:'_GetFreePageCount',
0x0063:'_LinPageLock',0x0064:'_LinPageUnLock',0x0067:'_PageCheckLinRange',0x006E:'_SelectorMapFlat',0x0078:'_Allocate_LDT_Selector',0x0079:'_Free_LDT_Selector',
0x007A:'_BuildDescriptorDWORDs',0x007B:'_GetDescriptor',0x007C:'_SetDescriptor',0x0081:'Hook_VMM_Fault',
0x0082:'Begin_Nest_V86_Exec',0x0083:'Begin_Nest_Exec',0x0085:'Resume_Exec',0x0086:'End_Nest_Exec',0x008B:'Begin_Use_Locked_PM_Stack',0x008C:'End_Use_Locked_PM_Stack',0x008D:'Save_Client_State',0x008E:'Restore_Client_State',
0x009B:'List_Create',0x009C:'List_Destroy',0x009D:'List_Allocate',0x009E:'List_Attach',0x009F:'List_Attach_Tail',0x00C4:'VMM_legacy_00C4',
0x00A1:'List_Remove',0x00A2:'List_Deallocate',0x00A3:'List_Get_First',0x00A4:'List_Get_Next',
0x0104:'Call_When_Thread_Switched',0x0108:'Get_Cur_Thread_Handle',0x0112:'Cancel_Call_When_Thread_Switched',0x011B:'Unhook_VMM_Fault',
0x012B:'Cancel_Call_When_Idle',0x0131:'Signal_Semaphore_No_Switch',0x0144:'Get_System_Time_Address',
0x0148:'RegOpenKey',0x0149:'RegCloseKey',0x014A:'RegCreateKey',0x014B:'RegDeleteKey',
0x014C:'RegEnumKey',0x014D:'RegQueryValue',0x014E:'RegSetValue',0x014F:'RegDeleteValue',
0x0150:'RegEnumValue',0x0151:'RegQueryValueEx',0x0152:'RegSetValueEx',0x015A:'Call_Restricted_Event',
}

def wrapper_start(b, int_off, xrefs):
    # Prefer a direct-call target in the small wrapper body. This avoids merging
    # adjacent wrappers that do not have INT3 padding between them.
    candidates=[t for t in xrefs if int_off-0x40 <= t <= int_off]
    if candidates: return max(candidates)
    p=int_off-1
    while p>=0 and b[p] != 0xcc: p-=1
    return p+1

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('image'); ap.add_argument('--disasm'); ap.add_argument('-o',default='vmm_services.csv'); a=ap.parse_args()
 b=pathlib.Path(a.image).read_bytes(); xrefs={}
 if a.disasm:
  for line in pathlib.Path(a.disasm).read_text(errors='ignore').splitlines():
   m=re.search(r'^\s*([0-9a-f]+):.*\bcall\s+0x([0-9a-f]+)',line,re.I)
   if m: xrefs.setdefault(int(m.group(2),16),[]).append(int(m.group(1),16))
 rows=[]
 # Restrict to the known tail thunk area to avoid decoding DSP data/tables as opcodes.
 for off in range(max(0,0xB9600), min(len(b)-6,0xBA080)):
  if b[off:off+2] != b'\xCD\x20': continue
  sid=struct.unpack_from('<I',b,off+2)[0]; dev=sid>>16; svc=sid&0xffff
  base_svc=svc & 0x7fff
  name=VMM.get(base_svc,'') if dev==1 else ''
  ws=wrapper_start(b,off,xrefs)
  refs=xrefs.get(ws,[])
  rows.append((f'0x{ws:05X}',f'0x{off:05X}',f'0x{sid:08X}',f'0x{dev:04X}',f'0x{svc:04X}',f'0x{base_svc:04X}',name,len(refs),' '.join(f'0x{x:X}' for x in refs[:32])))
 with open(a.o,'w',newline='') as f:
  w=csv.writer(f); w.writerow(['wrapper_start','int20_offset','service_id','device_id','service_no','base_service_no','known_name','direct_xref_count','direct_xrefs']); w.writerows(rows)
 print(f'wrote {a.o}: {len(rows)} thunk/int20 sites')

if __name__=='__main__': main()
