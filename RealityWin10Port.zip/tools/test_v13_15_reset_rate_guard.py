from pathlib import Path

root = Path(__file__).resolve().parents[1]
cpp = (root / "src/engine/ssyneng_host.cpp").read_text()
hdr = (root / "src/engine/ssyneng_host.h").read_text()
compat = (root / "src/compat/reality_compat.cpp").read_text()

assert "EnsureModernRateMixerBridge(const char* reason)" in hdr
assert "void SsynengRehost::EnsureModernRateMixerBridge" in cpp
assert 'EnsureModernRateMixerBridge("render guard after legacy reset")' in cpp
assert '"post MIDI reset"' in cpp
assert '"post GM/GS reset"' in cpp
assert "expectedSelector = rate == 44100u ? 0u" in cpp
assert "expectedFold = rate == 44100u ? 0u : 44100u" in cpp
assert "current.sampleRateSelector != expectedSelector" in cpp
assert "current.bitsPerSample != bits" in cpp
assert "current.channels != channels" in cpp
assert "Analog mode4" not in cpp
assert "runtime cache bypass" not in cpp
assert ("CleanRehost-v13.16-midi-input-engine-rate-guard-20260916" in compat or
        "CleanRehost-v13.17-midi-input-lifecycle-fix-20260916" in compat)
print("v13.16 inherited reset/rate guard static checks: PASS")
