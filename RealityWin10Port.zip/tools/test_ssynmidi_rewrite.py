#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
native=(ROOT/'src/compat/native_midi.cpp').read_text(errors='ignore')
winmm=(ROOT/'src/compat/midi_winmm.cpp').read_text(errors='ignore')
defs=(ROOT/'src/ssynmidi32/SSYNMIDI32.def').read_text(errors='ignore')
evidence=json.loads((ROOT/'analysis/SSYNMIDI_DRV_EVIDENCE.json').read_text())
checks={
 'four_device_records':'std::array<DriverDeviceRecord,4>' in native,
 'cmd59_offsets':'Field<std::uint16_t>(b,0x5CC)' in native and 'Field<std::uint16_t>(b,0x5CE)' in native,
 'sendmessage_not_postmessage':'SendMessageA(hwnd, msg, wp, 0)' in native and 'PostMessageA(hwnd, msg, wp, 0)' not in native,
 'open_notification':'SendLegacyDriverNotification(midiId, 0x489)' in native,
 'close_notification':'SendLegacyDriverNotification(midiId, 0x48A)' in native,
 'shutdown_notification':'SendLegacyDriverNotification(id, 0x48B)' in native,
 'fast_midi_bit92':'0x10000000u' in native and 'Field<DWORD>(b,0x5D8)' in native,
 'long_running_status':'ForwardRecoveredLongStream' in native and 'running = status' in native,
 'gm_gs_reset':'IsGmOrGsResetNative' in native and 'NativeMidiReset(true)' in native,
 'winmm_single_state_machine':'NativeMidiOpenDevice(0, callback, instance, flags)' in winmm and 'NativeMidiCloseDevice(0)' in winmm and 'NativeMidiHandleLongData' in winmm,
 'standalone_export_ordinals':all(x in defs for x in ['@1','@2','@3','@4','@5','@6','@7','@100']),
 'reference_hash':evidence.get('sha256')=='1b238198d44195198daa4193814215bdca9dd970e89a9aec577672191bb3198d',
 'reference_user111':any(r.get('module')=='USER' and r.get('target_ordinal')==111 for r in evidence.get('user_call_relocation',[])),
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'} {k}")
if failed:
    print('FAILED:', ', '.join(failed)); sys.exit(1)
print('SSYNMIDI rewrite static checks passed')
