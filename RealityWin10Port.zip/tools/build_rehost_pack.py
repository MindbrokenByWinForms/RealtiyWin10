#!/usr/bin/env python3
"""Convert SSYNENG.VXD (LE/VxD) into a user-mode rehost pack.
The pack reconstructs LE objects and records simple internal 32-bit fixups.
It does NOT make the VxD safe to execute: VMM/VxD service thunks must be replaced first.
"""
import argparse, struct, pathlib

def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def rd(b,p,n):
    return int.from_bytes(b[p:p+n],'little'),p+n

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('vxd'); ap.add_argument('-o','--output',default='ssyneng.rehost')
    a=ap.parse_args(); b=bytearray(pathlib.Path(a.vxd).read_bytes())
    e=u32(b,0x3c)
    if b[e:e+2] != b'LE': raise SystemExit('not an LE executable')
    objtab=e+u32(b,e+0x40); objcnt=u32(b,e+0x44); fp=e+u32(b,e+0x68); fr=e+u32(b,e+0x6c)
    pages=u32(b,e+0x14); datap=u32(b,e+0x80); pagesz=u32(b,e+0x28); pm=e+u32(b,e+0x48)
    objs=[struct.unpack_from('<IIIIII',b,objtab+24*i) for i in range(objcnt)]
    images=[]; page_owner={}
    for oi,(vsize,base,flags,pindex,pcount,res) in enumerate(objs,1):
        img=bytearray(vsize)
        for j in range(pcount):
            global_page=pindex+j; page_owner[global_page]=(oi,j*pagesz)
            ent=b[pm+4*(global_page-1):pm+4*(global_page-1)+4]
            phys=(ent[0]<<16)|(ent[1]<<8)|ent[2]
            if phys:
                src=datap+(phys-1)*pagesz; n=min(pagesz,vsize-j*pagesz); img[j*pagesz:j*pagesz+n]=b[src:src+n]
        images.append(img)

    fix=[]
    for pg in range(1,pages+1):
        if pg not in page_owner: continue
        soi,pageoff=page_owner[pg]
        s=u32(b,fp+4*(pg-1)); en=u32(b,fp+4*pg); pos=fr+s; stop=fr+en
        while pos<stop:
            src=b[pos]; flags=b[pos+1]; pos+=2; listflag=bool(src&0x20); st=src&0x0f
            if listflag: cnt=b[pos]; pos+=1; srcoffs=[]
            else: sr=struct.unpack_from('<h',b,pos)[0]; pos+=2; srcoffs=[sr]; cnt=1
            tt=flags&3; width_obj=2 if flags&0x40 else 1; tobj=None; targ=None
            if tt==0:
                tobj,pos=rd(b,pos,width_obj)
                if st!=2: targ,pos=rd(b,pos,4 if flags&0x10 else 2)
            elif tt==1:
                _,pos=rd(b,pos,width_obj); _,pos=rd(b,pos,1 if flags&0x80 else (4 if flags&0x10 else 2))
            elif tt==2:
                _,pos=rd(b,pos,width_obj); _,pos=rd(b,pos,4 if flags&0x10 else 2)
            elif tt==3: _,pos=rd(b,pos,width_obj)
            add=0
            if flags&0x04: add,pos=rd(b,pos,4 if flags&0x20 else 2)
            if listflag:
                for _ in range(cnt): sr=struct.unpack_from('<h',b,pos)[0]; pos+=2; srcoffs.append(sr)
            if tt!=0 or tobj is None or targ is None: continue
            if flags&0x08:
                # LE source chain. Expand it into ordinary absolute fixups.
                sr=srcoffs[0]; loc=pageoff+sr; raw=struct.unpack_from('<I',images[soi-1],loc)[0]
                first_delta=raw>>12; base_target=targ+add-first_delta; cur=sr; seen=set()
                while True:
                    loc=pageoff+cur
                    if loc in seen or loc<0 or loc+4>len(images[soi-1]): break
                    seen.add(loc); raw=struct.unpack_from('<I',images[soi-1],loc)[0]
                    nxt=raw&0xfff; delta=raw>>12
                    fix.append((soi,tobj,7,loc,base_target+delta))
                    if nxt==0xfff: break
                    cur=nxt
            elif st in (7,8):
                for sr in srcoffs:
                    loc=pageoff+sr
                    if 0<=loc<=len(images[soi-1])-4: fix.append((soi,tobj,st,loc,targ+add))
            # 16-bit selector/offset fixups are deliberately excluded from executable rehost v1.
        if pos!=stop: raise RuntimeError(f'fixup parse overrun page {pg}')

    # LE uses unsigned fields even when the relocated x86 displacement is intentionally
    # just before object base. Normalize the value to signed int32 for the rehost pack.
    norm=[]
    for so,to,k,off,targ in fix:
        targ &= 0xffffffff
        signed_targ = targ if targ < 0x80000000 else targ - 0x100000000
        if to < 1 or to > len(images):
            raise RuntimeError(f'bad target object {to}')
        # SSYNENG legitimately uses base-4/-8/-12/-16 in indexed DSP addressing.
        if signed_targ < -64 or signed_targ >= len(images[to-1]):
            raise RuntimeError(f'fixup target outside guarded object: obj {to} off {signed_targ}')
        norm.append((so,to,k,off,signed_targ))

    out=pathlib.Path(a.output)
    with out.open('wb') as f:
        f.write(struct.pack('<8sIII',b'SSYNRH1\0',1,len(images),len(norm)))
        for img in images: f.write(struct.pack('<I',len(img)))
        for img in images: f.write(img)
        for so,to,k,off,targ in norm: f.write(struct.pack('<BBBBIi',so,to,k,0,off,targ))
    neg=sum(1 for x in norm if x[4] < 0)
    print(f'wrote {out}: {len(images)} objects, {len(norm)} executable fixups ({neg} guarded negative targets)')

if __name__=='__main__': main()
