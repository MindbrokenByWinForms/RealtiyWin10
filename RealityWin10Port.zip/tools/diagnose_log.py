#!/usr/bin/env python3
from pathlib import Path
import re, sys

p = Path(sys.argv[1] if len(sys.argv) > 1 else 'RealityCompat.log')
if not p.exists():
    print(f'ERROR: log not found: {p}')
    raise SystemExit(2)
all_text = p.read_text(errors='replace')

# RealityCompat.log is append-only. Diagnose only the newest process so stale
# missing-DLL launches and AVs do not contaminate the current result.
starts = list(re.finditer(
    r'^--- RealityCompat .*?\nRealityCompat build=.*?\nRealityCompat synchronous initialize, pid=\d+',
    all_text, re.I | re.M))
text = all_text[starts[-1].start():] if starts else all_text

required = [
    ('clean build loaded', r'CleanRehost-v13-ssynmidi-driver-rewrite|CleanRehost-v12-aa9b0-contract-ui-mirror|CleanRehost-v11-host-cpu-accounting|CleanRehost-v10-allocator-branch-trace|CleanRehost-v9-voice-pcm-probe|CleanRehost-v8-host-render-seq-scheduler|CleanRehost-v7-midi-gate-stable-db-ui-probe|CleanRehost-v6-programdb-loader|CleanRehost-v5-synth-driver-bruteforce|CleanRehost-v4-directsound-primary|CleanRehost-v3-bankset-registry|CleanRehost-v2-bankset-audio|CleanRehost-v1-service17-midi-lifecycle'),
    ('original core ready', r'core init: original routine returned .*ready after=1'),
    ('service 3 lifecycle ready', r'lifecycle service3 phase .*ready=1'),
    ('channel block nonzero', r'synth state .*\bchannels=(?!00000000)([0-9A-Fa-f]{8})'),
    ('audio registration reached original dispatcher', r'DIOC code=7002.*?(?:original SSYNENG dispatcher|SSYN engine boundary:.*code=00007002.*ok=1)'),
    ('output mode configured', r'service3 output mode rate=\d+ mode=[24]'),
    ('modern audio transport active', r'modern audio transport active via IOCTL 7002|service3 (?:legacy )?output running|AudioDirectSoundBuffer: Play[^\n]*DS_OK'),
    ('modern output state mirrored running', r'modern output state mirrored running=1'),
    ('MIDI/render processing gate enabled', r'midiProcessGate=1'),
    ('program DB install/reconstruction', r'(?:service17 SET bit64 programDb=([0-9A-Fa-f]{8})|IOCTL4001 SetBanksetPointer db=([0-9A-Fa-f]{8})|fallback program DB installed=1 db=([0-9A-Fa-f]{8}))'),
    ('internal program DB nonzero', r'synth state .*\bdb=(?!00000000)([0-9A-Fa-f]{8})'),
    ('resolved channel program', r'CH\d+ .*\bprogram=(?!00000000)([0-9A-Fa-f]{8})'),
    ('ready program', r'CH\d+ .*\bprogram=(?!00000000)[0-9A-Fa-f]{8} .*\bready=1\b'),
    ('host engine/render pump started', r'host engine pump started'),
    ('MIDI ring actually consumed', r'(?:host MIDI drain decoded=|synth state .*consumed=(?!0\b)\d+)'),
]
optional = [
    ('SSYNMIDI cmd59 callback registration', r'SSYNMIDI32: cmd59 callback registration'),
    ('SSYNMIDI 0x489 callback delivered', r'SSYNMIDI32: callback message=489 .*hwnd='),
    ('SSYNMIDI callback token unresolved', r'SSYNMIDI32: callback message=489 .*unresolved'),
    ('VMM fault-hook compatibility', r'Hook_VMM_Fault compatibility no-op success'),
    ('brute-force GM/GS prime', r'brute-force prime full GM/GS reset -> 1'),
    ('brute-force MIDI probe', r'brute-force probe PC0=1 NoteOn=1'),
    ('program-root registrations', r'cmd41 program-root root=(?!00000000)'),
    ('reconstructed program DB', r'fallback program DB installed=1 db=(?!00000000)'),
    ('post-DB MIDI probe', r'post-DB probe channel=\d+ NoteOn=.*queued=1'),
    ('host AA9B0 rendering', r'host AA9B0 render call='),
    ('v12 AA9B0 contract', r'render contract .*slices=\d+ callbackBytes=(?!0\b)\d+'),
    ('v12 synchronized DS handoff', r'host AA9B0 render call=.*copied=1'),
    ('v12 sequence UI mirror', r'NativeSeqPlay: UI mirror controls'),
    ('active runtime voice', r'synth state .*voices=(?!0\b)\d+'),
    ('nonzero PCM rendered', r'host AA9B0 render call=.*pcmNonZero=(?!0\b)\d+'),
    ('native SMF parsed', r'NativeSeqPlay: SMF parsed .*events=(?!0\b)\d+'),
    ('native sequence scheduler', r'NativeSeqPlay: scheduler started .*events=(?!0\b)\d+'),
    ('native sequence MIDI injected', r'NativeSeqPlay: scheduler finished .*injected=(?!0\b)\d+'),
    ('UI post-DB sweep', r'UI post-DB sweep complete'),
    ('native WRITEPRIMARY accepted', r'requested=DSSCL_WRITEPRIMARY native -> 00000000'),
    ('stale primary warning suppressed', r'suppressing stale primary-buffer warning'),
    ('bankset file opened', r'SeerBankset open .*handle=(?!FFFFFFFF|0xffffffff)'),
    ('MIDI event queued', r'MIDI event queued|synthetic short message|MIDI inject'),
]

print(f'Reality clean-rehost diagnostic: {p}')
print('  scope: latest process only')
first_fail = None
for name, pat in required:
    ok = re.search(pat, text, re.I | re.S) is not None
    print(f'  [{"OK" if ok else "--"}] {name}')
    if not ok and first_fail is None:
        first_fail = name
for name, pat in optional:
    ok = re.search(pat, text, re.I | re.S) is not None
    print(f'  [{"OK" if ok else ".."}] {name} (optional until exercised)')

m = re.findall(r'service17 SET bit64 programDb=([0-9A-Fa-f]{8})', text, re.I)
m2 = re.findall(r'IOCTL4001 SetBanksetPointer db=([0-9A-Fa-f]{8})', text, re.I)
if m or m2:
    print('  last incoming programDb =', (m + m2)[-1])
state = re.findall(r'synth state[^\n]*db=([0-9A-Fa-f]{8})[^\n]*channels=([0-9A-Fa-f]{8})[^\n]*engine=([0-9A-Fa-f]{8})', text, re.I)
if state:
    print('  last internal db/channels/engine =', '/'.join(state[-1]))
bank = re.findall(r'VirtualRegistry: initialized[^\n]*banksets=([^\s]+)[^\n]*hasSeerBankset=(\d)', text, re.I)
if bank:
    print(f'  bankset directory = {bank[-1][0]} (contains .SeerBankset={bank[-1][1]})')

fatals=[]
for pat in (r'exception(?: code)?=([0-9A-Fa-f]{8})',
            r'UNKNOWN/REJECTED code=([0-9A-Fa-f]+)',
            r'engine operation failed error=(\d+)'):
    fatals += re.findall(pat, text, re.I)
if fatals:
    print('  warnings/errors in latest process:', ', '.join(fatals[-12:]))

if first_fail:
    print('\nFirst missing required milestone:', first_fail)
    hints = {
      'clean build loaded':'The new RealityCompat DLL may not be the one being injected.',
      'original core ready':'Check ssyneng.rehost location and VMM/core-start logs.',
      'service 3 lifecycle ready':'Trace B1EF0 and engine-state initialization.',
      'channel block nonzero':'Core/channel initialization is incomplete.',
      'audio registration reached original dispatcher':'SynMid audio registration did not reach SSYNENG.',
      'output mode configured':'Service-3 rate/mode state was not established.',
      'modern audio transport active':'SynMid did not complete its DirectSound/WaveOut + IOCTL 7002 transport registration.',
      'modern output state mirrored running':'The modern 0x7002 transport is active but engineState+0x258 was not mirrored to the legacy running state.',
      'MIDI/render processing gate enabled':'The legacy B6E90-equivalent global MIDI/render processing gate object1+0x20912 was not enabled.',
      'program DB install/reconstruction':'No program DB became available. v6 should reconstruct the missing wrapper DB from command-41 program-root registrations when the old bit-64/IOCTL4001 handoff is absent. Look for cmd41 program-root / fallback program DB logs.',
      'internal program DB nonzero':'A SetProgramDatabase request arrived but original 0x922E0 did not retain the pointer.',
      'resolved channel program':'Database exists but bank/program resolution left channel+0x06 null.',
      'ready program':'Program exists but resources are not ready; inspect delayed-MIDI/resource loading.',
      'host engine/render pump started':'v7 had the SSYNENG gates set but never recreated the Win9x audio callback clock. v8 must start the host pump that drains MIDI and calls AA9B0.',
      'MIDI ring actually consumed':'MIDI is being queued but the recovered A66B0 decoder is still not being driven. Check host MIDI drain/AA9B0 exceptions.',
    }
    print(hints.get(first_fail,''))
else:
    print('\nAll required transport milestones were observed. In v12, first check the recovered AA9B0 contract (slices/callbackBytes), copied=1, and pcmNonZero. If voices are nonzero but pcmNonZero stays 0, use the render-contract and layer-region logs to isolate remaining mixer/resource state. If PCM is nonzero but no sound is heard, trace the DirectSound play cursor versus the host copy cursor.')
