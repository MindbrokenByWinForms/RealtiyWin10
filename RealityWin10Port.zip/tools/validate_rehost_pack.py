#!/usr/bin/env python3
"""Structural validator for SSYNENG rehost packs.
Does not execute the VxD. It verifies object/fixup bounds and the guarded negative targets.
"""
import argparse, pathlib, struct, sys

HDR = struct.Struct('<8sIII')
OBJ = struct.Struct('<I')
FIX = struct.Struct('<BBBBIi')
GUARD = 64

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pack')
    ap.add_argument('--expect-fixups', type=int, default=8728)
    ap.add_argument('--expect-negative', type=int, default=19)
    a = ap.parse_args()
    b = pathlib.Path(a.pack).read_bytes()
    if len(b) < HDR.size:
        raise SystemExit('pack truncated before header')
    magic, version, object_count, fixup_count = HDR.unpack_from(b, 0)
    if magic[:7] != b'SSYNRH1' or version != 1:
        raise SystemExit(f'bad header magic/version: {magic!r} v{version}')
    p = HDR.size
    sizes = []
    for _ in range(object_count):
        if p + OBJ.size > len(b): raise SystemExit('truncated object table')
        (n,) = OBJ.unpack_from(b, p); p += OBJ.size; sizes.append(n)
    image_bytes = sum(sizes)
    p += image_bytes
    if p + fixup_count * FIX.size != len(b):
        raise SystemExit(f'length mismatch: header expects {p + fixup_count*FIX.size}, file is {len(b)}')
    neg = 0
    kinds = {}
    for i in range(fixup_count):
        so, to, kind, reserved, src, target = FIX.unpack_from(b, p); p += FIX.size
        if reserved != 0: raise SystemExit(f'fixup {i}: reserved byte nonzero')
        if not (1 <= so <= object_count and 1 <= to <= object_count):
            raise SystemExit(f'fixup {i}: bad object id {so}->{to}')
        if src + 4 > sizes[so-1]:
            raise SystemExit(f'fixup {i}: source out of bounds {so}:{src:#x}')
        if target < -GUARD or target >= sizes[to-1]:
            raise SystemExit(f'fixup {i}: target out of guarded bounds {to}:{target:#x}')
        if target < 0: neg += 1
        if kind not in (7, 8): raise SystemExit(f'fixup {i}: unsupported kind {kind}')
        kinds[kind] = kinds.get(kind, 0) + 1
    if a.expect_fixups >= 0 and fixup_count != a.expect_fixups:
        raise SystemExit(f'fixup count mismatch: {fixup_count} != {a.expect_fixups}')
    if a.expect_negative >= 0 and neg != a.expect_negative:
        raise SystemExit(f'negative-target count mismatch: {neg} != {a.expect_negative}')
    print(f'OK: {object_count} objects {sizes}, {fixup_count} fixups {kinds}, {neg} guarded negative targets, {len(b)} bytes')

if __name__ == '__main__': main()
