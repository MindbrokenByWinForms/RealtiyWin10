from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
plug = (ROOT / "clap/src/reality_clap.cpp").read_text(errors="replace")
ini = (ROOT / "clap/config/RealityCLAP.ini").read_text(errors="replace")

checks = {
    "clap_gui_extension": "CLAP_EXT_GUI" in plug and "clap_plugin_gui_t kGui" in plug,
    "win32_only_embedded_api": "CLAP_WINDOW_API_WIN32" in plug and "!isFloating" in plug,
    "fixed_size": "guiCanResize(const clap_plugin_t*) { return false; }" in plug,
    "finds_reality_gui_class": 'L"Reality GUI"' in plug,
    "rejects_title_only_splash": '_wcsicmp(cls, L"Reality GUI") != 0' in plug and 'return ctx.score >= 1000' in plug,
    "uses_engine_pid": "bridge.enginePid()" in plug and "GetWindowThreadProcessId" in plug,
    "cross_process_parent": "SetParent(realityHwnd, guiHwnd)" in plug,
    "child_style_conversion": "WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN" in plug,
    "restores_top_level": "restoreRealityWindow" in plug and "realityOriginalStyle" in plug,
    "secondary_windows_untouched": "EnumChildWindows" not in plug,
    "reattach_timer": "SetTimer(guiHwnd, kGuiAttachTimerId" in plug and "onGuiTimer" in plug,
    "fallback_on_failure": "leaving Reality floating" in plug,
    "actual_client_measurement": "GetClientRect(hwnd, &client)" in plug,
    "fallback_config": "GuiFallbackWidth" in plug and "GuiFallbackWidth" in ini,
    "bridge_kept": "RealityBridgeClient bridge" in plug,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL"), name)
if failed:
    raise SystemExit("v13.19 fixed GUI checks failed: " + ", ".join(failed))
print("v13.19 fixed embedded GUI static checks: PASS")
