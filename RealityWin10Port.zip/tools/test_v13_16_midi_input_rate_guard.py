from pathlib import Path

root = Path(__file__).resolve().parents[1]
cpp = (root / "src/engine/ssyneng_host.cpp").read_text()
compat = (root / "src/compat/reality_compat.cpp").read_text()

assert "engine + 0x284" in cpp
assert "engine + 0x256" in cpp
assert "currentConfiguredRate != rate || currentOutputMode != expectedOutputMode" in cpp
assert "engineStateDrifted = engineConfiguredRate != rate || engineOutputMode != expectedOutputMode" in cpp
assert "foldCompare != expectedFold ||\n                         engineStateDrifted" in cpp
assert "SSYNENG modern engine rate restore" in cpp
assert "SSYNENG service17 sample-rate SET requested=" in cpp
assert "configuredRate=%lu outputMode=%u" in cpp
assert ("CleanRehost-v13.16-midi-input-engine-rate-guard-20260916" in compat or
        "CleanRehost-v13.17-midi-input-lifecycle-fix-20260916" in compat)
print("v13.16 MIDI-input engine-rate guard static checks: PASS")
