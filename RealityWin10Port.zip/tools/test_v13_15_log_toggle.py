from pathlib import Path

cpp = Path('src/common/log.cpp').read_text(encoding='utf-8')
bat = Path('run_reality_v13_17.bat').read_text(encoding='utf-8')

assert 'GetEnvironmentVariableA("REALITY_CREATE_LOG"' in cpp
assert 'LoggingDisabledByEnvironment()' in cpp
assert 'if (LoggingDisabledByEnvironment()) return;' in cpp
assert 'set "REALITY_CREATE_LOG=1"' in bat
assert 'if "%REALITY_CREATE_LOG%"=="0"' in bat
assert 'Logging: ENABLED' in bat
assert 'Logging: DISABLED' in bat
print('v13.15 log toggle static checks: PASS')
