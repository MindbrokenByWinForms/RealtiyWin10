#!/usr/bin/env python3
from pathlib import Path
import struct, sys, hashlib
ROOT=Path(__file__).resolve().parents[1]
pack=ROOT/'ssyneng.rehost'
data=pack.read_bytes()
magic,ver,nobj,nfix=struct.unpack_from('<8sIII',data,0)
assert magic.startswith(b'SSYNRH1') and ver==1 and nobj>=1
off=20
sizes=[]
for _ in range(nobj):
    s,=struct.unpack_from('<I',data,off);off+=4;sizes.append(s)
obj1=data[off:off+sizes[0]]
checks={
    0x8EC00:b'\x55',      # PM/core startup
    0x922E0:b'\x55\x8b\xec', # SetProgramDatabase
    0x94FE0:b'\x55\x8b\xec', # service17 body
    0xA4BD0:b'\x55',      # Note On
    0xA5820:b'\x55',      # Program Change
    0xA66B0:b'\x55',      # MIDI decoder
    0xB1EF0:b'\x55\x8b\xec', # lifecycle helper
}
for rva,prefix in checks.items():
    got=obj1[rva:rva+len(prefix)]
    assert got==prefix, f'RVA {rva:06X}: expected {prefix.hex()} got {got.hex()}'
api=(ROOT/'src/engine/SSYNENG.def').read_text()
for name in ['SSynEng_ControlState','SSynEng_Start','SSynEng_Stop','SSynEng_ResetMidi','SSynEng_InjectMidiShort','SSynEng_GetProgramDatabase','SSynEng_RegisterProgramRoot']:
    assert name in api, f'missing export {name}'
native=(ROOT/'src/compat/native_midi.cpp').read_text()
assert '0x10000000u' in native and '0x5D8' in native, 'missing bit92 MIDI fast path'
assert '0x540' in native and '0x554' in native and 'registerRoot' in native, 'missing command41 program-root DB bridge'
seq=(ROOT/'src/compat/seqplay_native.cpp').read_text()
assert 'ParseSmf' in seq and 'scheduler started' in seq and 'NativeMidiInjectShort' in seq, 'missing v8 native SMF scheduler'
assert 'MirrorSequenceMessage' in seq and 'REALITY_SEQ_UI_MIRROR' in seq and '8200' in seq and '8600' in seq, 'missing v12 sequence UI mirror'
host=(ROOT/'src/engine/ssyneng_host.cpp').read_text()
assert '0x53Cu' in host and '0x94FE0' in host and '0x4001u' in host, 'missing service17/ioctl4001 program-db paths'
assert '0x1BEE0' in host and '0x101C' in host, 'missing exact MIDI event ring'
assert 'DrainMidiRingHost' in host and '0xA66B0' in host, 'missing v8 host MIDI drain'
assert 'channel-diff' in host and 'channelDiffSeen_' in host, 'missing v12 channel-state diff tracer'
assert 'RenderHostQuantum' in host and 'AA9B0' in host, 'missing v8 AA9B0 render pump'
assert 'ReadObjectU32(0x2090A)' in host and 'callbackSlices' in host and 'renderScratch_' in host, 'missing v12 AA9B0 callback contract/scratch handoff'
assert 'audioOp == 0x0Bu' in host and 'DeactivateModernAudio' in host, 'missing v12 7002 unlock lifetime fix'
assert 'ConfigureModernAudio' in host and 'host audio mapping' in host, 'missing v8 0x7002 audio mapping'
assert '0x922E0' in host and 'fallback program DB installed' in host and '0x18u' in host, 'missing reconstructed program DB loader'
print('OK clean source layout')
print('pack objects:',sizes,'fixups:',nfix)
print('pack sha256:',hashlib.sha256(data).hexdigest())
