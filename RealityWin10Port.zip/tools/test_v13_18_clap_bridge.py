from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
shared = (ROOT / "src/bridge/reality_clap_bridge_shared.h").read_text(errors="replace")
engine = (ROOT / "src/engine/ssyneng_host.cpp").read_text(errors="replace")
bridge = (ROOT / "src/bridge/reality_clap_bridge_engine.cpp").read_text(errors="replace")
plug = (ROOT / "clap/src/reality_clap.cpp").read_text(errors="replace")
client = (ROOT / "clap/src/bridge_client.cpp").read_text(errors="replace")
cmake = (ROOT / "clap/CMakeLists.txt").read_text(errors="replace")

checks = {
    "pointer_free_shared_abi": "void*" not in shared and "uintptr" not in shared,
    "fixed_shared_abi_size": "sizeof(SharedState) == 278600" in shared,
    "engine_publishes_aa9b0_pcm": "clapbridge::PublishAudio(renderScratch_" in engine,
    "engine_drains_bridge_midi": "clapbridge::PopMidi(&bridgeMidi)" in engine and "InjectMidiShort(bridgeMidi.packedMessage" in engine,
    "directsound_muted_only_in_bridge": "bridgeMuteDs" in engine and "std::memset" in engine,
    "plugin_has_stereo_output": "CLAP_EXT_AUDIO_PORTS" in plug and "Reality Main" in plug,
    "plugin_has_note_input": "CLAP_NOTE_DIALECT_CLAP | CLAP_NOTE_DIALECT_MIDI" in plug,
    "plugin_rejects_offline": "CLAP_RENDER_REALTIME" in plug and "CLAP_EXT_RENDER" in plug,
    "x64_frontend": "CMAKE_SIZEOF_VOID_P EQUAL 8" in cmake,
    "clap_1210_pinned": "GIT_TAG 1.2.10" in cmake,
    "sidecar_env_bridge": "REALITY_CLAP_BRIDGE_NAME=" in client,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL"), name)
if failed:
    raise SystemExit("v13.18 CLAP checks failed: " + ", ".join(failed))
print("v13.18 CLAP bridge static checks: PASS")
