from pathlib import Path

src = Path('src/compat/native_midi.cpp').read_text(encoding='utf-8')
compat = Path('src/compat/reality_compat.cpp').read_text(encoding='utf-8')

assert 'CleanRehost-v13.17-midi-input-lifecycle-fix-20260916' in compat
start = src.index('bool NativeMidiCloseDevice(unsigned midiId)')
end = src.index('MMRESULT NativeMidiHandleLongData', start)
close_body = src[start:end]
assert 'engineStop=deferred-to-driver-shutdown' in close_body
assert 'count == 0 ? NativeMidiStopEngine()' not in close_body
# Full/real shutdown must still stop the engine.
shutdown = src[src.index('void NativeMidiShutdownDriver()'):]
assert 'NativeMidiStopEngine();' in shutdown
print('v13.17 MIDI-input lifecycle preservation static checks: PASS')
