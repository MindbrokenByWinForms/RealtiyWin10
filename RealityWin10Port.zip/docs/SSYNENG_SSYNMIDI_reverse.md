# SSYNENG.VXD + SSYNMIDI.DRV reverse-engineering notes

These notes describe the exact binaries supplied with the Reality investigation.
No legacy binary was executed; this was static analysis of the NE/LE images.

## Input identity

| File | Type | Size | SHA-256 |
|---|---|---:|---|
| `SSYNENG(1).VXD` | Windows 9x LE dynamic VxD | 833,743 | `32d0f4179a1d0f0a06766c15d050091224b806676fe3bb1386de9ef713475309` |
| `SSYNMIDI.DRV` | Win16 NE multimedia driver | 37,312 | `1b238198d44195198daa4193814215bdca9dd970e89a9aec577672191bb3198d` |
| `SynCapt.EXE` | Win16 NE capture utility | 14,896 | see `SynCapt_reverse.md` |

## High-level architecture

The original stack is not merely a WaveOut/DirectSound wrapper:

```text
Win16 Reality UI / client
        |
        +--------------------+
        |                    |
        v                    v
 SSYNMIDI.DRV             SynCapt.EXE
 WinMM MIDI front-end     capture front-end
        |                    |
        +----------+---------+
                   |
          INT 2Fh, AX=1684h
          name = "SSYNENG "
                   |
                   v
             SSYNENG.VXD
       protected-mode API entry
                   |
       +-----------+------------+
       |           |            |
       v           v            v
 MIDI/control   synth/DSP    audio/capture
```

`SSYNMIDI.DRV` can dynamically load/unload `SSYNENG.VXD`. It obtains the
system VxD loader API with `INT 2Fh / AX=1684h / BX=0x27` (VXDLDR), requests
load/unload, then resolves the *named* `SSYNENG ` protected-mode API. Device ID
`0x27` therefore belongs to the loader, not to SSYNENG.

## SSYNENG LE / VxD entry points

The LE image has an exported ordinal pointing to the VxD Device Descriptor
Block (DDB) at object 1 + `0x3C13C`. Relevant DDB fields resolve to:

| DDB field | object 1 offset | Purpose |
|---|---:|---|
| control proc | `0xB8EB3` | VxD control-message entry |
| V86 API | `0xB8EA9` | effectively a no-op in this build |
| protected-mode API | `0xB8E9F` | the API used by Reality/SynCapt/SSYNMIDI |

The protected-mode entry is a tiny wrapper:

```asm
push ebp
push ebx
call 0xB1B50
pop  ebx
pop  ebp
ret
```

The V86 entry calls a routine that immediately returns. This is strong evidence
that the Windows clients specifically relied on the protected-mode interface.

## Protected-mode dispatcher

`0xB1B50` receives the VMM client-register frame. It reads client `AX` from
`[client+0x1C]` and splits it into:

- `AL`: service number for the AH=0 family
- `AH`: API family selector

If the engine is not initialized, exactly `AX=0001h` takes a special
initialization path (`0x8EC00`). Other calls fail with `0xFFFF` until the engine
is initialized.

For an initialized engine it calls `0xB15E0(client, AH, AL)`. AH=0 dispatches
AL through a 21-entry table (0..20). The reconstructed table is:

| AL | Handler | Current confidence |
|---:|---:|---|
| 0 | default | no-op/default |
| 1 | default | init is handled earlier when engine is absent |
| 2 | `0xB166B` | engine lifecycle/work-buffer operation |
| 3 | `0xB168F` | substantial engine start/open path |
| 4 | `0xB1770` | substantial engine stop/close path |
| 5 | `0xB182E` | returns status from `0x9061D` |
| 6 | `0xB1842` | success/no-op |
| 7 | default | no-op/default |
| 8 | default | no-op/default |
| 9 | default | no-op/default |
| 10 | `0xB1851` | calls engine refresh/reset routine `0xA6050` |
| 11 | `0xB185B` | larger reset/reinitialization path |
| 12 | default | no-op/default |
| 13 | `0xB18BF` | applies a current engine setting through `0x816C0` |
| 14 | `0xB18D4` | maps client pointer, passes two WORDs to `0x948C0` |
| 15 | `0xB1914` | pointer validation/mapping service |
| 16 | default | no-op/default |
| **17** | **`0xB193F`** | **shared synth-control state transfer (confirmed)** |
| 18 | `0xB198D` | mapped-structure operation, calls `0x962F0`/`0x96510` |
| 19 | `0xB1A05` | mapped-pointer operation, calls `0x96540` |
| 20 | `0xB1A3C` | large engine teardown/restart-like path |

AH=2, AH=3 and other nonzero AH values enter separate handlers rather than the
AL table. Their complete semantics remain to be named.

## Service AX=0011h: shared state transfer

This is the service used by SynCapt and heavily used by the MIDI/control side.
Handler `0xB193F` maps the caller's far pointer and calls core routine
`0x94FE0`.

The state starts with eight DWORD masks (256 bits):

```c
uint32_t fieldMask[8];    // offsets 0x00..0x1F
...                       // state fields selected by those masks
```

### Direction

`fieldMask[0] & 1` selects the **query/get** direction.

In query mode `0x94FE0` fills requested fields, builds a fresh eight-DWORD
"fields returned" mask locally, and copies that mask over the state block's
first 32 bytes before returning.

If bit 0 is clear, the routine is in **set/update** mode and consumes selected
fields from the caller.

### Confirmed sample-rate field

`fieldMask[1] & 0x20000000` (overall bit 61) selects sample rate.

In query mode the driver copies the engine's current sample rate into:

```text
state + 0x20C : DWORD sampleRate
```

and returns bit `0x20000000` in returned mask DWORD 1.

In set mode the same field participates in the engine's sample-rate switching
logic. The driver explicitly compares against 44100 (`0xAC44`).

### Confirmed capture descriptor

`fieldMask[1] & 0x00000080` (overall bit 39) selects capture state.
In set mode the old 32-bit state layout is:

```text
+0x194  DWORD callback address
+0x198  DWORD capture buffer 0 pointer
+0x19C  DWORD capture buffer 1 pointer
+0x1A0  DWORD capture size/limit
```

The VxD maps the two client buffer addresses and stores a global capture
structure equivalent to:

```c
struct OldCaptureGlobals {
    uint32_t callback;       // relocated global ~obj1+0x3F28C
    uint32_t buffer0Linear;  // ~+0x04
    uint32_t buffer1Linear;  // ~+0x08
    uint32_t bufferLimit;    // ~+0x0C
    uint16_t bufferIndex;    // ~+0x10/0x14 region
    uint32_t byteOffset;     // ~+0x14 region
};
```

(The addresses above identify the contiguous global region; field naming is
semantic, not recovered source symbols.)

### Capture callback behavior

The capture writer checks that a callback is installed and writes rendered
samples into whichever of the two mapped buffers is active. On a completed
buffer it constructs:

```c
callbackValue = ((bufferIndex & 0xFF) << 24) | (validByteCount & 0x00FFFFFF);
```

It invokes the Win16 callback through a VMM callback helper, then performs:

```c
bufferIndex = 1 - bufferIndex;
byteOffset = 0;
```

This confirms SynCapt's observed packed callback ABI and its double buffering.

## SSYNMIDI.DRV

`SSYNMIDI.DRV` is a Win16 NE multimedia/MIDI driver, not the synthesizer itself.
The product resources identify version 5.1.5.5 and the device description
contains `midi:Reality`.

Notable exports include:

```text
WEP
DriverProc
ConfigTimerProc
SeerSynthControl
TimeFunc
wodMessage
modMessage
```

It imports the Win16 modules KERNEL, USER, MMSYSTEM, SHELL and SETUPX.

### VxD loading

Initialization constructs/resolves `SSYNENG ` through `INT 2Fh / AX=1684h`.
If the named VxD is not present, it obtains the VxD loader interface using
`BX=0x27`, asks it to load `SSYNENG.VXD`, then retries the named lookup.
There is a symmetric unload path and an embedded message explaining that the
driver can refuse to unload while playing.

Thus the actual path is:

```text
WinMM -> SSYNMIDI.DRV -> VXDLDR -> SSYNENG.VXD -> SSYNENG PM API
```

### modMessage

The exported `modMessage` is a standard old-style MIDI-output driver switch.
Its cases 1..13 are now mapped exactly below; driver-management cases
`0x64..0x67` are separate lifecycle/configuration messages.

### SeerSynthControl

`SeerSynthControl` accepts a much larger control structure. Code accesses
fields out to approximately `+0x5EC`, and validates/works with a size around
`0x5F0`. Its first eight DWORDs again behave as field masks. It performs some
WinMM/driver-side work itself and routes engine-backed state through SSYNENG.

This means a faithful replacement should not model the entire interface as
only the minimum `0x210` bytes seen by SynCapt; the Reality MIDI/control path
uses an extended block of at least ~`0x5F0` bytes.

## Service 3 / service 4: output-engine lifecycle (confirmed)

The MIDI driver contains direct protected-mode wrappers for `AX=0003h` and
`AX=0004h`, and its higher-level MIDI-device open/close helpers call them. The
VxD side confirms that these are the substantial output-engine start/stop pair.

### Service 3 (`AX=0003h`, handler `0xB168F`)

The core sequence is:

```c
uint16_t service3_start(ClientFrame *client) {
    // 0xB1EF0(1): establish lifecycle state and initialize the 16 channel
    // objects when required.
    if (engine_lifecycle_set(1) != 1)
        return error;

    if (conflicting_components_active(/*allowed mask=*/2))
        return error;

    EngineState *s = gEngineState;             // global 0x2A5C4

    // state+0x284 is the configured/requested rate.  This build supports only
    // the two output modes used throughout Reality.
    s->outputRateMode = (s->configuredRate == 44100) ? 4 : 2; // +0x256

    uint16_t err = open_output_backend();       // 0xB6E90
    if (err == 0) {
        s->outputRunning = 1;                   // +0x258
        s->statusWord = 0;                      // +0x0A
        return 0;
    }

    // Failure path tears down the lifecycle state and clears a 0xAC-byte
    // runtime/output block rooted at *(0x3C190)+0x318.
    cleanup_partial_start();
    return err;
}
```

`0xB6E90` constructs a small custom PCM descriptor with:

```text
format/type = 1
sample rate = (state+0x256 == 2) ? 22050 : 44100
bits        = 16
channels    = 2
```

and calls `0x96400(0xFFFF, &format)`. `0x96400` eventually invokes the
installed audio-backend function pointer at global `0x208CC` with a final
argument of `1`. The close counterpart is the backend pointer at `0x208D8`.

This also corrects an earlier provisional interpretation: **mode 4 is 44.1 kHz
and mode 2 is 22.05 kHz**. Service 3 chooses mode 4 only when the configured
rate is exactly 44100; other values are reduced to the 22.05-kHz mode.

`0xB1EF0(1)` is more than a Boolean setter. When the engine is entering the
lifecycle state it initializes the 16 per-channel objects rooted at global
`0x208A0`, with stride `0x7A4`, through `0xA59D0` and performs additional
engine setup (`0xAC930`, `0xAC880`).

### Service 4 (`AX=0004h`, handler `0xB1770`)

Service 4 is the mirror teardown path:

```c
uint16_t service4_stop(void) {
    if (gEngineState->lifecycle == 1)
        tear_down_lifecycle_state();

    reset_all_channels_and_voices();            // 0xA6050

    if (conflicting_components_active(2))
        return current_error;

    if (gEngineState->outputPresent != 0) {      // WORD +0x250
        uint16_t err = close_output_backend();  // 0x964E0 -> [0x208D8](1)
        release_output_mapping();               // 0x94A10
        if (err == 0)
            gEngineState->outputRunning = 0;    // +0x258
        clear_runtime_output_block();
        final_output_cleanup();                  // 0xAE030
        return err;
    }
    return current_error;
}
```

This is why replacing only DirectSound/WaveOut is insufficient: Reality's MIDI
front end expects this VxD lifecycle operation to initialize channel objects,
queue state and engine runtime state before MIDI events are useful.

### Service 10 (`AX=000Ah`) is MIDI/synth reset

The Win16 driver's `MODM_RESET` case calls service `0x0A`, whose VxD handler
calls `0xA6050`. That routine iterates all 16 channel objects, clears the
per-note maps and active voice/controller state, and walks/release-resets voice
objects. It is therefore the reset operation needed by a compatible MIDI
front end.

### Service 11 (`AX=000Bh`) is a full MIDI-mode / GM-GS reinitialization

Handler `0xB185B` is substantially larger than service `0x0A`:

```c
uint16_t service_0B_full_midi_reset(void) {
    reset_all_channels_and_voices();      // 0xA6050
    initialize_midi_engine_queues();      // 0xAC880

    for (int ch = 0; ch != 16; ++ch)
        initialize_channel(gChannels + ch * 0x7A4); // 0xA59D0

    global_engine_setup_1(0xA100, &gBlock3C970);    // 0x83320
    global_engine_setup_2(0x1E800, &gBlock3C970);   // 0xAC2F0
    global_engine_setup_3(0);                       // 0xAB7D0
    return 0;
}
```

The semantic name is supported by the caller, not just by this reset-like body:
`SSYNMIDI.DRV`'s long-data parser recognizes both **General MIDI System On**
and a **Roland GS Reset** signature and calls its direct `AX=000Bh` wrapper.
Thus service `0x0B` is the engine's full MIDI-mode reinitialization path used
for GM/GS resets, while service `0x0A` is the ordinary WinMM `MODM_RESET`.

## SSYNMIDI `modMessage` mapping (confirmed)

The 1..13 switch in this exact Win16 driver maps to the classic MIDI-output
operations as follows:

| message | operation | observed target |
|---:|---|---|
| 1 | GETNUMDEVS | local |
| 2 | GETDEVCAPS | local |
| 3 | OPEN | open helper, eventually service 3 |
| 4 | CLOSE | close helper, eventually service 4 |
| 5 | PREPARE | unsupported/local path in this build |
| 6 | UNPREPARE | unsupported/local path in this build |
| **7** | **DATA / short MIDI** | queue producer path |
| **8** | **LONGDATA / SysEx** | MIDIHDR parser / long-data path |
| **9** | **RESET** | service `0x0A` |
| 10 | GETVOLUME | local/control state |
| 11 | SETVOLUME | local/control state |
| 12 | CACHEPATCHES | patch-cache path |
| 13 | CACHEDRUMPATCHES | drum-patch-cache path |

This is important for rehosting: the previous v2 compatibility shim had
provisional message numbers for DATA/RESET; v3 uses the exact `7/8/9` values.

### `MODM_LONGDATA` stream parser (`SSYNMIDI` seg1:`0x0EB4`)

The long-data routine first validates that the `MIDIHDR` is prepared (flag bit
`0x2`), obtains its data pointer and byte count, and then walks the byte stream.
It is not a blind "send this buffer to the VxD" call. It reconstructs packed
short messages and sends them through the same driver queue helper used by
`MODM_DATA`.

For channel status bytes, the parser uses the expected MIDI message lengths and
keeps running status in the driver instance (the saved status is visible around
instance offsets `+0x74/+0x76`):

```text
8n Note Off       : status + 2 data bytes
9n Note On        : status + 2 data bytes
An Poly Pressure  : status + 2 data bytes
Bn Control Change : status + 2 data bytes
Cn Program Change : status + 1 data byte
Dn Channel Press. : status + 1 data byte
En Pitch Bend     : status + 2 data bytes
```

Data bytes with no new status reuse the saved running status. A new non-realtime
status updates or clears that state as appropriate. This means MIDI files /
long WinMM buffers can be reduced to exactly the same packed 24-bit event form
consumed by SSYNENG's `0xA66B0` decoder.

#### Small SysEx recognizer (`seg1:0x0CE6` / `0x0BA2`)

The parser maintains a tiny SysEx state object. On `F0` it marks SysEx active
and starts an accumulated byte count. It stores at most the first 16 bytes
(`state + 0x06`) while still counting the full message. `F7` ends the message
and, for short-enough prefixes, calls the recognizer at `0x0BA2`. Realtime
status bytes `F8..FF` are allowed to interrupt the accumulator without becoming
part of the stored SysEx prefix.

Two reset families are recognizable directly from the comparisons:

```text
F0 7E <device> 09 01 ... F7
   ^^          ^^^^^
   Universal Non-Realtime, General MIDI System On

F0 41 10 42 12 40 00 7F 00 ... F7
   ^^ ^^ ^^ ^^ ^^^^^^^^^^^
   Roland device 10h / GS model 42h / DT1 / GS-reset address+data
```

For the universal sequence, the parser deliberately does not require a specific
device byte (`<device>`). For the Roland sequence it specifically checks device
ID `0x10`, model `0x42`, command `0x12`, and the `40 00 7F 00` reset payload
prefix. In either recognized reset case it calls the driver's `AX=000Bh`
wrapper, i.e. the full MIDI-mode reset described above. The observed recognizer
does not validate the final Roland checksum before choosing that reset path.

This should not be overread as a complete SysEx implementation: the code is a
small reset/signature recognizer embedded in the general long-buffer parser.

## Realtime MIDI transport: shared 512 x 8-byte ring (confirmed)

Short MIDI messages are **not** delivered to the VxD by making one protected-
mode API call per event. `SSYNMIDI.DRV` writes them directly into a shared
ring, while the VxD's audio/render path drains that ring.

The ring is exactly `0x101C` bytes:

```c
struct LegacyMidiEvent {
    uint32_t packedMidi;       // status | data1<<8 | data2<<16
    uint32_t timestamp;        // TimeFunc-derived driver timestamp
};

struct LegacyMidiRing {
    uint32_t writeIndex;       // +0x00
    uint32_t readIndex;        // +0x04; initialized to 0x1FF
    uint32_t unknown08;        // +0x08
    uint32_t unknown0C;        // +0x0C
    uint32_t unknown10;        // +0x10
    uint32_t producedCount;    // +0x14
    uint32_t consumedCount;    // +0x18
    LegacyMidiEvent event[512];// +0x1C, 8 bytes each
};                            // total = 0x101C
```

The VxD initializer at `0xB0710` sets `writeIndex=0`, `readIndex=0x1FF` and
zeros the remaining header counters. The Win16 producer at approximately
segment 1:`0x1DC4` writes at `event[writeIndex]`, advances and wraps after
`0x1FF`, stores the new write index and increments `+0x14`.

The matching VxD dequeue routine around `0xB0800` computes
`next=(readIndex+1)&0x1FF`; `next == writeIndex` means empty. Otherwise it
increments `+0x18`, returns `event[next].packedMidi`, and commits
`readIndex=next`.

The ring is not merely inferred from matching sizes. During VxD initialization,
`0xACB10` does:

```text
map_client_alias(0x1BEE0, 0x101C, 1) -> global 0x3F630
```

and service 17 query bit `fieldMask[1] & 0x40000000` (overall bit 62) returns
that mapped alias at:

```text
state + 0x530
```

Thus `0x1BEE0` is a VxD-resident MIDI ring deliberately mapped into client
address space for the Win16 producer. A second internal ring exists at
`0x1D720`; both are initialized by the engine reset/setup path.

The render/tick path calls the queue drain code (`0xB08C0` and related
routines) under the profiler regions named `ProcessMidiCpuPre` and
`ProcessMidiCpuPost`. Dequeued messages are passed to the central MIDI decoder
at `0xA66B0`.

## Central MIDI decoder `0xA66B0`

The VxD masks each message to 24 bits and decodes the conventional WinMM packed
short-message format:

```c
msg     &= 0x00FFFFFF;
status   = msg & 0xFF;
channel  = status & 0x0F;
command  = status & 0xF0;
data1    = (msg >> 8)  & 0x7F;
data2    = (msg >> 16) & 0x7F;
channelState = gChannels + channel * 0x7A4;
```

The command dispatch is:

| status | meaning | VxD path |
|---|---|---|
| `8n` | Note Off | `0xA6733` -> `0xA4D00` |
| `9n` | Note On | `0xA6745` -> `0xA4BD0` |
| `An` | Poly Key Pressure | `0xA6886` |
| `Bn` | Control Change | `0xA6758` -> `0xA5130` / `0xA6270` |
| `Cn` | Program Change | `0xA67DC` -> `0xA5820(channel, program, 1)` |
| `Dn` | Channel Pressure | `0xA67EF` |
| `En` | Pitch Bend | `0xA692A` |
| `Fn` | system / realtime | `0xA6A06` |

### Note on / note off

`0xA4BD0` explicitly tests Note On velocity. When velocity is zero it routes to
`0xA4D00`, i.e. standard MIDI `Note On velocity 0 == Note Off` behavior. With
nonzero velocity it updates the channel's 128-note bookkeeping arrays
(`+0x514` and `+0x594`) and enters the deeper voice/program allocation path
(`0xA4720` or a specialized path depending on the active program object).

`0xA4D00` is the note-release path. It updates performance counters, clears the
per-key state and walks/releases matching active voices. This is already well
past a simple MIDI parser and enters actual Reality voice management.

### Pressure and pitch bend state

Poly pressure stores the raw value per note at:

```text
channel + 0x27C + note       : BYTE raw pressure
channel + 0x2FC + note*4     : float normalized/clamped pressure
```

Channel pressure stores:

```text
channel + 0x277              : BYTE raw pressure
channel + 0x278              : float normalized/clamped pressure
```

Pitch bend stores the two 7-bit bytes at `+0x262/+0x263`, derives the signed
14-bit bend around center `0x2000`, stores normalized bend at `+0x264`, then
updates derived pitch quantities at `+0x26E/+0x272` using the channel's bend
range/tuning state.

### Controller processing

Controllers below 120 go to `0xA5130`; channel-mode messages 120..127 go to
`0xA6270`.

Several important controller semantics are directly identifiable:

```text
CC 6    Data Entry MSB
CC 38   Data Entry LSB
CC 64   Sustain pedal; release below 64 walks deferred/held voices
CC 98   NRPN LSB (unsupported selector path/reset in this build)
CC 99   NRPN MSB (unsupported selector path/reset in this build)
CC 100  RPN LSB
CC 101  RPN MSB
```

The RPN selector is kept around channel offsets `+0x508/+0x509/+0x50A`.
Data-entry handling recognizes at least RPN 0/1/2 and updates pitch-related
state, including pitch-bend range/tuning fields. Ordinary controllers are
stored in raw controller arrays and converted into normalized float values for
the synth modulation path.

Channel-mode CCs map exactly as MIDI defines them:

```text
120 All Sound Off
121 Reset All Controllers
122 Local Control
123 All Notes Off
124 Omni Mode Off
125 Omni Mode On
126 Mono Mode On
127 Poly Mode On
```

The all-sound/all-notes/omni/poly handlers walk active voices and clear the
128-note bookkeeping arrays. `All Notes Off` contains explicit sustain-pedal
logic: with sustain down it defers release by setting a per-channel hold state;
without sustain it releases matching voices immediately.

### System and realtime MIDI

The `F0..FF` dispatch table is also recoverable:

```text
F0 -> 0xA6A28  (short-message F0 handler; resets several per-channel selector/default fields)
F1..F7 -> ignored/default in this short-message decoder
F8 -> 0xA6A79  MIDI Timing Clock
F9 -> ignored
FA -> 0xA6AA9  Start
FB -> 0xA6AA9  Continue (same state transition here)
FC -> 0xA6ACD  Stop; also calls 0xAB950
FD -> ignored
FE -> ignored by this decoder
FF -> 0xA6A6D  System Reset -> `0xB1C10`
```

The `F8/FA/FB/FC` handlers manipulate globals around `0x3F19C`, `0x3F2A2` and
`0x3F2A8`, confirming that MIDI clock/transport synchronization is part of the
engine core rather than a UI-only feature.

The short-message `F0` handler is not the long SysEx parser. Actual buffered
SysEx recognition occurs in `SSYNMIDI.DRV` as described above, so
`0xA6A28` should be treated only as the VxD's short-message/system-state path.

## `SeerSynthControl` MIDI fast path

`SeerSynthControl` has a driver-side operation that bypasses service 17. In
**set/update** mode, overall field-mask bit 92 is:

```text
fieldMask[2] & 0x10000000
```

and the driver takes the packed DWORD at:

```text
state + 0x5D8
```

and calls its short-MIDI queue helper (`seg1:0x1EA8`) directly, then returns
success instead of forwarding that operation to the VxD state-transfer
routine. This is another likely path used by Reality itself to inject MIDI
into the synth without going through WinMM `modMessage`.

## Strings that identify engine responsibilities

The VxD contains strings and property names including:

```text
SquareWave
PhysicalVoice
ProcessWaveIn
ProcessMidiCpuPre
ProcessMidiCpuPost
SynthPerformance
44kFixedSampleRate
OutputDeviceNumber
DirectSound
WaveDriverVolume
MasterControls
SSCpuUse
SSNumVoic
SSClips
AudioBufferSize
```

and errors including `Can't allocate Direct Sound DMA buffer`.

A debug/PDB pathname is embedded:

```text
R:\rembuild\get\REALITY\DRIVERS\VSEERD\SSYNENG.pdb
```

This confirms that SSYNENG contains substantial synth/DSP, MIDI-processing and
audio-device logic. It is not just a capture bridge.

## Consequence for a 64-bit port

A kernel-mode x64 VxD port is the wrong target: x64 Windows does not support
Windows 9x VxDs or Win16 clients. The practical port boundary is user mode:

1. replace `INT 2Fh`/VxD API discovery with normal exported functions;
2. replace the shared far-pointer control state with an x64-safe API while
   preserving byte offsets/masks where useful to the rehost;
3. replace cross-process capture callback pointers with a named shared-memory
   PCM ring;
4. replace `SSYNMIDI.DRV` with a normal x64 bridge that accepts packed WinMM
   short MIDI messages and feeds a MIDI queue/engine;
5. progressively port or emulate the actual synth/DSP routines behind the VxD
   services.

The code in this package implements steps 1-4 for the portions whose behavior
is now confirmed. It deliberately does **not** claim to reproduce the VxD's
full synthesis DSP yet.

## Deeper program-selection and Note-On path

The next layer below the MIDI decoder is now sufficiently mapped to explain
why a rehost can have working WinMM MIDI and audio devices yet still create no
sound.

### Correction: service 17 program-database field

A deeper pass found a register rollover between the service-17 mask groups.
An earlier provisional note treated the `+0x53C` field as mask DWORD 1 bit 0.
That was incorrect.

The exact SET/apply path at `0x95767` tests the register that was loaded from
`[state+0x08]` at `0x956DD`. Therefore the field is:

```text
state + 0x53C               DWORD legacy program-database pointer
fieldMask[2] & 0x00000001   apply/set this pointer
                            = overall mask bit 64
```

Capture remains overall bit 39 and sample rate remains overall bit 61.

When bit 64 is set, service 17 passes `state+0x53C` to `0x922E0`, here named
`SetProgramDatabase`.

### Program database registration (`0x922E0`)

`SetProgramDatabase(db)` stores the pointer in global `obj1+0x3C510`.

If `db == NULL`, it performs a synth reset and clears the resolved-program
pointer for all 16 channels.

If `db != NULL`, it walks every MIDI channel and resolves the channel's current
bank/program key immediately. Thus a Program Change does not need to occur
after database installation: installing the database itself re-resolves the
existing per-channel selection.

Relevant global/state addresses in this build are:

```text
obj1+0x3C510  current program database pointer
obj1+0x3C514  high program namespace/prefix
obj1+0x208A0  base of 16 MIDI channel objects
obj1+0x2A5C4  main engine-state pointer
```

These are object-1 offsets in the relocated VxD image, not fixed process
addresses.

### MIDI channel object

The 16 channel objects have an exact stride of `0x7A4` bytes. Fields confirmed
by Program Change / Note On include:

```text
channel + 0x000  WORD  channel number/index
channel + 0x002  DWORD current packed bank/program key
channel + 0x006  DWORD resolved current program/instrument pointer
channel + 0x00A  BYTE  one bank-select component
channel + 0x02A  BYTE  the other bank-select component
channel + 0x276  BYTE  current 7-bit MIDI program number
channel + 0x7A2  WORD  Note-On gate/disable state (exact original field name unknown)
```

The semantic label for `+0x7A2` is intentionally conservative: Note On returns
without constructing a voice while it is nonzero.

### Program Change (`0xA5820`)

The Program Change handler writes the 7-bit program to `channel+0x276`, combines
it with the two bank bytes into the low program key, and stores the result at
`channel+0x02`.

The database lookup is then selected as follows:

- normal channels use lookup routine `0x91F60`;
- channel 10 (zero-based channel index 9) can use the separate drum lookup
  `0x91E50` when the engine's drum-mode condition is enabled.

The resolved object is assigned to `channel+0x06` through `0x92220`.

The exact bank-byte order can be switched by global `obj1+0x3F184`; therefore a
modern rehost should preserve the two raw bank bytes and use the original lookup
rather than hard-code a GM bank interpretation.

### Program database record layout and lookup

Normal lookup `0x91F60` reveals the following database shape:

```text
db + 0x00  DWORD record count
...
db + 0x0C  first 24-byte record
record stride = 0x18
record + 0x04  DWORD pointer to a program object
```

The comparison key ultimately comes from `programObject+0xA0`. The engine
combines global namespace `obj1+0x3C514` with the channel patch key:

```c
wanted = (programNamespace << 21) | channelPatchKey;
```

The normal lookup also performs bank fallbacks rather than simply returning
NULL after the first miss. This is another reason to keep the original lookup
code alive in the 32-bit rehost instead of replacing it with a simplistic GM
array.

### Note On (`0xA4BD0`)

The central Note-On routine can now be described as:

```c
Voice *NoteOn(uint32_t packedMidi, Channel *ch,
              uint16_t note, uint16_t velocity)
{
    if (gProgramDatabase == NULL)
        return NULL;

    if (ch->noteOnGate != 0)
        return NULL;

    if (velocity == 0) {
        NoteOff(...);
        return NULL;
    }

    Program *program = ch->resolvedProgram;     // +0x06
    if (program == NULL)
        return NULL;

    if (program->readyByte_at_0x10 == 0) {
        QueueDelayedMidi(packedMidi);
        return NULL;
    }

    Root *root = *(Root **)((uint8_t *)program + 0x04);
    if (*(uint16_t *)((uint8_t *)root + 0x04) == 2)
        return SpecialVoiceFactory(packedMidi, *(void **)(root + 0xEC));

    return GenericVoiceFactory(packedMidi, ch, root, 0);
}
```

`program+0x10` is described as a readiness/validity byte because its exact
source name is not available. Its behavior is clear: zero causes the original
packed event to be deferred rather than discarded.

### Delayed MIDI queue

The deferred-event store is a fixed **128-DWORD** table at approximately
`obj1+0x3F648..0x3F847`, with an associated indicator around `obj1+0x3F848`.

Mapped helpers include:

```text
0xB05F0  insert first free packed event
0xB0630  pop first nonzero event
0xB0680  clear delayed event(s) by channel + note
0xB06D0  clear delayed event(s) by channel
```

Engine/render paths periodically pop these events and feed them back through the
central MIDI decoder `0xA66B0`. A still-unready program can therefore requeue
its event.

This gives a rehost a useful diagnostic distinction:

1. no database pointer -> service-17 / program-database handoff failed;
2. database present but `channel+0x06 == 0` -> bank/program lookup failed;
3. program present but `program+0x10 == 0` -> program/resource has not become
   ready and Note On is being deferred;
4. program ready but voice constructor returns NULL -> voice allocation/model
   construction failed.

## Voice/model allocation

### Generic factory (`0xA4720`)

The generic factory obtains the program/root's collection at `root+0xEC`. The
collection includes:

```text
collection + 0x04  DWORD synthesis-model/type index
collection + 0x0A  WORD  layer count
collection + 0x10  DWORD pointer to layer-record array
```

Layer selection checks key/velocity ranges and several mono/exclusive fields.
Each selected layer is passed to a constructor selected from the table at
`obj1+0x3BDBC`. A successful constructor returns a runtime voice and the engine
stores the selected type at `voice+0x10`.

The common constructor helper `0x884A0` allocates/links a runtime voice into the
active voice list, associates it with the current channel/program, stores note
and velocity, and initializes common pitch/tuning state.

### Named synthesis-model dispatch table

The binary stores a parallel name table beside the constructor pointers, which
makes the first 30 model slots directly nameable:

| Type | Name | Constructor |
|---:|---|---:|
| 0 | Analog | `0x6E740` |
| 1 | SimpleMallet | `0x41530` |
| 2 | NylonGuitar | `0x42E40` |
| 3 | DistortedGuitar | `0x44A20` |
| 4 | Tonal | `0x46F20` |
| 5 | Contrabass | `0x490F0` |
| 6 | Clarinet | `0x4B920` |
| 7 | FluteLike | `0xA2670` |
| 8 | Plucked | `0x4D170` |
| 9 | Impulse | `0x4ECC0` |
| 10 | CoupledString | `0x50960` |
| 11 | Modal | `0x530B0` |
| 12 | Marimba | `0x551A0` |
| 13 | TibetBells | `0x57320` |
| 14 | WindChimes | `0x59520` |
| 15 | TubularBells | `0x5B780` |
| 16 | unused/null | `0` |
| 17 | DoublePluck | `0x5D730` |
| 18 | Vibes | `0x60600` |
| 19 | Percussion | `0x62AE0` |
| 20 | SquareWave | `0xA15E0` |
| 21 | Charang | `0xA0440` |
| 22 | DeltaString | `0x651C0` |
| 23 | BassSyn | `0x9F660` |
| 24 | CCvoc2 | `0x9E720` |
| 25 | CCvoc3 | `0x9D0B0` |
| 26 | Epiano | `0x6C8D0` |
| 27 | Bass | `0x9BDA0` |
| 28 | PhysicalVoice | `0x72690` |
| 29 | BowedString | `0x68670` |

This establishes that the program database selects Reality's actual synthesis
algorithms; it is not merely a sample-patch table.

### Special root-type-2 factory (`0xABC90`)

When the root type word is 2, Note On takes a separate constructor path. It
selects a region through `0xABAB0`, calls common allocator `0x884A0` with flag
`0x20000000`, and installs a family of callbacks in the created voice. This is
kept distinct from synthesis model 28 (`PhysicalVoice`); there is not enough
symbol information to claim that root type 2 and the named PhysicalVoice model
are the same concept.
