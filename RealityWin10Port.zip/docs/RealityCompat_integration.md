# RealityCompat integration plan for the original SSYNENG engine

This file is aimed at the existing 32-bit RealityWin10Port / RealityCompat
rehost. It is intentionally different from the clean `SSynEng64` transport
rewrite: **the shortest route to a working original Reality synth is to keep the
original SSYNENG core executing in the 32-bit Reality process.**

Why: SSYNENG's program database, channels, layers and runtime voices contain raw
32-bit pointers. A true x64 synth-core port requires converting/reconstructing
all of those structures plus every synthesis constructor/DSP routine. The
current x86 in-process rehost can preserve those pointers and execute the
original algorithms while modern code replaces only VMM/ring-0/audio/WinMM
boundaries.

## Required lifecycle order

Do not stub the following PM-API services when the original-engine backend is
selected:

```text
AX=0001  core/PM startup (special path to 0x8EC00 when core is absent)
AX=0003  engine/output start; initializes channel runtime and opens audio
AX=0011  control-state transfer, including program-database registration
AX=000A  ordinary MIDI/synth reset
AX=000B  full GM/GS reset/reinit
AX=0004  stop/teardown
```

Service 17 must be passed a real, writable legacy state block. In SET mode,
when `mask[2] & 1` is present, `state+0x53C` must reach the original
`SetProgramDatabase` path. Do not merely acknowledge the request.

## Add this diagnostic before service 17 is dispatched

The following is representative x86 C++ for RealityCompat. The exact logger and
object-base accessors should be replaced with the project's existing helpers.

```cpp
static uint32_t U32(const void* p) {
    uint32_t v;
    memcpy(&v, p, sizeof(v));
    return v;
}

void TraceSsynService17(void* legacyState, size_t cb) {
    if (!legacyState || cb < 0x540) return;
    auto* b = static_cast<uint8_t*>(legacyState);
    const uint32_t* m = reinterpret_cast<const uint32_t*>(b);

    const bool query = (m[0] & 1u) != 0;
    Log("SSYN S17 %s masks=%08X %08X %08X %08X %08X %08X %08X %08X",
        query ? "GET" : "SET",
        m[0],m[1],m[2],m[3],m[4],m[5],m[6],m[7]);

    if (!query && (m[2] & 0x00000001u)) {
        Log("SSYN S17 SET programDb=%08X", U32(b + 0x53C));
    }
}
```

Do **not** use `mask[1] bit0` for the database. The correct selector is
`mask[2] bit0` / overall bit 64.

## Verify the original engine accepted the database

After the original service 17 returns, read the relocated VxD object's globals
through the rehost's object-1 base:

```text
object1 + 0x3C510   internal current program DB pointer
object1 + 0x3C514   program namespace/prefix
object1 + 0x208A0   16-channel block pointer
object1 + 0x2A5C4   main engine-state pointer
```

All pointer dereferences in diagnostics should be guarded with `VirtualQuery`
or the port's existing pointer validator.

For each channel:

```cpp
uint8_t* ch = channels + index * 0x7A4;
channelIndex = *(uint16_t*)(ch + 0x000);
patchKey     = *(uint32_t*)(ch + 0x002);
program      = *(uint32_t*)(ch + 0x006);
programNo    = *(uint8_t *)(ch + 0x276);
noteGate     = *(uint16_t*)(ch + 0x7A2);
ready        = program ? *(uint8_t*)(program + 0x10) : 0;
root         = program ? *(uint32_t*)(program + 0x04) : 0;
```

A useful startup diagnostic is therefore:

```text
SSYN DB internal=XXXXXXXX channels=XXXXXXXX prefix=XXXXXXXX
CH00 key=XXXXXXXX prog=XXXXXXXX ready=1 root=XXXXXXXX gate=0
...
```

Expected healthy condition before a Note On:

- internal DB != 0;
- channel block != 0;
- channel 0 `program != 0` (or at least the channel being played);
- `ready != 0`;
- `gate == 0`.

## First deterministic MIDI smoke test

For the first test, bypass UI device-selection ambiguity but keep SSYNENG's
normal realtime path: enqueue packed MIDI into the same mapped 512 x 8-byte ring
used by SSYNMIDI, rather than calling the internal Note-On handler directly.

Use:

```text
0x000000C0   Program Change ch0 -> program 0
0x00643C90   Note On ch0, note 60, velocity 100
0x00003C80   Note Off ch0, note 60, velocity 0
```

The engine's own consumer should dequeue these and call the central decoder at
`0xA66B0`. Calling `0xA4BD0` directly is useful only as a debugger experiment;
it bypasses queue/timing semantics.

## If MIDI arrives but no voice appears

Debug in this exact order:

```text
1. obj1+0x3C510 == 0
   -> service-17 program database handoff is missing/broken.

2. channel+0x06 == 0
   -> database is present but current bank/program lookup did not resolve.
      Inspect channel+0x02 and namespace obj1+0x3C514.

3. program+0x10 == 0
   -> program/resource is not ready. The Note On should enter the 128-entry
      delayed-event queue, not disappear.

4. program ready, but generic/special constructor returns NULL
   -> runtime voice allocation/model construction failed. Inspect engine state,
      active-voice allocation and the selected model constructor.

5. non-NULL voice exists but output is silent
   -> only then move downstream to render scheduling / DirectSound buffer fill.
```

This ordering prevents spending time on DirectSound when the synth has not yet
constructed a voice.

## Suggested breakpoints / trace hooks

Useful original-engine offsets relative to rehost object 1:

```text
0x922E0  SetProgramDatabase
0xA5820  Program Change
0xA4BD0  Note On
0xA4720  generic voice/layer/model allocator
0x884A0  common runtime-voice allocator
0xABC90  special root-type-2 voice factory
0xA66B0  central packed-MIDI decoder
0xB05F0  delayed MIDI insert
0xB0630  delayed MIDI pop
```

At Note On, log the database pointer, channel pointer, `channel+0x06`,
`program+0x10`, and the constructor return value. One test note then tells you
which subsystem is still missing.

## Audio side

Do not replace the original synth's rendered audio with `SSynEng64` while trying
to make the original engine work. Let the existing RealityCompat audio shim
continue to satisfy SSYNENG's backend callbacks/DirectSound objects. Once the
original engine is demonstrably returning non-NULL voices, verify that the
existing output buffer continues to Play/Lock/Unlock and that its contents are
changing.

`SSynEng64` remains useful as a clean future x64 boundary and for SynCapt64, but
it is not a substitute for the original DSP core in the current port.

## What would be needed for a true 64-bit synth port

A real x64 rewrite of the complete synth would additionally require:

- 64-bit-safe program/database/channel/layer/voice representations;
- conversion of all raw pointer fields;
- ports of the 30 named model constructors and their render callbacks;
- voice-list and allocator logic;
- scheduler/timer replacement;
- MIDI delayed-event/resource readiness machinery;
- audio render/mixer/effects path.

That is feasible incrementally, but it is a separate project from getting the
current Reality executable operational on modern Windows.

### Correction from the first clean Windows run

The first v1 diagnostic incorrectly assumed SynMid must always send service-17 bit 64. The original VxD exposes the same `SetProgramDatabase` routine (`0x922E0`) through IOCTL `0x4001`; command 41 is bit 65 and is not a substitute. A healthy run may use either real database-install path. The same run also showed SynMid had already created/started the modern DirectSound buffer and registered it through `0x7002`, while the old Win9x `B6E90` callback table was absent. v2 therefore treats `0x7002` as the normal NT transport and reserves `B6E90` for an opt-in diagnostic.


## v6: reconstructing the missing program-database handoff

The v5 trace proves the MIDI ring is writable and the engine/output lifecycle is
running, yet the original global DB (`obj1+0x3C510`) remains NULL.  Meanwhile the
client repeatedly sends service-17 bit 65 / command `0x41`.

The recovered original service-17 code uses command 0x41 as follows:

```text
state+0x540  DWORD program/root pointer
state+0x554  WORD  1-based channel hint (0 = no direct channel bind)
```

With a nonzero channel hint it calls original helper `0x92250(root, channel)`,
which searches the installed DB for a 0x18-byte record whose `record+0x04`
equals `root`, then stores that record at `channel+0x06`.  The missing piece on
NT is therefore the small DB wrapper table, not the already-created program/root
objects.

v6 collects those exact command-41 roots, reads each root's original packed key
at `root+0xA0`, reconstructs only the wrapper records (`count` at DB+0, records
at DB+0x0C, stride 0x18, root at record+4, ready byte at record+0x10), derives
the high namespace used by original lookup, and installs the result through the
real `SetProgramDatabase` routine at `0x922E0`.  It then forwards the untouched
command-41 state to original service 17 so the original binder runs normally.

A later genuine service-17 bit-64 or IOCTL-4001 DB supersedes the fallback.
