# Distributed under the OSI-approved BSD 3-Clause License.  See accompanying
# file LICENSE.rst or https://cmake.org/licensing for details.

cmake_minimum_required(VERSION ${CMAKE_VERSION}) # this file comes with cmake

# If CMAKE_DISABLE_SOURCE_CHANGES is set to true and the source directory is an
# existing directory in our source tree, calling file(MAKE_DIRECTORY) on it
# would cause a fatal error, even though it would be a no-op.
if(NOT EXISTS "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-src")
  file(MAKE_DIRECTORY "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-src")
endif()
file(MAKE_DIRECTORY
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-build"
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix"
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/tmp"
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/src/clap_sdk-populate-stamp"
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/src"
  "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/src/clap_sdk-populate-stamp"
)

set(configSubDirs Debug)
foreach(subDir IN LISTS configSubDirs)
    file(MAKE_DIRECTORY "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/src/clap_sdk-populate-stamp/${subDir}")
endforeach()
if(cfgdir)
  file(MAKE_DIRECTORY "C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-subbuild/clap_sdk-populate-prefix/src/clap_sdk-populate-stamp${cfgdir}") # cfgdir has leading slash
endif()
