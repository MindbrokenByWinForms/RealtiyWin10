# CMake generated Testfile for 
# Source directory: C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-src
# Build directory: C:/Users/Admin/Downloads/RealityWin10Port_v13_19c_CLAP_SPLASH_FIX/clap/build64/_deps/clap_sdk-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
