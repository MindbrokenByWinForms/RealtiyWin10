#include "bridge_client.h"
#include <algorithm>
#include <cwchar>
#include <cstring>
#include <iterator>
#include <vector>

using namespace reality::clapbridge;

namespace {
std::wstring quote(const std::wstring& value) {
    return L"\"" + value + L"\"";
}

bool pathIsAbsolute(const std::wstring& p) {
    return p.size() >= 2 && ((p[1] == L':') || (p[0] == L'\\' && p[1] == L'\\'));
}

bool ieqPrefix(const std::wstring& s, const std::wstring& key) {
    if (s.size() < key.size()) return false;
    return _wcsnicmp(s.c_str(), key.c_str(), key.size()) == 0;
}
} // namespace

RealityBridgeClient::~RealityBridgeClient() {
    stop();
}

std::wstring RealityBridgeClient::directoryOf(const std::wstring& path) {
    const auto p = path.find_last_of(L"\\/");
    return p == std::wstring::npos ? L"." : path.substr(0, p);
}

std::wstring RealityBridgeClient::utf8ToWide(const char* text) {
    if (!text || !*text) return {};
    const int n = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (n <= 1) return {};
    std::wstring out(static_cast<std::size_t>(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, out.data(), n);
    out.resize(static_cast<std::size_t>(n - 1));
    return out;
}

std::wstring RealityBridgeClient::expandPath(const std::wstring& value, const std::wstring& baseDir) {
    if (value.empty()) return value;
    wchar_t expanded[32768]{};
    DWORD n = ExpandEnvironmentStringsW(value.c_str(), expanded, static_cast<DWORD>(std::size(expanded)));
    std::wstring out = (n && n < std::size(expanded)) ? expanded : value;
    if (!pathIsAbsolute(out)) {
        if (!baseDir.empty() && baseDir.back() != L'\\' && baseDir.back() != L'/') out = baseDir + L"\\" + out;
        else out = baseDir + out;
    }
    wchar_t full[32768]{};
    n = GetFullPathNameW(out.c_str(), static_cast<DWORD>(std::size(full)), full, nullptr);
    return (n && n < std::size(full)) ? std::wstring(full) : out;
}

RealityBridgeClient::Config RealityBridgeClient::loadConfig(const std::wstring& iniPath,
                                                              const std::wstring& pluginDir) {
    Config cfg{};
    auto get = [&](const wchar_t* key, const wchar_t* fallback) {
        wchar_t buf[32768]{};
        GetPrivateProfileStringW(L"Reality", key, fallback, buf, static_cast<DWORD>(std::size(buf)), iniPath.c_str());
        return std::wstring(buf);
    };

    cfg.launcher = expandPath(get(L"Launcher", L"RealityRuntime\\RealityPortLauncher.exe"), pluginDir);
    cfg.realityExe = expandPath(get(L"RealityExe", L"RealityRuntime\\Reality.exe"), pluginDir);
    cfg.banksets = expandPath(get(L"Banksets", L"RealityRuntime\\Banksets"), pluginDir);
    cfg.logging = GetPrivateProfileIntW(L"Reality", L"Logging", 0, iniPath.c_str()) != 0;
    cfg.muteDirectSound = GetPrivateProfileIntW(L"Reality", L"MuteDirectSound", 1, iniPath.c_str()) != 0;
    return cfg;
}

std::vector<wchar_t> RealityBridgeClient::buildEnvironment(const Config& cfg,
                                                            const std::wstring& bridgeName) {
    std::vector<std::wstring> vars;
    if (LPWCH env = GetEnvironmentStringsW()) {
        for (const wchar_t* p = env; *p; p += std::wcslen(p) + 1) vars.emplace_back(p);
        FreeEnvironmentStringsW(env);
    }

    const std::wstring managed[] = {
        L"REALITY_CLAP_BRIDGE_NAME=", L"REALITY_CLAP_MUTE_DS=", L"REALITY_CREATE_LOG=",
        L"REALITY_BANKSETS=", L"REALITY_HOST_ENGINE_PUMP=", L"REALITY_UI_PROBE=",
        L"REALITY_UI_FORCE_ENABLE=", L"REALITY_SYNTH_BRUTEFORCE=", L"REALITY_SYNTH_PROBE=",
        L"REALITY_VOICE_TRACE=", L"REALITY_SEQ_UI_MIRROR="
    };
    vars.erase(std::remove_if(vars.begin(), vars.end(), [&](const std::wstring& v) {
        for (const auto& key : managed) if (ieqPrefix(v, key)) return true;
        return false;
    }), vars.end());

    vars.emplace_back(L"REALITY_CLAP_BRIDGE_NAME=" + bridgeName);
    vars.emplace_back(std::wstring(L"REALITY_CLAP_MUTE_DS=") + (cfg.muteDirectSound ? L"1" : L"0"));
    vars.emplace_back(std::wstring(L"REALITY_CREATE_LOG=") + (cfg.logging ? L"1" : L"0"));
    if (!cfg.banksets.empty()) vars.emplace_back(L"REALITY_BANKSETS=" + cfg.banksets);
    vars.emplace_back(L"REALITY_HOST_ENGINE_PUMP=1");
    vars.emplace_back(L"REALITY_UI_PROBE=1");
    vars.emplace_back(L"REALITY_UI_FORCE_ENABLE=1");
    vars.emplace_back(L"REALITY_SYNTH_BRUTEFORCE=");
    vars.emplace_back(L"REALITY_SYNTH_PROBE=");
    vars.emplace_back(L"REALITY_VOICE_TRACE=0");
    vars.emplace_back(L"REALITY_SEQ_UI_MIRROR=0");

    std::sort(vars.begin(), vars.end(), [](const std::wstring& a, const std::wstring& b) {
        return _wcsicmp(a.c_str(), b.c_str()) < 0;
    });

    std::size_t chars = 1;
    for (const auto& v : vars) chars += v.size() + 1;
    std::vector<wchar_t> block(chars, L'\0');
    wchar_t* dst = block.data();
    for (const auto& v : vars) {
        std::memcpy(dst, v.c_str(), v.size() * sizeof(wchar_t));
        dst += v.size() + 1;
    }
    *dst = L'\0';
    return block;
}

bool RealityBridgeClient::start(const std::wstring& pluginPath) {
    if (state_) return true;
    lastError_.clear();
    const std::wstring pluginDir = directoryOf(pluginPath);
    configPath_ = pluginDir + L"\\RealityCLAP.ini";
    const Config cfg = loadConfig(configPath_, pluginDir);

    if (GetFileAttributesW(cfg.launcher.c_str()) == INVALID_FILE_ATTRIBUTES) {
        lastError_ = L"RealityPortLauncher.exe not found: " + cfg.launcher;
        return false;
    }
    if (GetFileAttributesW(cfg.realityExe.c_str()) == INVALID_FILE_ATTRIBUTES) {
        lastError_ = L"Reality.exe not found: " + cfg.realityExe;
        return false;
    }

    wchar_t name[256]{};
    swprintf_s(name, std::size(name), L"Local\\RealityCLAP_%lu_%p", GetCurrentProcessId(), this);
    bridgeName_ = name;

    mapping_ = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0,
                                  static_cast<DWORD>(sizeof(SharedState)), bridgeName_.c_str());
    if (!mapping_) {
        lastError_ = L"CreateFileMapping failed: " + std::to_wstring(GetLastError());
        return false;
    }
    state_ = static_cast<SharedState*>(MapViewOfFile(mapping_, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(SharedState)));
    if (!state_) {
        lastError_ = L"MapViewOfFile failed: " + std::to_wstring(GetLastError());
        closeMapping();
        return false;
    }

    std::memset(state_, 0, sizeof(*state_));
    state_->magic = kBridgeMagic;
    state_->version = kBridgeVersion;
    state_->structBytes = static_cast<std::uint32_t>(sizeof(SharedState));
    state_->sampleRate = 44100;
    state_->channels = 2;
    state_->bitsPerSample = 16;

    if (!launch(cfg)) {
        closeMapping();
        return false;
    }
    return true;
}

bool RealityBridgeClient::launch(const Config& cfg) {
    std::wstring cmd = quote(cfg.launcher) + L" --rehost " + quote(cfg.realityExe);
    std::vector<wchar_t> mutableCmd(cmd.begin(), cmd.end());
    mutableCmd.push_back(L'\0');
    auto env = buildEnvironment(cfg, bridgeName_);

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    const std::wstring cwd = directoryOf(cfg.launcher);
    const DWORD flags = CREATE_UNICODE_ENVIRONMENT | CREATE_NO_WINDOW;
    if (!CreateProcessW(cfg.launcher.c_str(), mutableCmd.data(), nullptr, nullptr, FALSE,
                        flags, env.data(), cwd.c_str(), &si, &pi)) {
        lastError_ = L"CreateProcess(RealityPortLauncher) failed: " + std::to_wstring(GetLastError());
        return false;
    }
    launcherPid_ = pi.dwProcessId;
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;
}

void RealityBridgeClient::requestShutdown() {
    if (state_) InterlockedExchange(&state_->shutdownRequested, 1);
}

void RealityBridgeClient::stop() {
    if (!state_) return;
    requestShutdown();

    const DWORD pid = enginePid();
    if (pid) {
        HANDLE process = OpenProcess(SYNCHRONIZE | PROCESS_TERMINATE, FALSE, pid);
        if (process) {
            const DWORD wr = WaitForSingleObject(process, 1200);
            if (wr == WAIT_TIMEOUT) TerminateProcess(process, 0);
            CloseHandle(process);
        }
    }
    closeMapping();
}

void RealityBridgeClient::closeMapping() {
    if (state_) {
        UnmapViewOfFile(state_);
        state_ = nullptr;
    }
    if (mapping_) {
        CloseHandle(mapping_);
        mapping_ = nullptr;
    }
}

bool RealityBridgeClient::ready() const {
    return state_ && (LoadCounter(&state_->readyFlags) & kReadyEngine) != 0u;
}

bool RealityBridgeClient::audioReady() const {
    return state_ && (LoadCounter(&state_->readyFlags) & kReadyAudio) != 0u;
}

DWORD RealityBridgeClient::enginePid() const {
    return state_ ? static_cast<DWORD>(LoadCounter(&state_->enginePid)) : 0u;
}

bool RealityBridgeClient::pushMidi(std::uint32_t packedMessage, std::uint32_t timestampMs) {
    if (!state_) return false;
    const std::uint32_t write = LoadCounter(&state_->midiWriteEvent);
    const std::uint32_t read = LoadCounter(&state_->midiReadEvent);
    if (write - read >= kMidiCapacityEvents) {
        InterlockedIncrement(&state_->midiOverruns);
        return false;
    }
    const std::uint32_t slot = write % kMidiCapacityEvents;
    state_->midi[slot].packedMessage = packedMessage & 0x00ffffffu;
    state_->midi[slot].timestampMs = timestampMs;
    MemoryBarrier();
    StoreCounter(&state_->midiWriteEvent, write + 1u);
    return true;
}

std::uint32_t RealityBridgeClient::availableAudioFrames() const {
    if (!state_) return 0u;
    const std::uint32_t write = LoadCounter(&state_->audioWriteFrame);
    const std::uint32_t read = LoadCounter(&state_->audioReadFrame);
    const std::uint32_t available = write - read;
    return std::min<std::uint32_t>(available, kAudioCapacityFrames);
}

bool RealityBridgeClient::trimAudioBacklog(std::uint32_t targetFrames) {
    if (!state_) return false;
    targetFrames = std::min<std::uint32_t>(targetFrames, kAudioCapacityFrames / 2u);
    const std::uint32_t write = LoadCounter(&state_->audioWriteFrame);
    const std::uint32_t read = LoadCounter(&state_->audioReadFrame);
    const std::uint32_t available = write - read;
    if (available <= targetFrames + 512u) return false;
    StoreCounter(&state_->audioReadFrame, write - targetFrames);
    return true;
}

bool RealityBridgeClient::readAudioFrame(float& left, float& right) {
    left = right = 0.0f;
    if (!state_) return false;
    const std::uint32_t read = LoadCounter(&state_->audioReadFrame);
    const std::uint32_t write = LoadCounter(&state_->audioWriteFrame);
    if (read == write) {
        InterlockedIncrement(&state_->audioUnderruns);
        return false;
    }
    const std::uint32_t slot = read % kAudioCapacityFrames;
    MemoryBarrier();
    left = static_cast<float>(state_->audio[slot * 2u + 0u]) / 32768.0f;
    right = static_cast<float>(state_->audio[slot * 2u + 1u]) / 32768.0f;
    StoreCounter(&state_->audioReadFrame, read + 1u);
    return true;
}

std::uint32_t RealityBridgeClient::engineRate() const {
    if (!state_) return 44100u;
    const auto rate = LoadCounter(&state_->sampleRate);
    return rate >= 8000u && rate <= 192000u ? rate : 44100u;
}
