#pragma once

#include <windows.h>
#include <cstdint>
#include <string>
#include <vector>
#include "../../src/bridge/reality_clap_bridge_shared.h"

class RealityBridgeClient {
public:
    RealityBridgeClient() = default;
    ~RealityBridgeClient();

    bool start(const std::wstring& pluginPath);
    void requestShutdown();
    void stop();

    bool ready() const;
    bool audioReady() const;
    DWORD enginePid() const;

    bool pushMidi(std::uint32_t packedMessage, std::uint32_t timestampMs);
    bool readAudioFrame(float& left, float& right);
    std::uint32_t availableAudioFrames() const;
    bool trimAudioBacklog(std::uint32_t targetFrames);

    std::uint32_t engineRate() const;
    std::wstring configPath() const { return configPath_; }
    const std::wstring& lastError() const { return lastError_; }
    static std::wstring utf8ToWide(const char* text);

private:
    struct Config {
        std::wstring launcher;
        std::wstring realityExe;
        std::wstring banksets;
        bool logging = false;
        bool muteDirectSound = true;
    };

    static std::wstring directoryOf(const std::wstring& path);
    static std::wstring expandPath(const std::wstring& value, const std::wstring& baseDir);
    static Config loadConfig(const std::wstring& iniPath, const std::wstring& pluginDir);
    static std::vector<wchar_t> buildEnvironment(const Config& cfg, const std::wstring& bridgeName);

    bool launch(const Config& cfg);
    void closeMapping();

    HANDLE mapping_ = nullptr;
    reality::clapbridge::SharedState* state_ = nullptr;
    std::wstring bridgeName_;
    std::wstring configPath_;
    std::wstring lastError_;
    DWORD launcherPid_ = 0;
};
