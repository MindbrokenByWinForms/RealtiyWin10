#include <clap/clap.h>
#include "bridge_client.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <new>
#include <string>
#include <cstdint>
#include <cwchar>
#include <iterator>

namespace {

static std::wstring gPluginPath;
static volatile LONG gEntryRefs = 0;
static constexpr std::uint32_t kTargetEngineLatencyFrames = 2048u;
static constexpr UINT_PTR kGuiAttachTimerId = 0x5245414Cu; // 'REAL'
static constexpr UINT kGuiAttachTimerMs = 150u;
static constexpr wchar_t kGuiWindowClass[] = L"RealityCLAP.FixedContainer.v13_19c";
static constexpr std::uint32_t kDefaultGuiWidth = 800u;
static constexpr std::uint32_t kDefaultGuiHeight = 600u;

struct Plugin;
struct FindRealityWindowCtx { DWORD pid; HWND best; int score; };
LRESULT CALLBACK RealityContainerWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

std::string wideToUtf8(const std::wstring& text) {
    if (text.empty()) return {};
    const int n = WideCharToMultiByte(CP_UTF8, 0, text.c_str(), static_cast<int>(text.size()),
                                      nullptr, 0, nullptr, nullptr);
    if (n <= 0) return {};
    std::string out(static_cast<std::size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, text.c_str(), static_cast<int>(text.size()),
                        out.data(), n, nullptr, nullptr);
    return out;
}

static const char *const kFeatures[] = {
    CLAP_PLUGIN_FEATURE_INSTRUMENT,
    CLAP_PLUGIN_FEATURE_SYNTHESIZER,
    CLAP_PLUGIN_FEATURE_STEREO,
    nullptr
};

clap_plugin_descriptor_t MakeDescriptor() {
    clap_plugin_descriptor_t d{};
    d.clap_version = CLAP_VERSION_INIT;
    d.id = "com.seersystems.reality.rehost";
    d.name = "Seer Systems Reality (Rehost)";
    d.vendor = "Seer Systems / community rehost";
    d.url = "";
    d.manual_url = "";
    d.support_url = "";
    d.version = "0.2.1-alpha";
    d.description = "CLAP bridge for the recovered 32-bit Seer Systems Reality engine with fixed embedded UI";
    d.features = kFeatures;
    return d;
}

static const clap_plugin_descriptor_t kDescriptor = MakeDescriptor();

struct Plugin {
    clap_plugin_t clap{};
    const clap_host_t* host = nullptr;
    const clap_host_log_t* hostLog = nullptr;
    RealityBridgeClient bridge;
    const clap_host_gui_t* hostGui = nullptr;
    double sampleRate = 44100.0;
    bool activated = false;

    HWND guiHwnd = nullptr;
    HWND guiHostParent = nullptr;
    HWND realityHwnd = nullptr;
    HWND realityOriginalParent = nullptr;
    LONG_PTR realityOriginalStyle = 0;
    LONG_PTR realityOriginalExStyle = 0;
    RECT realityOriginalRect{};
    bool realityOriginalCaptured = false;
    bool guiCreated = false;
    bool guiVisible = false;
    bool guiMeasuredFromReality = false;
    bool guiResizeRequested = false;
    bool realityEmbedded = false;
    bool embedFailedForWindow = false;
    std::uint32_t guiWidth = kDefaultGuiWidth;
    std::uint32_t guiHeight = kDefaultGuiHeight;

    double phase = 0.0;
    float aL = 0.0f, aR = 0.0f, bL = 0.0f, bR = 0.0f;
    bool haveA = false, haveB = false;

    void log(clap_log_severity severity, const std::string& text) const {
        if (hostLog && hostLog->log) hostLog->log(host, severity, text.c_str());
    }

    bool ensureBridgeStarted() {
        if (bridge.ready()) return true;
        if (bridge.start(gPluginPath)) return true;
        log(CLAP_LOG_ERROR, "Reality CLAP could not start the sidecar: " + wideToUtf8(bridge.lastError()));
        return false;
    }

    void loadGuiFallbackSize() {
        const std::wstring ini = bridge.configPath();
        if (ini.empty()) return;
        int w = GetPrivateProfileIntW(L"Reality", L"GuiFallbackWidth",
                                      static_cast<int>(kDefaultGuiWidth), ini.c_str());
        int h = GetPrivateProfileIntW(L"Reality", L"GuiFallbackHeight",
                                      static_cast<int>(kDefaultGuiHeight), ini.c_str());
        if (w >= 320 && w <= 4096) guiWidth = static_cast<std::uint32_t>(w);
        if (h >= 240 && h <= 4096) guiHeight = static_cast<std::uint32_t>(h);
    }

    static BOOL CALLBACK findRealityWindowProc(HWND hwnd, LPARAM param) {
        auto* ctx = reinterpret_cast<FindRealityWindowCtx*>(param);
        DWORD pid = 0;
        GetWindowThreadProcessId(hwnd, &pid);
        if (pid != ctx->pid) return TRUE;
        if ((GetWindowLongPtrW(hwnd, GWL_STYLE) & WS_CHILD) != 0) return TRUE;

        wchar_t cls[128]{};
        wchar_t title[256]{};
        GetClassNameW(hwnd, cls, static_cast<int>(std::size(cls)));
        GetWindowTextW(hwnd, title, static_cast<int>(std::size(title)));

        // Reality shows a splash/dialog first (class #32770, title "Reality").
        // Never accept a window merely because its title contains "Reality": if that
        // startup HWND is reparented it may stay alive but hidden, leaving the plugin
        // container permanently white after the real main window appears.
        // The actual application frame is consistently classed "Reality GUI".
        if (_wcsicmp(cls, L"Reality GUI") != 0) return TRUE;
        if (GetWindow(hwnd, GW_OWNER) != nullptr) return TRUE;

        RECT client{};
        if (!GetClientRect(hwnd, &client)) return TRUE;
        const LONG width = client.right - client.left;
        const LONG height = client.bottom - client.top;
        if (width < 320 || height < 240 || width > 4096 || height > 4096) return TRUE;

        // Exact-class match only. Visibility/enabled state is deliberately not required:
        // Reality creates the genuine main frame before it is fully enabled.
        ctx->score = 1000;
        ctx->best = hwnd;
        return FALSE;
        return TRUE;
    }

    HWND findRealityWindow() const {
        const DWORD pid = bridge.enginePid();
        if (!pid) return nullptr;
        FindRealityWindowCtx ctx{pid, nullptr, -1};
        EnumWindows(findRealityWindowProc, reinterpret_cast<LPARAM>(&ctx));
        return ctx.score >= 1000 ? ctx.best : nullptr;
    }

    void requestMeasuredGuiSize() {
        if (!guiMeasuredFromReality || guiResizeRequested || !guiHostParent) return;
        guiResizeRequested = true;
        if (guiHwnd) {
            SetWindowPos(guiHwnd, nullptr, 0, 0, static_cast<int>(guiWidth), static_cast<int>(guiHeight),
                         SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
        if (hostGui && hostGui->request_resize) {
            const bool accepted = hostGui->request_resize(host, guiWidth, guiHeight);
            char msg[192]{};
            std::snprintf(msg, sizeof(msg),
                          "Reality GUI embedding: fixed size %ux%u requested from host accepted=%u",
                          guiWidth, guiHeight, accepted ? 1u : 0u);
            log(accepted ? CLAP_LOG_INFO : CLAP_LOG_WARNING, msg);
        }
    }

    bool captureRealityWindow(HWND hwnd) {
        if (!hwnd || !IsWindow(hwnd)) return false;
        if (realityHwnd == hwnd && realityOriginalCaptured) return true;

        realityHwnd = hwnd;
        realityOriginalParent = GetParent(hwnd);
        realityOriginalStyle = GetWindowLongPtrW(hwnd, GWL_STYLE);
        realityOriginalExStyle = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
        GetWindowRect(hwnd, &realityOriginalRect);
        realityOriginalCaptured = true;
        realityEmbedded = false;
        embedFailedForWindow = false;

        RECT client{};
        if (GetClientRect(hwnd, &client)) {
            const LONG w = client.right - client.left;
            const LONG h = client.bottom - client.top;
            if (w >= 320 && h >= 240 && w <= 4096 && h <= 4096) {
                guiWidth = static_cast<std::uint32_t>(w);
                guiHeight = static_cast<std::uint32_t>(h);
                guiMeasuredFromReality = true;
                guiResizeRequested = false;
            }
        }

        wchar_t cls[128]{};
        wchar_t title[256]{};
        GetClassNameW(hwnd, cls, static_cast<int>(std::size(cls)));
        GetWindowTextW(hwnd, title, static_cast<int>(std::size(title)));
        char msg[512]{};
        std::snprintf(msg, sizeof(msg),
                      "Reality GUI embedding: discovered hwnd=%p pid=%lu client=%ux%u class=%s title=%s",
                      hwnd, static_cast<unsigned long>(bridge.enginePid()), guiWidth, guiHeight,
                      wideToUtf8(cls).c_str(), wideToUtf8(title).c_str());
        log(CLAP_LOG_INFO, msg);
        return true;
    }

    bool discoverRealityWindow() {
        if (realityHwnd && IsWindow(realityHwnd)) return true;
        realityHwnd = nullptr;
        realityOriginalCaptured = false;
        realityEmbedded = false;
        const HWND found = findRealityWindow();
        if (!found) return false;
        const bool ok = captureRealityWindow(found);
        if (ok) requestMeasuredGuiSize();
        return ok;
    }

    void sizeEmbeddedReality() {
        if (!realityEmbedded || !realityHwnd || !IsWindow(realityHwnd) || !guiHwnd) return;
        RECT r{};
        GetClientRect(guiHwnd, &r);
        const int w = std::max<LONG>(1, r.right-r.left);
        const int h = std::max<LONG>(1, r.bottom-r.top);
        SetWindowPos(realityHwnd, nullptr, 0, 0, w, h,
                     SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
    }

    void restoreRealityWindow(bool showFloating) {
        if (!realityHwnd || !IsWindow(realityHwnd) || !realityOriginalCaptured) {
            realityEmbedded = false;
            return;
        }
        if (!realityEmbedded) {
            if (showFloating) ShowWindow(realityHwnd, SW_SHOWNORMAL);
            return;
        }

        ShowWindow(realityHwnd, SW_HIDE);
        SetLastError(0);
        SetParent(realityHwnd, realityOriginalParent);
        SetWindowLongPtrW(realityHwnd, GWL_STYLE, realityOriginalStyle);
        SetWindowLongPtrW(realityHwnd, GWL_EXSTYLE, realityOriginalExStyle);
        const int w = std::max<LONG>(1, realityOriginalRect.right - realityOriginalRect.left);
        const int h = std::max<LONG>(1, realityOriginalRect.bottom - realityOriginalRect.top);
        SetWindowPos(realityHwnd, nullptr, realityOriginalRect.left, realityOriginalRect.top, w, h,
                     SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        realityEmbedded = false;
        if (showFloating) ShowWindow(realityHwnd, SW_SHOWNORMAL);
        log(CLAP_LOG_INFO, "Reality GUI embedding: restored Reality main window to top-level state");
    }

    bool tryEmbedReality() {
        if (!guiCreated || !guiHostParent || !guiHwnd) return false;
        if (realityEmbedded && realityHwnd && IsWindow(realityHwnd)) {
            sizeEmbeddedReality();
            return true;
        }
        if (!discoverRealityWindow() || embedFailedForWindow) return false;

        requestMeasuredGuiSize();
        ShowWindow(realityHwnd, SW_HIDE);

        const LONG_PTR childStyle =
            (realityOriginalStyle & ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME |
                                      WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)) |
            WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
        const LONG_PTR childExStyle =
            realityOriginalExStyle & ~(WS_EX_APPWINDOW | WS_EX_WINDOWEDGE | WS_EX_DLGMODALFRAME);

        bool ok = true;
        SetLastError(0);
        if (SetWindowLongPtrW(realityHwnd, GWL_STYLE, childStyle) == 0 && GetLastError() != 0) ok = false;
        SetLastError(0);
        if (ok && SetWindowLongPtrW(realityHwnd, GWL_EXSTYLE, childExStyle) == 0 && GetLastError() != 0) ok = false;
        if (ok) {
            SetLastError(0);
            const HWND previous = SetParent(realityHwnd, guiHwnd);
            if (!previous && GetLastError() != 0) ok = false;
        }

        if (!ok) {
            const DWORD error = GetLastError();
            SetParent(realityHwnd, realityOriginalParent);
            SetWindowLongPtrW(realityHwnd, GWL_STYLE, realityOriginalStyle);
            SetWindowLongPtrW(realityHwnd, GWL_EXSTYLE, realityOriginalExStyle);
            SetWindowPos(realityHwnd, nullptr, realityOriginalRect.left, realityOriginalRect.top,
                         std::max<LONG>(1, realityOriginalRect.right-realityOriginalRect.left),
                         std::max<LONG>(1, realityOriginalRect.bottom-realityOriginalRect.top),
                         SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
            ShowWindow(realityHwnd, SW_SHOWNORMAL);
            embedFailedForWindow = true;
            char msg[192]{};
            std::snprintf(msg, sizeof(msg),
                          "Reality GUI embedding: SetParent/style conversion failed error=%lu; leaving Reality floating",
                          static_cast<unsigned long>(error));
            log(CLAP_LOG_WARNING, msg);
            return false;
        }

        realityEmbedded = true;
        sizeEmbeddedReality();
        if (guiVisible) ShowWindow(realityHwnd, SW_SHOW);
        char msg[192]{};
        std::snprintf(msg, sizeof(msg), "Reality GUI embedding: attached hwnd=%p fixed=%ux%u",
                      realityHwnd, guiWidth, guiHeight);
        log(CLAP_LOG_INFO, msg);
        return true;
    }

    bool ensureGuiWindowClass() {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = RealityContainerWndProc;
        HMODULE module = nullptr;
        GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           reinterpret_cast<LPCWSTR>(&RealityContainerWndProc), &module);
        wc.hInstance = module;
        // Use an explicitly-wide integer resource ID. IDC_ARROW follows the project's
        // UNICODE setting and is LPSTR in this build, while LoadCursorW requires LPCWSTR.
        wc.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
        wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_BTNFACE + 1);
        wc.lpszClassName = kGuiWindowClass;
        if (RegisterClassExW(&wc)) return true;
        return GetLastError() == ERROR_CLASS_ALREADY_EXISTS;
    }

    bool createGui() {
        if (guiCreated) return true;
        if (!ensureBridgeStarted()) return false;
        loadGuiFallbackSize();
        discoverRealityWindow();
        if (!ensureGuiWindowClass()) {
            log(CLAP_LOG_ERROR, "Reality GUI embedding: RegisterClassExW failed");
            return false;
        }

        HMODULE module = nullptr;
        GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                           GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           reinterpret_cast<LPCWSTR>(&RealityContainerWndProc), &module);
        guiHwnd = CreateWindowExW(0, kGuiWindowClass, L"Reality CLAP",
                                  WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
                                  CW_USEDEFAULT, CW_USEDEFAULT,
                                  static_cast<int>(guiWidth), static_cast<int>(guiHeight),
                                  nullptr, nullptr, module, this);
        if (!guiHwnd) {
            log(CLAP_LOG_ERROR, "Reality GUI embedding: CreateWindowExW failed");
            return false;
        }
        guiCreated = true;
        SetTimer(guiHwnd, kGuiAttachTimerId, kGuiAttachTimerMs, nullptr);
        char msg[160]{};
        std::snprintf(msg, sizeof(msg), "Reality GUI embedding: container created fixed=%ux%u",
                      guiWidth, guiHeight);
        log(CLAP_LOG_INFO, msg);
        return true;
    }

    void destroyGui() {
        if (!guiCreated) return;
        if (guiHwnd) KillTimer(guiHwnd, kGuiAttachTimerId);
        restoreRealityWindow(false);
        if (realityHwnd && IsWindow(realityHwnd)) ShowWindow(realityHwnd, SW_HIDE);
        if (guiHwnd && IsWindow(guiHwnd)) DestroyWindow(guiHwnd);
        guiHwnd = nullptr;
        guiHostParent = nullptr;
        guiCreated = false;
        guiVisible = false;
        guiResizeRequested = false;
        guiMeasuredFromReality = false;
        realityHwnd = nullptr;
        realityOriginalCaptured = false;
        embedFailedForWindow = false;
    }

    bool setGuiParent(HWND parent) {
        if (!guiCreated || !guiHwnd || !parent) return false;
        LONG_PTR style = GetWindowLongPtrW(guiHwnd, GWL_STYLE);
        style &= ~WS_POPUP;
        style |= WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;
        SetWindowLongPtrW(guiHwnd, GWL_STYLE, style);
        SetLastError(0);
        const HWND previous = SetParent(guiHwnd, parent);
        if (!previous && GetLastError() != 0) {
            log(CLAP_LOG_ERROR, "Reality GUI embedding: could not parent CLAP container into host HWND");
            return false;
        }
        guiHostParent = parent;
        SetWindowPos(guiHwnd, nullptr, 0, 0, static_cast<int>(guiWidth), static_cast<int>(guiHeight),
                     SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
        tryEmbedReality();
        return true;
    }

    bool showGui() {
        if (!guiCreated || !guiHwnd) return false;
        guiVisible = true;
        tryEmbedReality();
        ShowWindow(guiHwnd, SW_SHOW);
        if (realityHwnd && IsWindow(realityHwnd)) ShowWindow(realityHwnd, SW_SHOW);
        return true;
    }

    bool hideGui() {
        if (!guiCreated || !guiHwnd) return false;
        guiVisible = false;
        if (realityHwnd && IsWindow(realityHwnd)) ShowWindow(realityHwnd, SW_HIDE);
        ShowWindow(guiHwnd, SW_HIDE);
        return true;
    }

    void onGuiTimer() {
        if (!guiCreated) return;
        if (realityHwnd && !IsWindow(realityHwnd)) {
            realityHwnd = nullptr;
            realityOriginalCaptured = false;
            realityEmbedded = false;
            embedFailedForWindow = false;
        }
        if (!realityEmbedded) tryEmbedReality();
        if (realityEmbedded) sizeEmbeddedReality();
    }

    void focusReality() {
        if (realityEmbedded && realityHwnd && IsWindow(realityHwnd) && IsWindowVisible(realityHwnd))
            SetFocus(realityHwnd);
    }

    void resetResampler() {
        phase = 0.0;
        aL = aR = bL = bR = 0.0f;
        haveA = haveB = false;
    }

    bool fillPair() {
        if (!haveA) haveA = bridge.readAudioFrame(aL, aR);
        if (haveA && !haveB) haveB = bridge.readAudioFrame(bL, bR);
        return haveA && haveB;
    }

    void render(float* outL, float* outR, std::uint32_t frames) {
        if (!outL || !outR) return;
        if (bridge.trimAudioBacklog(kTargetEngineLatencyFrames)) resetResampler();

        const double engineRate = static_cast<double>(bridge.engineRate());
        const double step = sampleRate > 1.0 ? engineRate / sampleRate : 1.0;

        for (std::uint32_t i = 0; i < frames; ++i) {
            if (!fillPair()) {
                outL[i] = 0.0f;
                outR[i] = 0.0f;
                continue;
            }

            const float t = static_cast<float>(phase);
            outL[i] = aL + (bL - aL) * t;
            outR[i] = aR + (bR - aR) * t;

            phase += step;
            while (phase >= 1.0 && haveA && haveB) {
                phase -= 1.0;
                aL = bL;
                aR = bR;
                haveA = true;
                haveB = bridge.readAudioFrame(bL, bR);
            }
        }
    }

    void sendMidi(std::uint8_t status, std::uint8_t d1, std::uint8_t d2, std::uint32_t frameOffset) {
        const std::uint32_t msg = static_cast<std::uint32_t>(status) |
                                  (static_cast<std::uint32_t>(d1 & 0x7f) << 8u) |
                                  (static_cast<std::uint32_t>(d2 & 0x7f) << 16u);
        const std::uint32_t now = GetTickCount();
        const std::uint32_t deltaMs = sampleRate > 1.0
            ? static_cast<std::uint32_t>((static_cast<double>(frameOffset) * 1000.0) / sampleRate)
            : 0u;
        bridge.pushMidi(msg, now + deltaMs);
    }

    void handleEvent(const clap_event_header_t* h) {
        if (!h || h->space_id != CLAP_CORE_EVENT_SPACE_ID || !bridge.ready()) return;
        switch (h->type) {
        case CLAP_EVENT_NOTE_ON:
        case CLAP_EVENT_NOTE_OFF:
        case CLAP_EVENT_NOTE_CHOKE: {
            const auto* ev = reinterpret_cast<const clap_event_note_t*>(h);
            if (ev->channel < 0 || ev->channel > 15 || ev->key < 0 || ev->key > 127) return;
            const std::uint8_t ch = static_cast<std::uint8_t>(ev->channel);
            const std::uint8_t key = static_cast<std::uint8_t>(ev->key);
            if (h->type == CLAP_EVENT_NOTE_ON) {
                const int vel = static_cast<int>(std::lround(std::clamp(ev->velocity, 0.0, 1.0) * 127.0));
                sendMidi(static_cast<std::uint8_t>(0x90u | ch), key, static_cast<std::uint8_t>(vel), h->time);
            } else {
                const int vel = h->type == CLAP_EVENT_NOTE_OFF
                    ? static_cast<int>(std::lround(std::clamp(ev->velocity, 0.0, 1.0) * 127.0)) : 0;
                sendMidi(static_cast<std::uint8_t>(0x80u | ch), key, static_cast<std::uint8_t>(vel), h->time);
            }
            break;
        }
        case CLAP_EVENT_MIDI: {
            const auto* ev = reinterpret_cast<const clap_event_midi_t*>(h);
            const std::uint32_t msg = static_cast<std::uint32_t>(ev->data[0]) |
                                      (static_cast<std::uint32_t>(ev->data[1]) << 8u) |
                                      (static_cast<std::uint32_t>(ev->data[2]) << 16u);
            const std::uint32_t now = GetTickCount();
            const std::uint32_t deltaMs = sampleRate > 1.0
                ? static_cast<std::uint32_t>((static_cast<double>(h->time) * 1000.0) / sampleRate) : 0u;
            bridge.pushMidi(msg, now + deltaMs);
            break;
        }
        default:
            break;
        }
    }

    void allNotesOff() {
        for (std::uint8_t ch = 0; ch < 16u; ++ch) {
            sendMidi(static_cast<std::uint8_t>(0xB0u | ch), 123u, 0u, 0u);
            sendMidi(static_cast<std::uint8_t>(0xB0u | ch), 120u, 0u, 0u);
        }
    }
};

Plugin* self(const clap_plugin_t* plugin) {
    return static_cast<Plugin*>(plugin->plugin_data);
}

LRESULT CALLBACK RealityContainerWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    Plugin* p = reinterpret_cast<Plugin*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (msg == WM_NCCREATE) {
        auto* cs = reinterpret_cast<CREATESTRUCTW*>(lp);
        p = static_cast<Plugin*>(cs->lpCreateParams);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(p));
    }
    if (p) {
        switch (msg) {
        case WM_TIMER:
            if (wp == kGuiAttachTimerId) {
                p->onGuiTimer();
                return 0;
            }
            break;
        case WM_SIZE:
            p->sizeEmbeddedReality();
            break;
        case WM_SETFOCUS:
        case WM_MOUSEACTIVATE:
            p->focusReality();
            break;
        default:
            break;
        }
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

bool CLAP_ABI pluginInit(const clap_plugin_t* plugin) {
    auto* p = self(plugin);
    p->hostLog = static_cast<const clap_host_log_t*>(p->host->get_extension(p->host, CLAP_EXT_LOG));
    p->hostGui = static_cast<const clap_host_gui_t*>(p->host->get_extension(p->host, CLAP_EXT_GUI));
    return true;
}

void CLAP_ABI pluginDestroy(const clap_plugin_t* plugin) {
    auto* p = self(plugin);
    p->destroyGui();
    p->bridge.stop();
    delete p;
}

bool CLAP_ABI pluginActivate(const clap_plugin_t* plugin, double sampleRate,
                             std::uint32_t, std::uint32_t) {
    auto* p = self(plugin);
    p->sampleRate = sampleRate;
    p->resetResampler();
    if (!p->ensureBridgeStarted()) return false;
    p->activated = true;
    return true;
}

void CLAP_ABI pluginDeactivate(const clap_plugin_t* plugin) {
    auto* p = self(plugin);
    p->activated = false;
    p->resetResampler();
    // Deliberately keep the x86 Reality sidecar alive across host deactivate /
    // reactivate cycles (sample-rate changes, device restarts, etc.).
}

bool CLAP_ABI pluginStartProcessing(const clap_plugin_t*) { return true; }
void CLAP_ABI pluginStopProcessing(const clap_plugin_t*) {}

void CLAP_ABI pluginReset(const clap_plugin_t* plugin) {
    auto* p = self(plugin);
    p->allNotesOff();
    p->resetResampler();
}

clap_process_status CLAP_ABI pluginProcess(const clap_plugin_t* plugin, const clap_process_t* process) {
    auto* p = self(plugin);
    if (!process || process->audio_outputs_count < 1u || !process->audio_outputs) return CLAP_PROCESS_CONTINUE;

    if (process->in_events) {
        const std::uint32_t count = process->in_events->size(process->in_events);
        for (std::uint32_t i = 0; i < count; ++i) p->handleEvent(process->in_events->get(process->in_events, i));
    }

    auto& out = process->audio_outputs[0];
    if (out.data32 && out.channel_count >= 2u && out.data32[0] && out.data32[1]) {
        p->render(out.data32[0], out.data32[1], process->frames_count);
    }
    return CLAP_PROCESS_CONTINUE;
}

std::uint32_t CLAP_ABI audioPortsCount(const clap_plugin_t*, bool isInput) {
    return isInput ? 0u : 1u;
}

bool CLAP_ABI audioPortsGet(const clap_plugin_t*, std::uint32_t index, bool isInput,
                            clap_audio_port_info_t* info) {
    if (!info || isInput || index != 0u) return false;
    std::memset(info, 0, sizeof(*info));
    info->id = 0;
    std::snprintf(info->name, sizeof(info->name), "Reality Main");
    info->flags = CLAP_AUDIO_PORT_IS_MAIN;
    info->channel_count = 2;
    info->port_type = CLAP_PORT_STEREO;
    info->in_place_pair = CLAP_INVALID_ID;
    return true;
}

const clap_plugin_audio_ports_t kAudioPorts { audioPortsCount, audioPortsGet };

std::uint32_t CLAP_ABI notePortsCount(const clap_plugin_t*, bool isInput) {
    return isInput ? 1u : 0u;
}

bool CLAP_ABI notePortsGet(const clap_plugin_t*, std::uint32_t index, bool isInput,
                           clap_note_port_info_t* info) {
    if (!info || !isInput || index != 0u) return false;
    std::memset(info, 0, sizeof(*info));
    info->id = 0;
    info->supported_dialects = CLAP_NOTE_DIALECT_CLAP | CLAP_NOTE_DIALECT_MIDI;
    info->preferred_dialect = CLAP_NOTE_DIALECT_CLAP;
    std::snprintf(info->name, sizeof(info->name), "Reality MIDI In");
    return true;
}

const clap_plugin_note_ports_t kNotePorts { notePortsCount, notePortsGet };

std::uint32_t CLAP_ABI latencyGet(const clap_plugin_t* plugin) {
    const auto* p = self(plugin);
    const double sr = p->sampleRate > 1.0 ? p->sampleRate : 44100.0;
    return static_cast<std::uint32_t>(std::ceil(static_cast<double>(kTargetEngineLatencyFrames) * sr / 44100.0));
}

const clap_plugin_latency_t kLatency { latencyGet };

bool CLAP_ABI renderHasHardRealtimeRequirement(const clap_plugin_t*) { return true; }
bool CLAP_ABI renderSet(const clap_plugin_t*, clap_plugin_render_mode mode) {
    return mode == CLAP_RENDER_REALTIME;
}
const clap_plugin_render_t kRender { renderHasHardRealtimeRequirement, renderSet };

bool CLAP_ABI guiIsApiSupported(const clap_plugin_t*, const char* api, bool isFloating) {
    return !isFloating && api && std::strcmp(api, CLAP_WINDOW_API_WIN32) == 0;
}

bool CLAP_ABI guiGetPreferredApi(const clap_plugin_t*, const char** api, bool* isFloating) {
    if (!api || !isFloating) return false;
    *api = CLAP_WINDOW_API_WIN32;
    *isFloating = false;
    return true;
}

bool CLAP_ABI guiCreate(const clap_plugin_t* plugin, const char* api, bool isFloating) {
    if (!guiIsApiSupported(plugin, api, isFloating)) return false;
    return self(plugin)->createGui();
}

void CLAP_ABI guiDestroy(const clap_plugin_t* plugin) {
    self(plugin)->destroyGui();
}

bool CLAP_ABI guiSetScale(const clap_plugin_t*, double) {
    // Win32 CLAP sizes are physical pixels. Keep Reality's original pixel geometry.
    return false;
}

bool CLAP_ABI guiGetSize(const clap_plugin_t* plugin, std::uint32_t* width, std::uint32_t* height) {
    if (!width || !height) return false;
    auto* p = self(plugin);
    if (!p->guiCreated) return false;
    p->discoverRealityWindow();
    *width = p->guiWidth;
    *height = p->guiHeight;
    return true;
}

bool CLAP_ABI guiCanResize(const clap_plugin_t*) { return false; }
bool CLAP_ABI guiGetResizeHints(const clap_plugin_t*, clap_gui_resize_hints_t*) { return false; }

bool CLAP_ABI guiAdjustSize(const clap_plugin_t* plugin, std::uint32_t* width, std::uint32_t* height) {
    if (!width || !height) return false;
    const auto* p = self(plugin);
    *width = p->guiWidth;
    *height = p->guiHeight;
    return true;
}

bool CLAP_ABI guiSetSize(const clap_plugin_t* plugin, std::uint32_t width, std::uint32_t height) {
    auto* p = self(plugin);
    if (!p->guiCreated || width != p->guiWidth || height != p->guiHeight) return false;
    if (p->guiHwnd) {
        SetWindowPos(p->guiHwnd, nullptr, 0, 0, static_cast<int>(width), static_cast<int>(height),
                     SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
    }
    p->sizeEmbeddedReality();
    return true;
}

bool CLAP_ABI guiSetParent(const clap_plugin_t* plugin, const clap_window_t* window) {
    if (!window || !window->api || std::strcmp(window->api, CLAP_WINDOW_API_WIN32) != 0 || !window->win32)
        return false;
    return self(plugin)->setGuiParent(static_cast<HWND>(window->win32));
}

bool CLAP_ABI guiSetTransient(const clap_plugin_t*, const clap_window_t*) { return false; }
void CLAP_ABI guiSuggestTitle(const clap_plugin_t*, const char*) {}
bool CLAP_ABI guiShow(const clap_plugin_t* plugin) { return self(plugin)->showGui(); }
bool CLAP_ABI guiHide(const clap_plugin_t* plugin) { return self(plugin)->hideGui(); }

const clap_plugin_gui_t kGui {
    guiIsApiSupported,
    guiGetPreferredApi,
    guiCreate,
    guiDestroy,
    guiSetScale,
    guiGetSize,
    guiCanResize,
    guiGetResizeHints,
    guiAdjustSize,
    guiSetSize,
    guiSetParent,
    guiSetTransient,
    guiSuggestTitle,
    guiShow,
    guiHide
};

const void* CLAP_ABI pluginGetExtension(const clap_plugin_t*, const char* id) {
    if (!id) return nullptr;
    if (std::strcmp(id, CLAP_EXT_AUDIO_PORTS) == 0) return &kAudioPorts;
    if (std::strcmp(id, CLAP_EXT_NOTE_PORTS) == 0) return &kNotePorts;
    if (std::strcmp(id, CLAP_EXT_LATENCY) == 0) return &kLatency;
    if (std::strcmp(id, CLAP_EXT_RENDER) == 0) return &kRender;
    if (std::strcmp(id, CLAP_EXT_GUI) == 0) return &kGui;
    return nullptr;
}

void CLAP_ABI pluginOnMainThread(const clap_plugin_t* plugin) {
    auto* p = self(plugin);
    if (p->guiCreated) p->onGuiTimer();
}

const clap_plugin_t* createPlugin(const clap_host_t* host) {
    if (!host || !clap_version_is_compatible(host->clap_version)) return nullptr;
    auto* p = new (std::nothrow) Plugin();
    if (!p) return nullptr;
    p->host = host;
    p->clap.desc = &kDescriptor;
    p->clap.plugin_data = p;
    p->clap.init = pluginInit;
    p->clap.destroy = pluginDestroy;
    p->clap.activate = pluginActivate;
    p->clap.deactivate = pluginDeactivate;
    p->clap.start_processing = pluginStartProcessing;
    p->clap.stop_processing = pluginStopProcessing;
    p->clap.reset = pluginReset;
    p->clap.process = pluginProcess;
    p->clap.get_extension = pluginGetExtension;
    p->clap.on_main_thread = pluginOnMainThread;
    return &p->clap;
}

std::uint32_t CLAP_ABI factoryCount(const clap_plugin_factory_t*) { return 1u; }

const clap_plugin_descriptor_t* CLAP_ABI factoryDescriptor(const clap_plugin_factory_t*, std::uint32_t index) {
    return index == 0u ? &kDescriptor : nullptr;
}

const clap_plugin_t* CLAP_ABI factoryCreate(const clap_plugin_factory_t*, const clap_host_t* host,
                                            const char* pluginId) {
    if (!pluginId || std::strcmp(pluginId, kDescriptor.id) != 0) return nullptr;
    return createPlugin(host);
}

const clap_plugin_factory_t kFactory { factoryCount, factoryDescriptor, factoryCreate };

bool CLAP_ABI entryInit(const char* pluginPath) {
    const LONG refs = InterlockedIncrement(&gEntryRefs);
    if (refs == 1) gPluginPath = RealityBridgeClient::utf8ToWide(pluginPath);
    return !gPluginPath.empty();
}

void CLAP_ABI entryDeinit() {
    if (InterlockedDecrement(&gEntryRefs) == 0) gPluginPath.clear();
}

const void* CLAP_ABI entryGetFactory(const char* id) {
    return id && std::strcmp(id, CLAP_PLUGIN_FACTORY_ID) == 0 ? &kFactory : nullptr;
}

clap_plugin_entry_t MakeEntry() {
    clap_plugin_entry_t e{};
    e.clap_version = CLAP_VERSION_INIT;
    e.init = entryInit;
    e.deinit = entryDeinit;
    e.get_factory = entryGetFactory;
    return e;
}

} // namespace

extern "C" CLAP_EXPORT const clap_plugin_entry_t clap_entry = MakeEntry();
