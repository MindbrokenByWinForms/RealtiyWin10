#pragma once
#include <windows.h>
#include <cstdarg>

void LogInit(HMODULE self);
void Logf(const char* fmt, ...);
