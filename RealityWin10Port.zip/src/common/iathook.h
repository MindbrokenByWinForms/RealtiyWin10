#pragma once
#include <windows.h>

bool PatchImport(HMODULE module, const char* importedDll, const char* functionName,
                 void* replacement, void** original);
