#include "log.h"
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>

static std::mutex g_mu;
static FILE* g_file = nullptr;

static bool LoggingDisabledByEnvironment() {
    char value[32] = {};
    DWORD n = GetEnvironmentVariableA("REALITY_CREATE_LOG", value, static_cast<DWORD>(sizeof(value)));
    if (n == 0 || n >= sizeof(value)) return false;
    return value[0] == '0' || _stricmp(value, "off") == 0 ||
           _stricmp(value, "false") == 0 || _stricmp(value, "no") == 0;
}

void LogInit(HMODULE self) {
    std::lock_guard<std::mutex> lock(g_mu);
    if (g_file) return;
    if (LoggingDisabledByEnvironment()) return;
    char path[MAX_PATH] = {};
    GetModuleFileNameA(self, path, MAX_PATH);
    std::string p(path);
    auto slash = p.find_last_of("\\/");
    if (slash != std::string::npos) p.resize(slash + 1); else p.clear();
    p += "RealityCompat.log";
    g_file = std::fopen(p.c_str(), "a");
    if (g_file) {
        SYSTEMTIME st{}; GetLocalTime(&st);
        std::fprintf(g_file, "\n--- RealityCompat %04u-%02u-%02u %02u:%02u:%02u ---\n",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        std::fflush(g_file);
    }
}

void Logf(const char* fmt, ...) {
    std::lock_guard<std::mutex> lock(g_mu);
    if (!g_file) return;
    va_list ap; va_start(ap, fmt);
    std::vfprintf(g_file, fmt, ap);
    va_end(ap);
    std::fputc('\n', g_file);
    std::fflush(g_file);
}
