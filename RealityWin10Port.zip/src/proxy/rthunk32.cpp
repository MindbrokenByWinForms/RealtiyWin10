#include <windows.h>

// These four exports existed only in Win9x's generic-thunk KERNEL32 support.
// Stage 8 intentionally disables SynHigh's SeqPlay.dll (16-bit NE) path, so
// they should never execute during normal Reality operation. They exist only
// to let the NT loader resolve SynHigh's import table. If unexpectedly called,
// fail/no-op rather than entering arbitrary 16-bit code.
//
// IMPORTANT: MSVC inline-assembly uses ';' as an assembly comment delimiter.
// Keep instructions on separate lines; otherwise a line such as
//   __asm { xor eax, eax; ret 8 }
// comments out the closing brace and breaks compilation.

// Real Win9x signature is ThunkConnect32@24 (six 32-bit arguments).
// SynHigh's 16-bit SeqPlay side is intentionally disabled on NT, so report
// a successful connection while preserving the exact stdcall stack cleanup.
extern "C" __declspec(naked) void ThunkConnect32()
{
    __asm {
        mov eax, 1
        ret 24
    }
}

extern "C" __declspec(naked) void MapSL()
{
    __asm {
        xor eax, eax
        ret 4
    }
}

extern "C" __declspec(naked) void SMapLS_IP_EBP_8()
{
    __asm {
        xor eax, eax
        ret
    }
}

extern "C" __declspec(naked) void SUnMapLS_IP_EBP_8()
{
    __asm {
        ret
    }
}

BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID)
{
    return TRUE;
}
