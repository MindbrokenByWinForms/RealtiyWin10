#pragma once

#include <windows.h>
#include <cstdint>
#include "reality_clap_bridge_shared.h"

namespace reality::clapbridge {

// Returns true only when REALITY_CLAP_BRIDGE_NAME names a valid mapping made
// by the CLAP front-end. All functions are no-ops in ordinary standalone mode.
bool EnsureOpen();
bool IsActive();
bool MuteDirectSound();

bool PublishAudio(const void* pcm, std::uint32_t frames,
                  std::uint32_t rate, std::uint32_t bits,
                  std::uint32_t channels);

bool PopMidi(MidiEvent* event);
bool ShutdownRequested();
void RequestGracefulWindowClose();
void Close();

} // namespace reality::clapbridge
