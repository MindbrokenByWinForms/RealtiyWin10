#pragma once

// Shared-memory ABI between the 64-bit CLAP front-end and the 32-bit Reality
// rehost. Keep this header POD-only and pointer-free so the layout is identical
// in x86 and x64 processes.

#include <windows.h>
#include <cstdint>

namespace reality::clapbridge {

static constexpr std::uint32_t kBridgeMagic = 0x504C4352u; // 'RCLP'
static constexpr std::uint32_t kBridgeVersion = 0x00010000u;
static constexpr std::uint32_t kAudioCapacityFrames = 65536u;
static constexpr std::uint32_t kMidiCapacityEvents = 2048u;
static constexpr std::uint32_t kReadyEngine = 0x00000001u;
static constexpr std::uint32_t kReadyAudio = 0x00000002u;

#pragma pack(push, 4)
struct MidiEvent {
    std::uint32_t packedMessage; // WinMM-style status | d1<<8 | d2<<16
    std::uint32_t timestampMs;   // advisory, zero is valid
};

struct SharedState {
    std::uint32_t magic;
    std::uint32_t version;
    std::uint32_t structBytes;
    volatile LONG readyFlags;
    volatile LONG enginePid;
    volatile LONG shutdownRequested;

    volatile LONG sampleRate;
    volatile LONG channels;
    volatile LONG bitsPerSample;
    volatile LONG callbackFrames;

    // Monotonic counters. One writer and one reader per ring.
    volatile LONG audioWriteFrame;
    volatile LONG audioReadFrame;
    volatile LONG audioOverruns;
    volatile LONG audioUnderruns;

    volatile LONG midiWriteEvent;
    volatile LONG midiReadEvent;
    volatile LONG midiOverruns;
    volatile LONG reserved0;

    // Interleaved signed 16-bit stereo at the recovered engine's native
    // transport rate (normally 44100 Hz). Capacity is expressed in frames.
    std::int16_t audio[kAudioCapacityFrames * 2u];
    MidiEvent midi[kMidiCapacityEvents];
};
#pragma pack(pop)

static_assert(sizeof(MidiEvent) == 8, "bridge MIDI event ABI changed");
static_assert(sizeof(SharedState) == 278600, "bridge shared-memory ABI changed");

inline std::uint32_t LoadCounter(volatile LONG* value) noexcept {
    return static_cast<std::uint32_t>(InterlockedCompareExchange(value, 0, 0));
}

inline void StoreCounter(volatile LONG* value, std::uint32_t v) noexcept {
    InterlockedExchange(value, static_cast<LONG>(v));
}

} // namespace reality::clapbridge
