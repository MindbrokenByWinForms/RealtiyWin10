#include "reality_clap_bridge_engine.h"
#include "log.h"
#include <algorithm>
#include <cstring>
#include <iterator>

namespace reality::clapbridge {
namespace {
HANDLE g_mapping = nullptr;
SharedState* g_state = nullptr;
bool g_attempted = false;
bool g_muteDirectSound = true;

bool EnvFalse(const char* name) {
    char value[32]{};
    const DWORD n = GetEnvironmentVariableA(name, value, static_cast<DWORD>(sizeof(value)));
    if (!n || n >= sizeof(value)) return false;
    return _stricmp(value, "0") == 0 || _stricmp(value, "false") == 0 ||
           _stricmp(value, "no") == 0 || _stricmp(value, "off") == 0;
}

BOOL CALLBACK CloseWindowProc(HWND hwnd, LPARAM) {
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == GetCurrentProcessId()) PostMessageW(hwnd, WM_CLOSE, 0, 0);
    return TRUE;
}
} // namespace

bool EnsureOpen() {
    if (g_state) return true;
    if (g_attempted) return false;
    g_attempted = true;

    wchar_t name[256]{};
    const DWORD n = GetEnvironmentVariableW(L"REALITY_CLAP_BRIDGE_NAME", name,
                                             static_cast<DWORD>(std::size(name)));
    if (!n || n >= std::size(name)) return false;

    g_muteDirectSound = !EnvFalse("REALITY_CLAP_MUTE_DS");
    g_mapping = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, name);
    if (!g_mapping) {
        Logf("RealityCLAP bridge: OpenFileMapping failed name=%ls error=%lu", name, GetLastError());
        return false;
    }

    g_state = static_cast<SharedState*>(MapViewOfFile(g_mapping, FILE_MAP_ALL_ACCESS,
                                                      0, 0, sizeof(SharedState)));
    if (!g_state) {
        Logf("RealityCLAP bridge: MapViewOfFile failed error=%lu", GetLastError());
        CloseHandle(g_mapping);
        g_mapping = nullptr;
        return false;
    }

    if (g_state->magic != kBridgeMagic || g_state->version != kBridgeVersion ||
        g_state->structBytes != sizeof(SharedState)) {
        Logf("RealityCLAP bridge: incompatible mapping magic=%08lX version=%08lX bytes=%lu expected=%lu",
             static_cast<unsigned long>(g_state->magic),
             static_cast<unsigned long>(g_state->version),
             static_cast<unsigned long>(g_state->structBytes),
             static_cast<unsigned long>(sizeof(SharedState)));
        UnmapViewOfFile(g_state);
        CloseHandle(g_mapping);
        g_state = nullptr;
        g_mapping = nullptr;
        return false;
    }

    InterlockedExchange(&g_state->enginePid, static_cast<LONG>(GetCurrentProcessId()));
    InterlockedOr(&g_state->readyFlags, static_cast<LONG>(kReadyEngine));
    Logf("RealityCLAP bridge: attached name=%ls pid=%lu muteDS=%u",
         name, GetCurrentProcessId(), g_muteDirectSound ? 1u : 0u);
    return true;
}

bool IsActive() {
    return EnsureOpen();
}

bool MuteDirectSound() {
    return EnsureOpen() && g_muteDirectSound;
}

bool PublishAudio(const void* pcm, std::uint32_t frames,
                  std::uint32_t rate, std::uint32_t bits,
                  std::uint32_t channels) {
    if (!pcm || !frames || !EnsureOpen()) return false;
    // v13.x's recovered callback is currently known-good as signed 16-bit stereo.
    if (bits != 16u || channels != 2u) return false;

    const auto* src = static_cast<const std::int16_t*>(pcm);
    std::uint32_t write = LoadCounter(&g_state->audioWriteFrame);
    std::uint32_t read = LoadCounter(&g_state->audioReadFrame);
    std::uint32_t used = write - read;
    if (used > kAudioCapacityFrames) {
        read = write - kAudioCapacityFrames;
        StoreCounter(&g_state->audioReadFrame, read);
        used = kAudioCapacityFrames;
    }

    if (frames > kAudioCapacityFrames) {
        src += static_cast<std::size_t>(frames - kAudioCapacityFrames) * 2u;
        frames = kAudioCapacityFrames;
    }

    const std::uint32_t freeFrames = kAudioCapacityFrames - used;
    if (frames > freeFrames) {
        const std::uint32_t drop = frames - freeFrames;
        StoreCounter(&g_state->audioReadFrame, read + drop);
        InterlockedIncrement(&g_state->audioOverruns);
    }

    for (std::uint32_t i = 0; i < frames; ++i) {
        const std::uint32_t slot = (write + i) % kAudioCapacityFrames;
        g_state->audio[slot * 2u + 0u] = src[i * 2u + 0u];
        g_state->audio[slot * 2u + 1u] = src[i * 2u + 1u];
    }

    InterlockedExchange(&g_state->sampleRate, static_cast<LONG>(rate));
    InterlockedExchange(&g_state->channels, 2);
    InterlockedExchange(&g_state->bitsPerSample, 16);
    InterlockedExchange(&g_state->callbackFrames, static_cast<LONG>(frames));
    MemoryBarrier();
    StoreCounter(&g_state->audioWriteFrame, write + frames);
    InterlockedOr(&g_state->readyFlags, static_cast<LONG>(kReadyAudio));
    return true;
}

bool PopMidi(MidiEvent* event) {
    if (!event || !EnsureOpen()) return false;
    const std::uint32_t read = LoadCounter(&g_state->midiReadEvent);
    const std::uint32_t write = LoadCounter(&g_state->midiWriteEvent);
    if (read == write) return false;
    const std::uint32_t slot = read % kMidiCapacityEvents;
    *event = g_state->midi[slot];
    MemoryBarrier();
    StoreCounter(&g_state->midiReadEvent, read + 1u);
    return true;
}

bool ShutdownRequested() {
    return EnsureOpen() && InterlockedCompareExchange(&g_state->shutdownRequested, 0, 0) != 0;
}

void RequestGracefulWindowClose() {
    if (!EnsureOpen()) return;
    EnumWindows(CloseWindowProc, 0);
}

void Close() {
    if (g_state) {
        InterlockedAnd(&g_state->readyFlags, 0);
        UnmapViewOfFile(g_state);
        g_state = nullptr;
    }
    if (g_mapping) {
        CloseHandle(g_mapping);
        g_mapping = nullptr;
    }
}

} // namespace reality::clapbridge
