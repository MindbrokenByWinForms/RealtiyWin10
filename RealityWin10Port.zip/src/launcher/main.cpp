#include <windows.h>
#include <string>
#include <iostream>
#include <vector>
#include <cstring>

static std::wstring DirOf(const std::wstring& p) { auto n=p.find_last_of(L"\\/"); return n==std::wstring::npos?L".":p.substr(0,n); }
static std::wstring FullPath(const std::wstring& p) { wchar_t b[MAX_PATH]={}; DWORD n=GetFullPathNameW(p.c_str(),MAX_PATH,b,nullptr); return n?std::wstring(b):p; }

static DWORD RemoteCallExport(HANDLE process, uintptr_t remoteBase, const std::wstring& dllPath, const char* exportName) {
    HMODULE local = LoadLibraryExW(dllPath.c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
    if (!local) return ERROR_MOD_NOT_FOUND;
    FARPROC fp = GetProcAddress(local, exportName);
#ifdef _M_IX86
    // Stage 5 compatibility: older builds may contain only the stdcall-decorated
    // symbol. Stage 6 .def files export stable undecorated names, but keep this
    // fallback so the launcher can diagnose/use a stale Stage 5 DLL too.
    if (!fp && strcmp(exportName, "RealityCompat_Initialize") == 0)
        fp = GetProcAddress(local, "_RealityCompat_Initialize@4");
#endif
    if (!fp) { FreeLibrary(local); return ERROR_PROC_NOT_FOUND; }
    uintptr_t rva = reinterpret_cast<uintptr_t>(fp) - reinterpret_cast<uintptr_t>(local);
    FreeLibrary(local);
    auto remoteProc = reinterpret_cast<LPTHREAD_START_ROUTINE>(remoteBase + rva);
    HANDLE t = CreateRemoteThread(process, nullptr, 0, remoteProc, nullptr, 0, nullptr);
    if (!t) return GetLastError();
    WaitForSingleObject(t, INFINITE);
    DWORD rc=0; GetExitCodeThread(t,&rc); CloseHandle(t); return rc;
}

int wmain(int argc, wchar_t** argv) {
    bool rehost=true; int exeArg=1;
    if (argc>1 && _wcsicmp(argv[1],L"--rehost")==0) { rehost=true; exeArg=2; }
    else if (argc>1 && _wcsicmp(argv[1],L"--stub")==0) { rehost=false; exeArg=2; }
    if (argc<=exeArg) { std::wcerr<<L"Usage: RealityWin10Launcher.exe [--rehost|--stub] <Reality.exe> [args...]\n"; return 2; }
    SetEnvironmentVariableW(L"REALITY_REHOST", rehost?L"1":nullptr);
    SetEnvironmentVariableW(L"REALITY_STUB", rehost?nullptr:L"1");

    std::wstring exe=FullPath(argv[exeArg]);
    wchar_t self[MAX_PATH]={}; GetModuleFileNameW(nullptr,self,MAX_PATH);
    std::wstring dll=DirOf(self)+L"\\RealityCompat.dll";
    std::wstring cmd=L"\""+exe+L"\"";
    for(int i=exeArg+1;i<argc;++i) cmd+=L" \""+std::wstring(argv[i])+L"\"";
    std::vector<wchar_t> mutableCmd(cmd.begin(),cmd.end()); mutableCmd.push_back(0);

    STARTUPINFOW si{}; si.cb=sizeof(si); PROCESS_INFORMATION pi{};
    if(!CreateProcessW(exe.c_str(),mutableCmd.data(),nullptr,nullptr,FALSE,CREATE_SUSPENDED,nullptr,DirOf(exe).c_str(),&si,&pi)) {
        std::wcerr<<L"CreateProcess failed: "<<GetLastError()<<L"\n"; return 3;
    }
    SIZE_T bytes=(dll.size()+1)*sizeof(wchar_t);
    void* remote=VirtualAllocEx(pi.hProcess,nullptr,bytes,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
    if(!remote || !WriteProcessMemory(pi.hProcess,remote,dll.c_str(),bytes,nullptr)) { TerminateProcess(pi.hProcess,1); return 4; }
    auto load=reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"),"LoadLibraryW"));
    HANDLE rt=CreateRemoteThread(pi.hProcess,nullptr,0,load,remote,0,nullptr);
    if(!rt){ TerminateProcess(pi.hProcess,1); return 5; }
    WaitForSingleObject(rt,INFINITE);
    DWORD loaded=0; GetExitCodeThread(rt,&loaded); CloseHandle(rt); VirtualFreeEx(pi.hProcess,remote,0,MEM_RELEASE);
    if(!loaded){ std::wcerr<<L"RealityCompat.dll failed to load\n"; TerminateProcess(pi.hProcess,1); return 6; }

    // Stage 5: initialize hooks + SSYNENG.dll synchronously before the primary
    // Reality thread is allowed to execute. This removes the Stage-4 startup race.
    DWORD initRc=RemoteCallExport(pi.hProcess,(uintptr_t)loaded,dll,"RealityCompat_Initialize");
    if(initRc!=0){ std::wcerr<<L"RealityCompat initialization failed: 0x"<<std::hex<<initRc<<L"\n"; TerminateProcess(pi.hProcess,initRc); return 7; }

    ResumeThread(pi.hThread); CloseHandle(pi.hThread);
    std::wcout<<L"Reality launched in "<<(rehost?L"REHOST":L"STUB")<<L" mode using SSYNENG.dll.\n";
    DWORD wait=WaitForSingleObject(pi.hProcess,2500);
    if(wait==WAIT_OBJECT_0){ DWORD code=0; GetExitCodeProcess(pi.hProcess,&code); std::wcerr<<L"Reality exited during startup. Exit code: 0x"<<std::hex<<code<<L"\n"; }
    else std::wcout<<L"Reality is still running after startup probe.\n";
    CloseHandle(pi.hProcess); return 0;
}
