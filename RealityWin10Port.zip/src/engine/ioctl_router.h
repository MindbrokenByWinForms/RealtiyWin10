#pragma once
#include <windows.h>
#include <cstdint>

namespace reality {
class SsynengRehost;

// Stage 3 uses genuine Win32 handles for SSYNENG opens.  This matters because
// legacy code can pass a device handle through generic Kernel32 handle APIs
// before/after DeviceIoControl.  A magic integer handle is rejected by those APIs.
HANDLE CreateCompatHandle();
bool IsCompatHandle(HANDLE h);
bool CloseCompatHandle(HANDLE h);

void SetExperimentalRehost(SsynengRehost* rehost);
BOOL CompatDeviceIoControl(DWORD code, LPVOID inBuf, DWORD inLen,
                           LPVOID outBuf, DWORD outLen, LPDWORD bytesReturned);
}
