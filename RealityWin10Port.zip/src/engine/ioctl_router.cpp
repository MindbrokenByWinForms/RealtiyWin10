#include "ioctl_router.h"
#include "log.h"
#include "ssyneng_host.h"
#include <algorithm>
#include <cstring>
#include <mutex>
#include <unordered_set>

namespace reality {

namespace {
std::mutex g_handleMutex;
std::unordered_set<HANDLE> g_handles;
}

HANDLE CreateCompatHandle() {
    HANDLE h = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (h) {
        std::lock_guard<std::mutex> lock(g_handleMutex);
        g_handles.insert(h);
    }
    return h ? h : INVALID_HANDLE_VALUE;
}

bool IsCompatHandle(HANDLE h) {
    std::lock_guard<std::mutex> lock(g_handleMutex);
    return g_handles.find(h) != g_handles.end();
}

bool CloseCompatHandle(HANDLE h) {
    {
        std::lock_guard<std::mutex> lock(g_handleMutex);
        auto it = g_handles.find(h);
        if (it == g_handles.end()) return false;
        g_handles.erase(it);
    }
    return CloseHandle(h) != FALSE;
}

namespace {
struct State {
    bool backdoor = false;
    uint32_t bankset = 0;
} g;
SsynengRehost* g_rehost = nullptr;

template<class T> bool Put(void* out, DWORD outLen, DWORD* br, const T& v) {
    if (!out || outLen < sizeof(T)) return false;
    std::memcpy(out, &v, sizeof(T));
    if (br) *br = sizeof(T);
    return true;
}
void Finish(DWORD* br, DWORD n = 0) { if (br) *br = n; }
}

void SetExperimentalRehost(SsynengRehost* rehost) {
    g_rehost = rehost;
    Logf("experimental original SSYNENG dispatcher %s", rehost ? "enabled" : "disabled");
}

BOOL CompatDeviceIoControl(DWORD code, LPVOID inBuf, DWORD inLen,
                           LPVOID outBuf, DWORD outLen, LPDWORD bytesReturned) {
    Finish(bytesReturned);
    Logf("DIOC code=%04lX in=%p/%lu out=%p/%lu", code, inBuf, inLen, outBuf, outLen);

    if (code == 0x4001 && inBuf && inLen >= 4) {
        uint32_t db = 0;
        bool readable = false;
#if defined(_MSC_VER)
        __try { std::memcpy(&db, inBuf, sizeof(db)); readable = true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { readable = false; }
#else
        std::memcpy(&db, inBuf, sizeof(db)); readable = true;
#endif
        Logf("  IOCTL4001 SetBanksetPointer candidate=%08X readable=%u", db, readable ? 1u : 0u);
    }

    if (code == 0x7002 && inBuf && inLen >= 68) {
        uint32_t words[17]{};
        bool readable = false;
#if defined(_MSC_VER)
        __try {
            std::memcpy(words, inBuf, sizeof(words));
            readable = true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            readable = false;
        }
#else
        std::memcpy(words, inBuf, sizeof(words));
        readable = true;
#endif
        if (readable) {
            Logf("  7002 words: %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X",
                 words[0], words[1], words[2], words[3], words[4], words[5], words[6], words[7],
                 words[8], words[9], words[10], words[11], words[12], words[13], words[14], words[15], words[16]);
        }
    }

    if (g_rehost && g_rehost->armed()) {
        Logf("  -> original SSYNENG dispatcher");
        return g_rehost->DispatchIoctl(code, inBuf, inLen, outBuf, outLen, bytesReturned);
    }

    switch (code) {
    case 0x9001: // SapiWrapper::EnableBackDoorToSynth
        g.backdoor = true;
        return Put(outBuf, outLen, bytesReturned, uint32_t{1}) ? TRUE : FALSE;
    case 0x9002:
        g.backdoor = false;
        return Put(outBuf, outLen, bytesReturned, uint32_t{1}) ? TRUE : FALSE;

    case 0x2101: // observed directly in VxD
        return Put(outBuf, outLen, bytesReturned, uint32_t{0x01000001}) ? TRUE : FALSE;
    case 0x2102: { // engine identification string path
        const char s[] = "Seer Synthesizer Engine (Win10 compatibility host)";
        if (!outBuf || outLen == 0) return FALSE;
        DWORD n = std::min<DWORD>(outLen, static_cast<DWORD>(sizeof(s)));
        std::memcpy(outBuf, s, n);
        Finish(bytesReturned, n);
        return TRUE;
    }
    case 0x2103:
        return Put(outBuf, outLen, bytesReturned, uint32_t{0x01000001}) ? TRUE : FALSE;

    case 0x1001: { // VxD returns two DWORDs; tied to VMM memory/page query
        if (!outBuf || outLen < 8) return FALSE;
        uint32_t v[2] = { 0x10000u, 0x10000u }; // benign compatibility values
        std::memcpy(outBuf, v, sizeof(v));
        Finish(bytesReturned, sizeof(v));
        return TRUE;
    }
    case 0x1002:
    case 0x1003:
        // Registration/setup. For tracing mode we accept and preserve the ABI.
        if (outBuf && outLen >= 4) Put(outBuf, outLen, bytesReturned, uint32_t{1});
        return TRUE;
    case 0x1004: // LockMem: modern Win32 process pages need no VxD lock for our host
    case 0x1005: // UnlockMem
        return TRUE;

    case 0x4001: // SetBanksetPointer
        if (inBuf && inLen >= 4) std::memcpy(&g.bankset, inBuf, 4);
        Logf("  bankset pointer = %08X", g.bankset);
        return TRUE;

    case 0x6001: // metering/status block; zero-filled is safe for UI bring-up
        if (outBuf && outLen) {
            std::memset(outBuf, 0, outLen);
            Finish(bytesReturned, outLen);
        }
        return TRUE;

    default:
        // Stage-1 behavior: preserve control-flow and log exact buffers. This intentionally
        // does not claim to synthesize audio; SSYNENG rehosting is the next layer.
        if ((code & 0xF000) == 0x3000 || (code & 0xF000) == 0x4000 ||
            (code & 0xF000) == 0x5000 || code == 0x8001 ||
            code == 0x2005 || code == 0x2006) {
            if (outBuf && outLen) {
                std::memset(outBuf, 0, outLen);
                Finish(bytesReturned, outLen);
            }
            Logf("  STUBBED known SSYNENG group %04lX", code);
            return TRUE;
        }
        SetLastError(ERROR_INVALID_FUNCTION);
        Logf("  UNKNOWN/REJECTED code=%04lX", code);
        return FALSE;
    }
}
} // namespace reality
