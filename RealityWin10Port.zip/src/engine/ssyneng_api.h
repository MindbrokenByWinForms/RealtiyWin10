#pragma once
#include <windows.h>

// Native 32-bit user-mode boundary around the recovered SSYNENG.VXD engine.
// Reality itself remains x86; keeping the original engine in-process preserves
// all of its raw 32-bit program/channel/voice pointers.
#define SSYNENG_API_VERSION 0x00040000u
#define SSYNENG_INIT_REHOST_ORIGINAL 0x00000001u

using SSynEng_GetApiVersion_t   = DWORD (WINAPI*)();
using SSynEng_Initialize_t      = BOOL  (WINAPI*)(LPCWSTR moduleDirectory, DWORD flags);
using SSynEng_Shutdown_t        = void  (WINAPI*)();
using SSynEng_OpenDevice_t      = HANDLE(WINAPI*)();
using SSynEng_IsDeviceHandle_t  = BOOL  (WINAPI*)(HANDLE);
using SSynEng_CloseDevice_t     = BOOL  (WINAPI*)(HANDLE);
using SSynEng_DeviceIoControl_t = BOOL  (WINAPI*)(HANDLE,DWORD,LPVOID,DWORD,LPVOID,DWORD,LPDWORD);

// Recovered protected-mode API operations.
using SSynEng_ControlState_t    = BOOL  (WINAPI*)(LPVOID legacyState, DWORD stateBytes);
using SSynEng_Start_t           = BOOL  (WINAPI*)();
using SSynEng_Stop_t            = BOOL  (WINAPI*)();
using SSynEng_ResetMidi_t       = BOOL  (WINAPI*)(BOOL fullGmGsReset);
using SSynEng_InjectMidiShort_t = BOOL  (WINAPI*)(DWORD packedMessage, DWORD timestampMs);
using SSynEng_DumpSynthState_t  = void  (WINAPI*)();
// v6: reconstructed program-database bridge.  SynHigh/SynMid still emits
// command 0x41 with the program-root pointer and optional 1-based channel
// hint even when the old SetBanksetPointer handoff never occurs on NT.
using SSynEng_GetProgramDatabase_t = DWORD (WINAPI*)();
using SSynEng_RegisterProgramRoot_t = BOOL (WINAPI*)(DWORD rootPointer, WORD channelHint);
