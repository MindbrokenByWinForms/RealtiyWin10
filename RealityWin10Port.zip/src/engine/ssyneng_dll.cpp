#include <windows.h>
#include <string>
#include <cstdlib>
#include <new>
#include "ssyneng_api.h"
#include "ioctl_router.h"
#include "ssyneng_host.h"
#include "log.h"
#include "reality_clap_bridge_engine.h"

static HMODULE g_self = nullptr;
// Intentionally process-lifetime storage.  A cross-translation-unit static
// destructor previously called Unload after vmm_bridge's STL globals had
// already been destroyed, producing the repeatable shutdown AV in SSYNENG.
// The registered exit callback below performs ordered teardown first; keeping
// the small host object itself alive lets Windows reclaim it safely afterward.
static reality::SsynengRehost* g_rehost = nullptr;
static bool g_initialized = false;
static bool g_exitHandlerRegistered = false;

static void ShutdownEngineCore(const char* reason) {
    if (!g_initialized && !g_rehost) return;
    Logf("SSYNENG.dll ordered shutdown begin reason=%s initialized=%u host=%p",
         reason, g_initialized ? 1u : 0u, g_rehost);
    reality::SetExperimentalRehost(nullptr);
    if (g_rehost) {
        g_rehost->StopEngine();
        g_rehost->Unload();
    }
    reality::clapbridge::Close();
    g_initialized = false;
    Logf("SSYNENG.dll ordered shutdown complete reason=%s", reason);
}

static void __cdecl ProcessExitShutdown() {
    ShutdownEngineCore("CRT process-exit callback");
}

static std::wstring JoinPath(LPCWSTR dir, LPCWSTR leaf) {
    std::wstring s = (dir && *dir) ? dir : L".";
    if (!s.empty() && s.back() != L'\\' && s.back() != L'/') s += L'\\';
    s += leaf;
    return s;
}

extern "C" __declspec(dllexport) DWORD WINAPI SSynEng_GetApiVersion() {
    return SSYNENG_API_VERSION;
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_Initialize(LPCWSTR moduleDirectory, DWORD flags) {
    if (g_initialized) return TRUE;
    LogInit(g_self);
    Logf("SSYNENG.dll native host initialize flags=%08lX", flags);

    if (!g_rehost) {
        g_rehost = new (std::nothrow) reality::SsynengRehost();
        if (!g_rehost) {
            SetLastError(ERROR_NOT_ENOUGH_MEMORY);
            return FALSE;
        }
    }

    if (flags & SSYNENG_INIT_REHOST_ORIGINAL) {
        std::wstring pack = JoinPath(moduleDirectory, L"ssyneng.rehost");
        if (!g_rehost->LoadPack(pack) || !g_rehost->ArmVmmBridge()) {
            Logf("SSYNENG.dll failed to load/arm original engine pack: %ls", pack.c_str());
            SetLastError(ERROR_NOT_READY);
            return FALSE;
        }
        reality::SetExperimentalRehost(g_rehost);
        Logf("SSYNENG.dll original-engine backend armed: %ls", pack.c_str());
    } else {
        reality::SetExperimentalRehost(nullptr);
        Logf("SSYNENG.dll compatibility/stub backend armed");
    }

    g_initialized = true;
    if (!g_exitHandlerRegistered && std::atexit(ProcessExitShutdown) == 0) {
        g_exitHandlerRegistered = true;
        Logf("SSYNENG.dll registered ordered process-exit shutdown callback");
    }
    return TRUE;
}

extern "C" __declspec(dllexport) void WINAPI SSynEng_Shutdown() {
    ShutdownEngineCore("explicit API");
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_ControlState(LPVOID legacyState, DWORD stateBytes) {
    if (!g_initialized || !g_rehost) { SetLastError(ERROR_NOT_READY); return FALSE; }
    return g_rehost->ControlState(legacyState, stateBytes);
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_Start() {
    if (!g_initialized || !g_rehost) { SetLastError(ERROR_NOT_READY); return FALSE; }
    return g_rehost->StartEngine();
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_Stop() {
    if (!g_initialized || !g_rehost) return TRUE;
    return g_rehost->StopEngine();
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_ResetMidi(BOOL fullGmGsReset) {
    if (!g_initialized || !g_rehost) { SetLastError(ERROR_NOT_READY); return FALSE; }
    return g_rehost->ResetMidi(fullGmGsReset != FALSE);
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_InjectMidiShort(
    DWORD packedMessage, DWORD timestampMs) {
    if (!g_initialized || !g_rehost) {
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }
    return g_rehost->InjectMidiShort(packedMessage, timestampMs);
}

extern "C" __declspec(dllexport) void WINAPI SSynEng_DumpSynthState() {
    if (g_initialized && g_rehost) g_rehost->DumpSynthState("external diagnostic");
}

extern "C" __declspec(dllexport) DWORD WINAPI SSynEng_GetProgramDatabase() {
    if (!g_initialized || !g_rehost) return 0;
    return g_rehost->GetProgramDatabasePointer();
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_RegisterProgramRoot(
    DWORD rootPointer, WORD channelHint) {
    if (!g_initialized || !g_rehost) {
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }
    return g_rehost->RegisterProgramRoot(rootPointer, channelHint);
}

extern "C" __declspec(dllexport) HANDLE WINAPI SSynEng_OpenDevice() {
    if (!g_initialized) { SetLastError(ERROR_NOT_READY); return INVALID_HANDLE_VALUE; }
    return reality::CreateCompatHandle();
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_IsDeviceHandle(HANDLE h) {
    return reality::IsCompatHandle(h) ? TRUE : FALSE;
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_CloseDevice(HANDLE h) {
    return reality::CloseCompatHandle(h) ? TRUE : FALSE;
}

extern "C" __declspec(dllexport) BOOL WINAPI SSynEng_DeviceIoControl(
    HANDLE h, DWORD code, LPVOID inBuf, DWORD inLen,
    LPVOID outBuf, DWORD outLen, LPDWORD bytesReturned) {
    if (!g_initialized || !reality::IsCompatHandle(h)) {
        SetLastError(ERROR_INVALID_HANDLE);
        return FALSE;
    }
    return reality::CompatDeviceIoControl(code, inBuf, inLen, outBuf, outLen, bytesReturned);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
    }
    return TRUE;
}
