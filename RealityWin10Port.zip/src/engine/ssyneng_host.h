#pragma once
#include <windows.h>
#include <cstdint>
#include <string>
#include <vector>

namespace reality {

struct RehostObject {
    uint8_t* allocation = nullptr;
    uint8_t* base = nullptr;
    uint32_t size = 0;
};

class SsynengRehost {
public:
    ~SsynengRehost();

    bool LoadPack(const std::wstring& path);
    bool ArmVmmBridge();
    bool InitializeCore();
    bool CoreReady() const;

    BOOL DispatchIoctl(DWORD code, LPVOID inBuf, DWORD inLen,
                       LPVOID outBuf, DWORD outLen, LPDWORD bytesReturned);

    // Original protected-mode engine operations recovered from SSYNENG.VXD.
    BOOL ControlState(void* legacyState, DWORD stateBytes); // service 0x11 core
    BOOL StartEngine();                                    // service 0x03 semantics
    BOOL StopEngine();                                     // service 0x04 semantics
    BOOL ResetMidi(bool fullGmGsReset);                    // service 0x0A / 0x0B
    BOOL InjectMidiShort(DWORD packedMessage, DWORD timestampMs);
    void DumpSynthState(const char* reason = nullptr) const;
    DWORD GetProgramDatabasePointer() const;
    BOOL RegisterProgramRoot(DWORD rootPointer, WORD channelHint);

    void Unload();
    bool loaded() const { return !objects_.empty(); }
    bool armed() const { return bridgeArmed_; }
    void* Ptr(uint32_t objectIndex1Based, uint32_t offset) const;
    void* PtrSigned(uint32_t objectIndex1Based, int32_t offset) const;

private:
    bool InitializeLifecycle();
    bool TryStartOutput();
    void MarkModernOutputRunning(const char* reason);
    void ConfigureModernAudio(const void* block, DWORD bytes);
    void ConfigureModernRateMixerBridge(DWORD rate, DWORD bits, DWORD channels, const char* reason);
    void EnsureModernRateMixerBridge(const char* reason);
    void DeactivateModernAudio(const char* reason);
    void DumpRenderContract(const char* reason = nullptr) const;
    DWORD ResolveNativeCallbackBytes(DWORD frameBytes, DWORD outputBytes, bool publish);
    bool QueryModernAudioCursor(DWORD mappedBase, DWORD mappedBytes, DWORD* playCursor, DWORD* writeCursor);
    bool EnsureHostPump();
    void StopHostPump();
    static DWORD WINAPI HostPumpThreadThunk(LPVOID param);
    DWORD HostPumpMain();
    unsigned DrainMidiRingHost(unsigned maxEvents = 256);
    unsigned DrainDelayedMidiHost(unsigned maxEvents = 32);
    unsigned MidiRingPendingCount(uint32_t* readIndex = nullptr, uint32_t* writeIndex = nullptr);
    void ObserveNativeMidiAfterRender(bool rendered);
    unsigned CountMatchingVoices(unsigned chIndex, BYTE note, uint32_t* firstVoice = nullptr) const;
    void LogMidiNoteDisposition(DWORD packedMessage, const char* source);
    bool RenderHostQuantum();
    bool PointerReadable(uint32_t address, SIZE_T bytes) const;
    uint32_t ReadObjectU32(uint32_t offset) const;
    bool RebuildFallbackProgramDatabase();

    static constexpr uint32_t kGuardBytes = 64;
    std::vector<RehostObject> objects_;
    bool bridgeArmed_ = false;
    bool coreInitAttempted_ = false;
    bool startRequested_ = false;
    bool lifecycleReady_ = false;
    bool modernAudioRegistered_ = false;
    bool legacyOutputOpened_ = false;
    HANDLE hostPumpThread_ = nullptr;
    HANDLE hostPumpStopEvent_ = nullptr;
    HANDLE hostPumpWakeEvent_ = nullptr;
    volatile LONG hostPumpStarting_ = 0;
    volatile LONG modernAudioBuffer_ = 0;
    volatile LONG modernAudioBytes_ = 0;
    volatile LONG modernAudioRate_ = 44100;
    volatile LONG modernAudioBits_ = 16;
    volatile LONG modernAudioChannels_ = 2;
    DWORD renderCursorBytes_ = 0;
    bool renderCursorPrimed_ = false;
    DWORD renderCursorResyncs_ = 0;
    DWORD lastScheduledCallbackBytes_ = 0;
    uint8_t* renderScratch_ = nullptr;
    uint8_t* noteOffNullGuardStub_ = nullptr;
    DWORD renderScratchBytes_ = 0;
    DWORD lastRenderCallbackBytes_ = 0;
    WORD lastRenderCallbackSlices_ = 0;
    DWORD renderCallCount_ = 0;
    DWORD hostMidiDrainCount_ = 0;
    DWORD hostDelayedMidiRetryCount_ = 0;
    DWORD hostDelayedMidiRetryPasses_ = 0;
    uint32_t nativeMidiLastRead_ = 0xffffffffu;
    DWORD nativeMidiStallQuanta_ = 0;
    DWORD nativeMidiProgressEvents_ = 0;
    DWORD nativeMidiFallbackPasses_ = 0;
    DWORD nativeMidiFallbackEvents_ = 0;
    volatile LONG pendingNoteMsg_ = 0;
    volatile LONG pendingNoteBaselineMatches_ = 0;
    volatile LONG pendingNoteSerial_ = 0;
    DWORD lastTracedPendingNoteSerial_ = 0;
    DWORD noteDispositionCount_ = 0;
    bool genericLayerTraceSeen_[16][128]{};
    std::uint64_t channelDiffSeen_ = 0;
    bool renderFaulted_ = false;
    bool renderEverNonZero_ = false;
    CRITICAL_SECTION midiLock_{};
    bool midiLockInit_ = false;
    CRITICAL_SECTION audioLock_{};
    bool audioLockInit_ = false;
    struct FallbackProgramEntry {
        uint32_t key = 0xffffffffu;
        uint32_t sourceRoot = 0;
        uint32_t stableRoot = 0;
        uint16_t rootType = 0;
    };
    static constexpr uint32_t kFallbackMaxPrograms = 512;
    static constexpr uint32_t kFallbackRootSnapshotBytes = 0x200;
    uint8_t* fallbackProgramDb_ = nullptr;
    uint8_t* fallbackRootPool_ = nullptr;
    std::vector<FallbackProgramEntry> fallbackPrograms_;
    uint32_t fallbackProgramPrefix_ = 0;
    bool fallbackProgramPrefixSet_ = false;
};

}
