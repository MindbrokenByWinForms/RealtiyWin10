#include "host_cpu_accounting.h"
#include "host_cpu_math.h"
#include "log.h"
#include <cstring>
#include <cmath>
namespace reality {
namespace {
uint8_t* image=nullptr;
LARGE_INTEGER frequency{};
const unsigned callOffset=0xAAB52;
const uint8_t originalCall[5]={0xe8,0x19,0x33,0,0};
thread_local bool active=false;
thread_local LARGE_INTEGER started{};
thread_local DWORD spanFrames=0, sampleRate=0;
thread_local double oldScale=0;
volatile LONG reports=0;
using OriginalLoad=DWORD (__cdecl*)(DWORD,DWORD);
using NativeClock=double (__cdecl*)();
using Render=WORD (__cdecl*)(void*,DWORD);

DWORD __cdecl HostLoad(DWORD kind,DWORD detail) {
    if(!active || kind!=0xfffeu)
        return reinterpret_cast<OriginalLoad>(image+0xADE70)(kind,detail);
    LARGE_INTEGER now{};
    if(!QueryPerformanceCounter(&now)) return 0xffffffffu; // fail closed
    const double elapsed=static_cast<double>(now.QuadPart-started.QuadPart);
    const DWORD load=HostCpuPercent(now.QuadPart-started.QuadPart,frequency.QuadPart,spanFrames,sampleRate);
    const LONG n=InterlockedIncrement(&reports);
    if(n<=16 || (n&(n-1))==0) {
        uint32_t state=0, previous=0;std::memcpy(&state,image+0x2A5C4,4);
        if(state) std::memcpy(&previous,reinterpret_cast<void*>(static_cast<uintptr_t>(state+0x264)),4);
        Logf("HOSTCPU sample=%ld frames=%lu rate=%lu elapsedUs=%.3f measuredPercent=%lu previousAdmissionLoad=%lu",n,spanFrames,sampleRate,elapsed*1000000.0/frequency.QuadPart,load,previous);
    }
    return load;
}
bool Begin(DWORD frames,DWORD rate) {
    LARGE_INTEGER start{};
    if(!QueryPerformanceCounter(&start))return false;
    // 8370 and 7F50 are the baseline doubles used by ADE70(FFFE/FFFF).
    // They belong to the omitted VxD callback's accounting, not to the DSP.
    const double now=reinterpret_cast<NativeClock>(image+0x94D10)();
    if(!std::isfinite(now))return false;
    std::memcpy(image+0x8370,&now,8);std::memcpy(image+0x7F50,&now,8);
    std::memcpy(&oldScale,image+0x3F2CC,8);
    // Native clock units are microseconds; account for the host span, rather
    // than retaining the legacy sample/buffer reciprocal from the VxD setup.
    const double spanScale=static_cast<double>(rate)/(1000000.0*frames);
    std::memcpy(image+0x3F2CC,&spanScale,8);
    spanFrames=frames;sampleRate=rate;
    started=start;active=true;return true;
}
void End() {
    if(active)std::memcpy(image+0x3F2CC,&oldScale,8);
    active=false;
}
}
bool InstallHostCpuAccounting(uint8_t* base) {
    if(image)return image==base;
    if(std::memcmp(base+callOffset,originalCall,5)!=0 ||
       !QueryPerformanceFrequency(&frequency) || frequency.QuadPart<=0) return false;
    DWORD old=0;if(!VirtualProtect(base+callOffset,5,PAGE_EXECUTE_READWRITE,&old))return false;
    image=base;reports=0;
    const uint32_t relative=static_cast<uint32_t>(reinterpret_cast<uintptr_t>(&HostLoad)-reinterpret_cast<uintptr_t>(base+callOffset+5));
    std::memcpy(base+callOffset+1,&relative,4);
    FlushInstructionCache(GetCurrentProcess(),base+callOffset,5);
    DWORD ignored=0;VirtualProtect(base+callOffset,5,old,&ignored);
    Logf("HOSTCPU installed: AAB52 -> measured host-span load; original allocation limits preserved");
    return true;
}
void UninstallHostCpuAccounting() {
    if(!image)return;
    DWORD old=0;if(VirtualProtect(image+callOffset,5,PAGE_EXECUTE_READWRITE,&old)) {
        std::memcpy(image+callOffset,originalCall,5);FlushInstructionCache(GetCurrentProcess(),image+callOffset,5);
        DWORD ignored=0;VirtualProtect(image+callOffset,5,old,&ignored);
    }
    image=nullptr;
}
WORD RenderWithHostCpuAccounting(void* buffer,DWORD callbackSlices,DWORD accountingFrames,DWORD rate) {
    // AA9B0's second parameter is not a PCM frame count.  The original
    // SSYNENG worker passes WORD [engine+0x14] (normally 2), while the total
    // PCM byte span is held separately at object1+0x2090A.  Keep CPU
    // accounting based on the real audio duration but preserve AA9B0's native
    // callback ABI.
    if(!image || !callbackSlices || !accountingFrames || !rate || active)return 0xffff;
    WORD result=0xffff;
#if defined(_MSC_VER)
    __try {
        if(Begin(accountingFrames,rate)) result=reinterpret_cast<Render>(image+0xAA9B0)(buffer,callbackSlices);
    } __finally { End(); }
#else
    if(Begin(accountingFrames,rate))result=reinterpret_cast<Render>(image+0xAA9B0)(buffer,callbackSlices);End();
#endif
    return result;
}
}
