#pragma once
#include <windows.h>
#include <cstdint>

namespace reality {
// Experimental user-mode bridge for SSYNENG's Win9x INT 20h VMM/VxD services.
// It patches genuine service sites to INT3 and emulates a small, high-value subset
// from a vectored exception handler. Unknown calls are logged and returned as failure.
bool InstallVmmBridge(uint8_t* object1Base, uint32_t object1Size);
void UninstallVmmBridge();

// Build a synthetic 16:16 pointer understood by SSYNENG's original
// _SelectorMapFlat path. The pointed memory stays owned by the caller.
bool CreateLegacyFarPointer(void* flatBase, uint32_t bytes, uint32_t* farPointer);
void DestroyLegacyFarPointer(uint32_t farPointer);
}
