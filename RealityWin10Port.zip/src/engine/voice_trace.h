#pragma once
#include <windows.h>
#include <cstdint>
namespace reality {
bool InstallVoiceTrace(uint8_t* base);
void UninstallVoiceTrace();
void TraceProgramRoot(uint32_t source, uint32_t stable);
}
