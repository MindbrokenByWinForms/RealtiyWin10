#pragma once
#include <cstdint>
#include <cmath>
namespace reality {
inline uint32_t HostCpuPercent(int64_t elapsed, int64_t frequency, uint32_t frames, uint32_t rate) {
    if(elapsed<0 || frequency<=0 || !frames || !rate)return UINT32_MAX;
    const double p=static_cast<double>(elapsed)*rate*100.0/(static_cast<double>(frequency)*frames);
    if(!std::isfinite(p) || p>=UINT32_MAX)return UINT32_MAX;
    return static_cast<uint32_t>(p);
}
}
