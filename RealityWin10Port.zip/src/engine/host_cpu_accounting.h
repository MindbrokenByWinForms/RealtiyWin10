#pragma once
#include <windows.h>
#include <cstdint>
namespace reality {
bool InstallHostCpuAccounting(uint8_t* image);
void UninstallHostCpuAccounting();
WORD RenderWithHostCpuAccounting(void* buffer, DWORD callbackSlices, DWORD accountingFrames, DWORD rate);
}
