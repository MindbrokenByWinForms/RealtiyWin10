#include "ssyneng_host.h"
#include "vmm_bridge.h"
#include "voice_trace.h"
#include "host_cpu_accounting.h"
#include "reality_clap_bridge_engine.h"
#include "log.h"
#include <fstream>
#include <vector>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <cstdio>

namespace reality {
#pragma pack(push,1)
struct PackHeader { char magic[8]; uint32_t version, objectCount, fixupCount; };
struct PackObj { uint32_t size; };
struct PackFixup {
    uint8_t srcObject, targetObject, kind, reserved;
    uint32_t srcOffset;
    int32_t targetOffset;
};
struct DiocParams32 {
    uint32_t internal1;
    uint32_t vmHandle;
    uint32_t internal2;
    uint32_t code;          // +0x0c
    uint32_t inBuffer;      // +0x10
    uint32_t inLength;      // +0x14
    uint32_t outBuffer;     // +0x18
    uint32_t outLength;     // +0x1c
    uint32_t bytesReturned; // +0x20
};
#pragma pack(pop)
static_assert(sizeof(DiocParams32) == 0x24, "Win9x DIOC parameter layout must stay 32-bit");


static bool HostPumpDisabled() {
    char value[16]{};
    const DWORD n = GetEnvironmentVariableA("REALITY_HOST_ENGINE_PUMP", value, sizeof(value));
    if (!n || n >= sizeof(value)) return false; // v8 default: enabled
    return _stricmp(value, "0") == 0 || _stricmp(value, "false") == 0 ||
           _stricmp(value, "no") == 0 || _stricmp(value, "off") == 0;
}

// Keep this helper POD-only so RenderHostQuantum can safely invoke it from an
// MSVC __try block. A capturing lambda inside __try would make the function
// require C++ object unwinding and can trigger C2712. Any invalid host pointer
// is intentionally handled by the caller's SEH guard.
static void ProbePcmSpan(uint32_t addr, uint32_t spanFrames, uint32_t frameBytes,
                         uint32_t bits, uint32_t* peak, uint32_t* nonZero) {
    if (!addr || !spanFrames || !frameBytes || !peak || !nonZero) return;
    const uint32_t spanBytes = spanFrames * frameBytes;
    if (bits == 16u) {
        const int16_t* p = reinterpret_cast<const int16_t*>(static_cast<uintptr_t>(addr));
        const uint32_t n = spanBytes / 2u;
        for (uint32_t i = 0; i < n; ++i) {
            const int v = static_cast<int>(p[i]);
            const uint32_t a = static_cast<uint32_t>(v < 0 ? -v : v);
            if (a) ++(*nonZero);
            if (a > *peak) *peak = a;
        }
    } else {
        const uint8_t* p = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(addr));
        for (uint32_t i = 0; i < spanBytes; ++i) {
            const uint32_t v = p[i];
            if (v) ++(*nonZero);
            if (v > *peak) *peak = v;
        }
    }
}

static void LogChannelDiff(DWORD msg, unsigned channel, const uint8_t* before,
                           const uint8_t* after, size_t bytes) {
    if (!before || !after || !bytes) return;
    unsigned changed = 0, shown = 0;
    char detail[4096] = {};
    size_t used = 0;
    for (size_t i = 0; i < bytes; ++i) {
        if (before[i] == after[i]) continue;
        ++changed;
        if (shown >= 96 || used + 24 >= sizeof(detail)) continue;
        const int n = std::snprintf(detail + used, sizeof(detail) - used,
                                    "%s+%03lX:%02X>%02X", shown ? " " : "",
                                    static_cast<unsigned long>(i),
                                    static_cast<unsigned>(before[i]), static_cast<unsigned>(after[i]));
        if (n > 0) used += static_cast<size_t>(std::min<int>(n, static_cast<int>(sizeof(detail) - used - 1)));
        ++shown;
    }
    const BYTE status = static_cast<BYTE>(msg & 0xffu);
    const BYTE d1 = static_cast<BYTE>((msg >> 8) & 0x7fu);
    const BYTE d2 = static_cast<BYTE>((msg >> 16) & 0x7fu);
    const char* kind = (status & 0xF0u) == 0xC0u ? "Program" :
                       ((status & 0xF0u) == 0xB0u && d1 == 7u) ? "CC7-volume" :
                       ((status & 0xF0u) == 0xB0u && d1 == 10u) ? "CC10-pan" : "other";
    Logf("SSYNENG channel-diff kind=%s ch=%u msg=%08lX d1=%u d2=%u changedBytes=%u shown=%u %s%s",
         kind, channel, static_cast<unsigned long>(msg), static_cast<unsigned>(d1),
         static_cast<unsigned>(d2), changed, shown, detail,
         changed > shown ? " ..." : "");
}

static bool PatchCodeChecked(SsynengRehost& host, uint32_t off,
                             const uint8_t* expected, size_t expectedLen,
                             const uint8_t* patch, size_t patchLen,
                             const char* name) {
    auto* p = reinterpret_cast<uint8_t*>(host.Ptr(1, off));
    if (!p || expectedLen == 0 || patchLen == 0) {
        Logf("SSYNENG user-mode patch %s: invalid target object1+%05X", name, off);
        return false;
    }
    if (std::memcmp(p, expected, expectedLen) != 0) {
        Logf("SSYNENG user-mode patch %s: signature mismatch at object1+%05X", name, off);
        return false;
    }
    DWORD oldProtect = 0;
    if (!VirtualProtect(p, patchLen, PAGE_EXECUTE_READWRITE, &oldProtect)) {
        Logf("SSYNENG user-mode patch %s: VirtualProtect failed error=%lu", name, GetLastError());
        return false;
    }
    std::memcpy(p, patch, patchLen);
    FlushInstructionCache(GetCurrentProcess(), p, patchLen);
    DWORD ignored = 0;
    VirtualProtect(p, patchLen, oldProtect, &ignored);
    Logf("SSYNENG user-mode patch: %s at object1+%05X", name, off);
    return true;
}

static bool PatchKernelPointerModel(SsynengRehost& host) {
    // Win9x VxDs normally receive ring-0 linear addresses from _PageAllocate.
    // Reality's engine deliberately classifies 0x00100000..0x7fffffff as a
    // user pointer and converts it to NULL before dereferencing.  In our NT
    // user-mode rehost those are exactly the addresses VirtualAlloc returns.
    //
    // Every site below is a signature-verified pointer guard of the form:
    //   cmp reg,00100000h / jbe ...
    //   cmp reg,80000000h / jb  INVALID
    //   ... NULL / -1 checks ...
    // We NOP only the `jb INVALID`.  NULL and 0xffffffff remain invalid, while
    // ordinary NT user addresses are accepted.  This does not touch unrelated
    // 0x80000000 tests used for floating-point sign bits elsewhere in the DSP.
    struct Site { uint32_t branchOff; const char* name; };
    static const Site sites[] = {
        {0xA44F9, "core parameter pointer guard A44E0"},
        {0xA4875, "core parameter pointer guard A485F"},
        {0xA4D4B, "core parameter pointer guard A4D2C"},
        {0xA50DC, "core parameter pointer guard A50CE"},
        {0xA5425, "core parameter pointer guard A540A"},
        {0xA5A8B, "core parameter pointer guard A5A73"},
        {0xA5D26, "core parameter pointer guard A5D0E"},
        {0xA5E4A, "core parameter pointer guard A5E33"},
        {0xA5FE0, "core parameter pointer guard A5FB1"},
        {0xA69B9, "core parameter pointer guard A69AB"},
        {0xA6D92, "pointer validator A6D80"},
        {0xA6DC6, "core pointer accessor A6DB0"},
        {0xA6E5D, "core parameter pointer guard A6E44"},
        {0xA6ED4, "core parameter pointer guard A6EBC"},
        {0xA6F46, "core parameter pointer guard A6F30"},
        {0xA6F79, "core parameter pointer guard A6F63"},
        {0xA6FD6, "core parameter pointer guard A6FC0"},
    };
    static const uint8_t exp[] = {0x72, 0x09};
    static const uint8_t pat[] = {0x90, 0x90};
    bool ok = true;
    for (const auto& s : sites)
        ok &= PatchCodeChecked(host, s.branchOff, exp, sizeof(exp), pat, sizeof(pat), s.name);
    if (ok)
        Logf("SSYNENG user-mode pointer model: accepted NT user pointers at %u verified ring-0 guard sites",
             static_cast<unsigned>(sizeof(sites)/sizeof(sites[0])));
    return ok;
}


static bool InstallNoteOffNullGuard(SsynengRehost& host, uint8_t** outStub) {
    // The original Note-Off path at object1+A4D9D assumes [EBP-8] is a
    // valid note/voice helper and immediately reads byte +0x29.  Under the
    // modern host this can legitimately be null when a Note-Off arrives after
    // a voice was already retired (or after a resource-state transition),
    // producing the recurring C0000005 at allocationRVA A4DDD seen in v13.2.
    // Preserve the original non-null semantics, but treat null as the same
    // fast path as helper+0x29 != 0 and continue at A4DF1.
    static const uint8_t expected[6] = {0x80,0x79,0x29,0x00,0x75,0x4E};
    auto* site = reinterpret_cast<uint8_t*>(host.Ptr(1, 0xA4D9D));
    auto* nullTarget = reinterpret_cast<uint8_t*>(host.Ptr(1, 0xA4DF1));
    auto* fallthrough = reinterpret_cast<uint8_t*>(host.Ptr(1, 0xA4DA3));
    if (!site || !nullTarget || !fallthrough || std::memcmp(site, expected, sizeof(expected)) != 0) {
        Logf("SSYNENG note-off null guard: signature mismatch at object1+A4D9D");
        return false;
    }
    uint8_t* stub = reinterpret_cast<uint8_t*>(VirtualAlloc(nullptr, 64,
        MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE));
    if (!stub) {
        Logf("SSYNENG note-off null guard: trampoline allocation failed error=%lu", GetLastError());
        return false;
    }
    auto emitRel32 = [](uint8_t*& q, uint8_t op1, uint8_t op2, const uint8_t* target, bool twoByte) -> bool {
        uint8_t* start = q;
        if (twoByte) { *q++ = op1; *q++ = op2; }
        else { *q++ = op1; }
        const intptr_t delta = reinterpret_cast<intptr_t>(target) - reinterpret_cast<intptr_t>(q + 4);
        if (delta < INT32_MIN || delta > INT32_MAX) return false;
        const int32_t rel = static_cast<int32_t>(delta);
        std::memcpy(q, &rel, 4); q += 4;
        (void)start;
        return true;
    };
    uint8_t* q = stub;
    *q++ = 0x85; *q++ = 0xC9;                    // test ecx,ecx
    if (!emitRel32(q, 0x0F, 0x84, nullTarget, true)) { VirtualFree(stub,0,MEM_RELEASE); return false; } // jz
    *q++ = 0x80; *q++ = 0x79; *q++ = 0x29; *q++ = 0x00; // cmp byte ptr [ecx+29],0
    if (!emitRel32(q, 0x0F, 0x85, nullTarget, true)) { VirtualFree(stub,0,MEM_RELEASE); return false; } // jne
    if (!emitRel32(q, 0xE9, 0x00, fallthrough, false)) { VirtualFree(stub,0,MEM_RELEASE); return false; } // jmp

    DWORD oldProtect = 0;
    if (!VirtualProtect(site, sizeof(expected), PAGE_EXECUTE_READWRITE, &oldProtect)) {
        VirtualFree(stub,0,MEM_RELEASE); return false;
    }
    site[0] = 0xE9;
    const intptr_t delta = reinterpret_cast<intptr_t>(stub) - reinterpret_cast<intptr_t>(site + 5);
    if (delta < INT32_MIN || delta > INT32_MAX) {
        DWORD ignored=0; VirtualProtect(site,sizeof(expected),oldProtect,&ignored);
        VirtualFree(stub,0,MEM_RELEASE); return false;
    }
    const int32_t rel = static_cast<int32_t>(delta);
    std::memcpy(site + 1, &rel, 4);
    site[5] = 0x90;
    FlushInstructionCache(GetCurrentProcess(), site, sizeof(expected));
    FlushInstructionCache(GetCurrentProcess(), stub, static_cast<SIZE_T>(q-stub));
    DWORD ignored=0; VirtualProtect(site,sizeof(expected),oldProtect,&ignored);
    if (outStub) *outStub = stub;
    Logf("SSYNENG user-mode patch: note-off null helper guard object1+A4D9D trampoline=%p", stub);
    return true;
}

static bool PatchRing0Helpers(SsynengRehost& host) {
    // These routines are not synth DSP. They are the Win9x ring-0 CPU/interrupt
    // support used while VSEERD starts. Executing them inside a normal NT process
    // raises STATUS_PRIVILEGED_INSTRUCTION before the engine-ready flag is set.
    // Replace only signatures verified against the supplied Reality 1.5 SSYNENG.
    bool ok = true;

    {   // Disable CR0.EM clearing in ring 3.
        static const uint8_t exp[] = {0xB8,0,0,0,0,0x0F,0x20,0xC0};
        static const uint8_t pat[] = {0x31,0xC0,0xC3}; // xor eax,eax; ret
        ok &= PatchCodeChecked(host, 0x905B8, exp, sizeof(exp), pat, sizeof(pat), "CR0.EM clear helper -> no-op");
    }
    {   // Disable CR0.EM setting in ring 3.
        static const uint8_t exp[] = {0xB8,0,0,0,0,0x0F,0x20,0xC0};
        static const uint8_t pat[] = {0x31,0xC0,0xC3};
        ok &= PatchCodeChecked(host, 0x905C7, exp, sizeof(exp), pat, sizeof(pat), "CR0.EM set helper -> no-op");
    }
    {   // Original reads CR0.TS then CLTS. Return TS clear and do not touch CR0.
        static const uint8_t exp[] = {0xB8,0,0,0,0,0x0F,0x20,0xC0,0x83,0xE0,0x08,0x0F,0x06};
        static const uint8_t pat[] = {0x31,0xC0,0xC3};
        ok &= PatchCodeChecked(host, 0x905D6, exp, sizeof(exp), pat, sizeof(pat), "CR0.TS/CLTS helper -> TS clear");
    }
    {   // Restore-TS helper takes a bit on the stack. NT owns task switching/FPU state.
        static const uint8_t exp[] = {0x8B,0x44,0x24,0x04,0x83,0xE0,0x08,0x0F,0x20,0xC1};
        static const uint8_t pat[] = {0xC3};
        ok &= PatchCodeChecked(host, 0x905E4, exp, sizeof(exp), pat, sizeof(pat), "CR0.TS restore helper -> no-op");
    }
    {   // Legacy PIT channel-0 read uses OUT/IN, both privileged under NT. RDTSC
        // supplies the same property the callers need here: a fast changing counter.
        static const uint8_t exp[] = {0xE6,0x43,0x90,0x90,0x90,0x90};
        static const uint8_t pat[] = {0x0F,0x31,0xC3}; // rdtsc; ret
        ok &= PatchCodeChecked(host, 0x90600, exp, sizeof(exp), pat, sizeof(pat), "8254 PIT read -> RDTSC");
    }
    {   // 386/486/Pentium CPU-family probe toggles EFLAGS under CLI/STI. Reality only
        // branches on family >= 5; report family 6 and let its later CPUID feature tests run.
        static const uint8_t exp[] = {0x53,0x51,0x52,0xFA,0x9C,0x58,0x8B,0xD8};
        static const uint8_t pat[] = {0xB8,0x06,0x00,0x00,0x00,0xC3}; // mov eax,6; ret
        ok &= PatchCodeChecked(host, 0x9061D, exp, sizeof(exp), pat, sizeof(pat), "CPU family probe -> family 6");
    }
    {   // Installs VxD handlers directly into the IDT with SIDT/CLI/STI. The NT
        // user-mode host must never modify the kernel IDT; scheduling is replaced elsewhere.
        static const uint8_t exp[] = {0x55,0x8B,0xEC,0x51,0x56,0x57,0x66,0x8C,0xD8,0x66};
        static const uint8_t pat[] = {0xC3};
        ok &= PatchCodeChecked(host, 0xAF240, exp, sizeof(exp), pat, sizeof(pat), "IDT hook installer -> no-op");
    }
    {   // Matching IDT restore routine.
        static const uint8_t exp[] = {0x56,0x0F,0x01,0x0D};
        static const uint8_t pat[] = {0xC3};
        ok &= PatchCodeChecked(host, 0xAF2E0, exp, sizeof(exp), pat, sizeof(pat), "IDT hook remover -> no-op");
    }
    return ok;
}

SsynengRehost::~SsynengRehost() { Unload(); }
void SsynengRehost::Unload() {
    StopHostPump();
    if (bridgeArmed_) { UninstallVmmBridge(); bridgeArmed_ = false; }
    UninstallVoiceTrace();
    UninstallHostCpuAccounting();
    if (midiLockInit_) { DeleteCriticalSection(&midiLock_); midiLockInit_ = false; }
    if (audioLockInit_) { DeleteCriticalSection(&audioLock_); audioLockInit_ = false; }
    if (fallbackProgramDb_) {
        VirtualFree(fallbackProgramDb_, 0, MEM_RELEASE);
        fallbackProgramDb_ = nullptr;
    }
    if (fallbackRootPool_) {
        VirtualFree(fallbackRootPool_, 0, MEM_RELEASE);
        fallbackRootPool_ = nullptr;
    }
    fallbackPrograms_.clear();
    fallbackProgramPrefix_ = 0;
    fallbackProgramPrefixSet_ = false;
    if (noteOffNullGuardStub_) {
        VirtualFree(noteOffNullGuardStub_, 0, MEM_RELEASE);
        noteOffNullGuardStub_ = nullptr;
    }
    for (auto& o : objects_) if (o.allocation) VirtualFree(o.allocation, 0, MEM_RELEASE);
    objects_.clear();
    coreInitAttempted_ = false;
    startRequested_ = false;
    lifecycleReady_ = false;
    modernAudioRegistered_ = false;
    legacyOutputOpened_ = false;
    InterlockedExchange(&modernAudioBuffer_, 0);
    InterlockedExchange(&modernAudioBytes_, 0);
    renderCursorBytes_ = 0;
    if (renderScratch_) { VirtualFree(renderScratch_, 0, MEM_RELEASE); renderScratch_ = nullptr; }
    renderScratchBytes_ = 0;
    lastRenderCallbackBytes_ = 0;
    lastRenderCallbackSlices_ = 0;
    renderCallCount_ = 0;
    hostMidiDrainCount_ = 0;
    channelDiffSeen_ = 0;
    renderFaulted_ = false;
}
void* SsynengRehost::Ptr(uint32_t oi, uint32_t off) const {
    if (!oi || oi > objects_.size()) return nullptr;
    const auto& o = objects_[oi-1];
    if (off >= o.size) return nullptr;
    return o.base + off;
}
void* SsynengRehost::PtrSigned(uint32_t oi, int32_t off) const {
    if (!oi || oi > objects_.size()) return nullptr;
    const auto& o = objects_[oi-1];
    if (off < -static_cast<int32_t>(kGuardBytes) || off >= static_cast<int32_t>(o.size)) return nullptr;
    return o.base + off;
}

bool SsynengRehost::LoadPack(const std::wstring& path) {
    Unload();
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    PackHeader h{}; f.read(reinterpret_cast<char*>(&h), sizeof(h));
    if (!f || std::memcmp(h.magic, "SSYNRH1", 7) != 0 || h.version != 1 || h.objectCount == 0) return false;
    std::vector<PackObj> meta(h.objectCount);
    f.read(reinterpret_cast<char*>(meta.data()), meta.size()*sizeof(PackObj));
    objects_.resize(h.objectCount);
    for (uint32_t i=0; i<h.objectCount; ++i) {
        objects_[i].size = meta[i].size;
        const SIZE_T allocSize = static_cast<SIZE_T>(meta[i].size) + 2u*kGuardBytes;
        objects_[i].allocation = reinterpret_cast<uint8_t*>(VirtualAlloc(nullptr, allocSize,
            MEM_RESERVE|MEM_COMMIT, PAGE_EXECUTE_READWRITE));
        if (!objects_[i].allocation) { Unload(); return false; }
        objects_[i].base = objects_[i].allocation + kGuardBytes;
        std::memset(objects_[i].allocation, 0, allocSize);
        f.read(reinterpret_cast<char*>(objects_[i].base), meta[i].size);
        if (!f) { Unload(); return false; }
    }
    std::vector<PackFixup> fx(h.fixupCount);
    f.read(reinterpret_cast<char*>(fx.data()), fx.size()*sizeof(PackFixup));
    if (!f) { Unload(); return false; }
    for (auto& x : fx) {
        auto* src = reinterpret_cast<uint8_t*>(Ptr(x.srcObject, x.srcOffset));
        auto* dst = reinterpret_cast<uint8_t*>(PtrSigned(x.targetObject, x.targetOffset));
        if (!src || !dst) {
            Logf("bad rehost fixup src=%u:%X dst=%u:%X", x.srcObject,x.srcOffset,x.targetObject,x.targetOffset);
            Unload(); return false;
        }
        if (x.kind == 7) {
            const uint32_t v = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(dst));
            std::memcpy(src, &v, 4);
        } else if (x.kind == 8) {
            const intptr_t delta = dst - (src + 4);
            if (delta < INT32_MIN || delta > INT32_MAX) { Unload(); return false; }
            const int32_t rel = static_cast<int32_t>(delta);
            std::memcpy(src, &rel, 4);
        } else {
            Logf("unsupported fixup kind=%u", x.kind); Unload(); return false;
        }
    }
    if (!PatchRing0Helpers(*this) || !PatchKernelPointerModel(*this)) {
        Logf("SSYNENG user-mode kernel-assumption patch set incomplete; refusing unsafe rehost startup");
        Unload();
        return false;
    }
    if (!InstallHostCpuAccounting(reinterpret_cast<uint8_t*>(Ptr(1, 0)))) { Unload(); return false; }
    if (!InstallVoiceTrace(reinterpret_cast<uint8_t*>(Ptr(1, 0)))) { Unload(); return false; }
    if (!InstallNoteOffNullGuard(*this, &noteOffNullGuardStub_)) { Unload(); return false; }
    FlushInstructionCache(GetCurrentProcess(), nullptr, 0);
    Logf("loaded SSYNENG rehost pack: objects=%u fixups=%u; ring-0 startup helpers patched", h.objectCount, h.fixupCount);
    return true;
}

bool SsynengRehost::ArmVmmBridge() {
    if (bridgeArmed_) return true;
    if (objects_.empty()) return false;
    bridgeArmed_ = InstallVmmBridge(objects_[0].base, objects_[0].size);
    if (bridgeArmed_ && !midiLockInit_) {
        InitializeCriticalSection(&midiLock_);
        midiLockInit_ = true;
    }
    if (bridgeArmed_ && !audioLockInit_) {
        InitializeCriticalSection(&audioLock_);
        audioLockInit_ = true;
    }
    return bridgeArmed_;
}

bool SsynengRehost::CoreReady() const {
    // SSYNENG's ordinary DeviceIoControl dispatcher calls 0x8EA80, which simply
    // returns object1[0x3C19C].  When this flag is zero the VxD returns 0x15
    // (ERROR_NOT_READY) for normal synth IOCTLs.
    auto* flag = reinterpret_cast<const volatile uint32_t*>(Ptr(1, 0x3C19C));
    return flag && *flag != 0;
}

static uint32_t ReadRehostU32(const SsynengRehost& host, uint32_t off) {
    auto* p = reinterpret_cast<const volatile uint32_t*>(host.Ptr(1, off));
    return p ? *p : 0;
}

static void LogCoreState(const SsynengRehost& host, const char* tag) {
    const uint32_t core   = ReadRehostU32(host, 0x3C190);
    const uint32_t scratch= ReadRehostU32(host, 0x3C194);
    const uint32_t ready  = ReadRehostU32(host, 0x3C19C);
    const uint32_t phase  = ReadRehostU32(host, 0x3C1A0);
    const uint32_t alias  = ReadRehostU32(host, 0x2A5C4);
    const uint32_t chan   = ReadRehostU32(host, 0x208A0);
    Logf("SSYNENG core state %s: core=%08lX core+304=%08lX scratch=%08lX alias=%08lX channelBlock=%08lX ready=%lu phase=%08lX",
         tag, core, core ? core + 0x304u : 0u, scratch, alias, chan, ready, phase);
}

#if defined(_MSC_VER)
static LONG CoreInitExceptionFilter(EXCEPTION_POINTERS* ep, SsynengRehost* host) {
    if (host) LogCoreState(*host, "at exception");
    if (ep && ep->ExceptionRecord && ep->ContextRecord) {
        const uintptr_t ip = reinterpret_cast<uintptr_t>(ep->ExceptionRecord->ExceptionAddress);
        const uintptr_t base = host ? reinterpret_cast<uintptr_t>(host->Ptr(1, 0)) : 0;
        const uint32_t off = (base && ip >= base && ip - base < 0x01000000u)
                           ? static_cast<uint32_t>(ip - base) : 0xffffffffu;
        auto* c = ep->ContextRecord;
        Logf("SSYNENG core init precise exception: code=%08lX address=%08lX object1RVA=%08lX EAX=%08lX EBX=%08lX ECX=%08lX EDX=%08lX ESI=%08lX EDI=%08lX EBP=%08lX ESP=%08lX",
             ep->ExceptionRecord->ExceptionCode, static_cast<DWORD>(ip), off,
             c->Eax,c->Ebx,c->Ecx,c->Edx,c->Esi,c->Edi,c->Ebp,c->Esp);
        if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION &&
            ep->ExceptionRecord->NumberParameters >= 2) {
            Logf("SSYNENG core init access violation: operation=%lu faultAddress=%08lX",
                 static_cast<DWORD>(ep->ExceptionRecord->ExceptionInformation[0]),
                 static_cast<DWORD>(ep->ExceptionRecord->ExceptionInformation[1]));
        }
    }
    return EXCEPTION_EXECUTE_HANDLER;
}
#endif

bool SsynengRehost::InitializeCore() {
    if (!bridgeArmed_) {
        Logf("SSYNENG core init requested before VMM bridge was armed");
        return false;
    }
    if (CoreReady()) return true;
    if (coreInitAttempted_) {
        Logf("SSYNENG core init already attempted and is still not ready; not repeating partial Win9x startup");
        return false;
    }
    coreInitAttempted_ = true;

    // In the original Win9x stack this is reached through SSYNENG's protected-
    // mode API dispatcher (0xB1B50) when SSYNMIDI.DRV sends DI=1, BX=0.
    // That dispatcher calls this exact no-argument routine at object1+0x8EC00.
    // Our native MIDI replacement removes the old 16-bit .DRV, so reproduce the
    // same engine-start transition directly rather than fabricating IOCTL success.
    auto* entry = Ptr(1, 0x8EC00);
    if (!entry) {
        Logf("SSYNENG core init entry object1+8EC00 unavailable");
        return false;
    }

    Logf("SSYNENG core init: invoking original PM-API startup routine 8EC00 (ready before=%u)",
         CoreReady() ? 1u : 0u);
    LogCoreState(*this, "before 8EC00");
    using InitFn = DWORD (__cdecl*)();
    auto fn = reinterpret_cast<InitFn>(entry);
    DWORD rc = 0;
#if defined(_MSC_VER)
    __try {
        rc = fn();
    } __except(CoreInitExceptionFilter(GetExceptionInformation(), this)) {
        DWORD ex = GetExceptionCode();
        Logf("SSYNENG core init exception code=%08lX", ex);
        return false;
    }
#else
    rc = fn();
#endif
    const bool ready = CoreReady();
    LogCoreState(*this, "after 8EC00");
    Logf("SSYNENG core init: original routine returned %lu; ready after=%u", rc, ready ? 1u : 0u);
    return ready;
}

BOOL SsynengRehost::DispatchIoctl(DWORD code, LPVOID inBuf, DWORD inLen,
                                  LPVOID outBuf, DWORD outLen, LPDWORD bytesReturned) {
    if (!bridgeArmed_) { SetLastError(ERROR_NOT_READY); return FALSE; }

    // The old 16-bit SSYNMIDI.DRV performed the protected-mode API startup before
    // ordinary synth IOCTLs were allowed through.  In the native port that driver
    // no longer exists, so lazily perform the identical original core initializer
    // when the first gated command arrives.  Keep the historically ungated query/
    // backdoor families untouched.
    const bool ungated = (code == 0x1001u) || ((code & 0xF000u) == 0x9000u) ||
                         ((code & 0xFF00u) == 0x2100u) || (code == 0xFFFFFFFFu);
    if (!ungated && !CoreReady()) {
        Logf("SSYNENG gated IOCTL %04lX arrived with core not ready; reproducing legacy PM startup", code);
        if (!InitializeCore()) {
            Logf("SSYNENG core initialization is still incomplete; dispatching %04lX for diagnostic parity", code);
        }
    }

    if (code == 0x4001u) {
        uint32_t db = 0;
        bool readable = false;
#if defined(_MSC_VER)
        __try {
            if (inBuf && inLen >= 4u) { std::memcpy(&db, inBuf, sizeof(db)); readable = true; }
        } __except(EXCEPTION_EXECUTE_HANDLER) { readable = false; }
#else
        if (inBuf && inLen >= 4u) { std::memcpy(&db, inBuf, sizeof(db)); readable = true; }
#endif
        Logf("SSYNENG IOCTL4001 SetBanksetPointer db=%08lX readable=%u",
             static_cast<unsigned long>(db), readable ? 1u : 0u);
    }

    auto* entry = Ptr(1, 0xAE450);
    if (!entry) { SetLastError(ERROR_PROC_NOT_FOUND); return FALSE; }
    if (bytesReturned) *bytesReturned = 0;
    DiocParams32 p{};
    p.vmHandle = 1;
    p.code = code;
    p.inBuffer = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(inBuf));
    p.inLength = inLen;
    p.outBuffer = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(outBuf));
    p.outLength = outLen;
    p.bytesReturned = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(bytesReturned));

    using Dispatcher = DWORD (__cdecl*)(DiocParams32*);
    auto fn = reinterpret_cast<Dispatcher>(entry);
    DWORD rc = ERROR_GEN_FAILURE;
#if defined(_MSC_VER)
    __try {
        rc = fn(&p);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        rc = GetExceptionCode();
        Logf("SSYNENG rehost exception code=%08lX during IOCTL %04lX", rc, code);
        SetLastError(rc);
        return FALSE;
    }
#else
    rc = fn(&p);
#endif
    // The original 0x5000 channel/part setters return their DIOC parameter
    // block after completing the operation.  Win9x's VxD control wrapper
    // consumed that internal pointer; it was never a Win32 error code.  The
    // user-mode boundary must therefore normalize only this verified ABI
    // success token while preserving genuine errors such as 21 and 87.
    const DWORD requestToken = static_cast<DWORD>(reinterpret_cast<uintptr_t>(&p));
    if ((code & 0xF000u) == 0x5000u && rc == requestToken) {
        Logf("SSYNENG dispatcher normalized legacy request-token success=%08lX for IOCTL %04lX",
             rc, code);
        rc = ERROR_SUCCESS;
    }
    if (rc != ERROR_SUCCESS) {
        Logf("SSYNENG original dispatcher returned %lu for IOCTL %04lX", rc, code);
        SetLastError(rc);
        return FALSE;
    }

    if (code == 0x4001u) {
        DumpSynthState("after IOCTL4001 bankset handoff");
    }

    // SynMid's 32-bit audio manager opens and starts DirectSound/WaveOut itself
    // and hands SSYNENG a *temporarily locked* DirectSound region through
    // 0x7002.  In the observed ABI word[0]==0x0A registers/starts the mapping
    // and word[0]==0x0B unregisters/stops it immediately before SynMid calls
    // IDirectSoundBuffer::Unlock.  V11 treated both operations as a permanent
    // registration, leaving the host renderer writing through a stale lock
    // pointer after op 0x0B.
    if (code == 0x7002u) {
        uint32_t audioOp = 0xffffffffu;
        if (inBuf && inLen >= sizeof(audioOp)) {
#if defined(_MSC_VER)
            __try { std::memcpy(&audioOp, inBuf, sizeof(audioOp)); }
            __except(EXCEPTION_EXECUTE_HANDLER) { audioOp = 0xffffffffu; }
#else
            std::memcpy(&audioOp, inBuf, sizeof(audioOp));
#endif
        }
        if (audioOp == 0x0Bu) {
            DeactivateModernAudio("IOCTL 7002 op=0B/unlock");
        } else if (audioOp == 0x0Au) {
            ConfigureModernAudio(inBuf, inLen);
            bool first = false, mapped = false;
            if (audioLockInit_) EnterCriticalSection(&audioLock_);
            mapped = InterlockedCompareExchange(&modernAudioBuffer_, 0, 0) != 0 &&
                     InterlockedCompareExchange(&modernAudioBytes_, 0, 0) > 0;
            if (mapped) {
                first = !modernAudioRegistered_;
                modernAudioRegistered_ = true;
            }
            if (audioLockInit_) LeaveCriticalSection(&audioLock_);
            if (mapped) {
                // The original service-3 backend sets engineState+0x258 only
                // after its callback transport has opened successfully.  The
                // NT 0x7002 op=0A handoff is the equivalent successful start.
                MarkModernOutputRunning("IOCTL 7002 op=0A");
                EnsureHostPump();
                if (first) {
                    Logf("SSYNENG modern audio transport active via IOCTL 7002 op=0A (legacy B6E90 open bypassed)");
                    DumpSynthState("after modern audio registration");
                    DumpRenderContract("after modern audio registration");
                }
            }
        } else {
            Logf("SSYNENG modern audio transport unknown IOCTL 7002 op=%08lX; mapping unchanged", audioOp);
        }
    }

    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

BOOL SsynengRehost::ControlState(void* legacyState, DWORD stateBytes) {
    if (!legacyState || stateBytes < 0x540u || !bridgeArmed_) {
        SetLastError(ERROR_INVALID_PARAMETER);
        return FALSE;
    }
    if (!CoreReady() && !InitializeCore()) {
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }

    auto* b = static_cast<uint8_t*>(legacyState);
    auto* masks = reinterpret_cast<uint32_t*>(b);
    const bool query = (masks[0] & 1u) != 0;
    if (!query && (masks[1] & 0x20000000u) && stateBytes >= 0x210u) {
        uint32_t requestedRate = 0;
        std::memcpy(&requestedRate, b + 0x20C, sizeof(requestedRate));
        Logf("SSYNENG service17 sample-rate SET requested=%lu liveTransport=%lu registered=%u",
             static_cast<unsigned long>(requestedRate),
             static_cast<unsigned long>(InterlockedCompareExchange(&modernAudioRate_, 0, 0)),
             modernAudioRegistered_ ? 1u : 0u);
    }
    Logf("SSYNENG service17 %s masks=%08lX %08lX %08lX %08lX %08lX %08lX %08lX %08lX",
         query ? "GET" : "SET",
         masks[0], masks[1], masks[2], masks[3], masks[4], masks[5], masks[6], masks[7]);
    if (!query && (masks[2] & 0x00000001u) && stateBytes >= 0x540u) {
        const uint32_t db = *reinterpret_cast<uint32_t*>(b + 0x53Cu);
        Logf("SSYNENG service17 SET bit64 programDb=%08lX", db);
    }

    uint32_t farPointer = 0;
    if (!CreateLegacyFarPointer(legacyState, stateBytes, &farPointer)) {
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return FALSE;
    }

    // 0x94FE0 is the body used by protected-mode service AX=0011 after the
    // Win16 DS:offset has been translated to a linear pointer. Its first
    // argument is unused in this build; the second is the legacy far pointer.
    using TransferFn = WORD (__cdecl*)(void*, uint32_t);
    auto* entry = reinterpret_cast<TransferFn>(Ptr(1, 0x94FE0));
    WORD rc = 1;
#if defined(_MSC_VER)
    __try {
        rc = entry ? entry(nullptr, farPointer) : 1;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        const DWORD ex = GetExceptionCode();
        DestroyLegacyFarPointer(farPointer);
        Logf("SSYNENG service17 exception=%08lX state=%p", ex, legacyState);
        SetLastError(ex);
        return FALSE;
    }
#else
    rc = entry ? entry(nullptr, farPointer) : 1;
#endif
    DestroyLegacyFarPointer(farPointer);

    if (rc != 0) {
        Logf("SSYNENG service17 returned %u", static_cast<unsigned>(rc));
        SetLastError(ERROR_GEN_FAILURE);
        return FALSE;
    }

    if (!query && (masks[2] & 0x00000001u)) DumpSynthState("after service17 bit64 bankset handoff");
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

uint32_t SsynengRehost::ReadObjectU32(uint32_t offset) const {
    auto* p = reinterpret_cast<const volatile uint32_t*>(Ptr(1, offset));
    return p ? *p : 0u;
}

DWORD SsynengRehost::GetProgramDatabasePointer() const {
    return ReadObjectU32(0x3C510);
}

bool SsynengRehost::RebuildFallbackProgramDatabase() {
    if (fallbackPrograms_.empty() || !CoreReady()) return false;

    // The recovered SSYNENG database layout is:
    //   +0x00 DWORD recordCount
    //   +0x0C first 0x18-byte program record
    //   record+0x04 -> program/root object
    //   record+0x10 -> ready byte checked by A4BD0
    //
    // v6 stored SynHigh's command-41 pointer directly in record+4.  The loader
    // recycles those small root objects, so a later SetProgramDatabase pass
    // dereferenced a stale root+0xA0 and faulted.  v7 points records at a stable
    // 0x200-byte snapshot pool instead.  The real deep sample/model pointers in
    // each root remain untouched.
    constexpr SIZE_T kDbBytes = 0x0Cu + kFallbackMaxPrograms * 0x18u;
    if (fallbackPrograms_.size() > kFallbackMaxPrograms) {
        Logf("SSYNENG fallback program DB overflow programs=%u max=%u",
             static_cast<unsigned>(fallbackPrograms_.size()), kFallbackMaxPrograms);
        return false;
    }
    if (!fallbackProgramDb_) {
        fallbackProgramDb_ = reinterpret_cast<uint8_t*>(VirtualAlloc(
            nullptr, kDbBytes, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE));
        if (!fallbackProgramDb_) {
            Logf("SSYNENG fallback program DB allocation failed error=%lu", GetLastError());
            return false;
        }
        std::memset(fallbackProgramDb_, 0, kDbBytes);
        Logf("SSYNENG fallback program DB allocated base=%p bytes=%lu",
             fallbackProgramDb_, static_cast<unsigned long>(kDbBytes));
    }

    // Publish count last so the engine never walks a half-written new record.
    const uint32_t zeroCount = 0;
    std::memcpy(fallbackProgramDb_ + 0x00, &zeroCount, sizeof(zeroCount));
    for (uint32_t i = 0; i < static_cast<uint32_t>(fallbackPrograms_.size()); ++i) {
        uint8_t* rec = fallbackProgramDb_ + 0x0C + i * 0x18u;
        std::memset(rec, 0, 0x18u);
        const uint32_t stableRoot = fallbackPrograms_[i].stableRoot;
        std::memcpy(rec + 0x04, &stableRoot, sizeof(stableRoot));
        rec[0x10] = 1;
    }
    MemoryBarrier();
    const uint32_t count = static_cast<uint32_t>(fallbackPrograms_.size());
    std::memcpy(fallbackProgramDb_ + 0x00, &count, sizeof(count));

    if (fallbackProgramPrefixSet_) {
        auto* prefix = reinterpret_cast<uint32_t*>(Ptr(1, 0x3C514));
        if (prefix) *prefix = fallbackProgramPrefix_;
    }

    const uint32_t fallbackDb = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(fallbackProgramDb_));
    const uint32_t currentDb = ReadObjectU32(0x3C510);
    if (currentDb == fallbackDb) {
        // The real driver installs one complete database, then mutates/uses it.
        // Do not repeatedly call 0x922E0 for every command-41 object.  Besides
        // being unnecessary, that caused v6 to rescan transient roots while the
        // loader was still recycling them.
        Logf("SSYNENG fallback program DB updated in-place db=%08lX records=%lu prefix=%08lX",
             currentDb, static_cast<unsigned long>(count), fallbackProgramPrefix_);
        return true;
    }
    if (currentDb != 0u) {
        Logf("SSYNENG fallback program DB install skipped: genuine db=%08lX superseded fallback=%08lX",
             currentDb, fallbackDb);
        return true;
    }

    using SetDatabaseFn = void (__cdecl*)(void*);
    auto* setDb = reinterpret_cast<SetDatabaseFn>(Ptr(1, 0x922E0));
    if (!setDb) return false;
#if defined(_MSC_VER)
    __try {
        setDb(fallbackProgramDb_);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG fallback SetProgramDatabase exception=%08lX", GetExceptionCode());
        SetLastError(GetExceptionCode());
        return false;
    }
#else
    setDb(fallbackProgramDb_);
#endif
    const uint32_t installed = ReadObjectU32(0x3C510);
    const bool ok = installed == fallbackDb;
    Logf("SSYNENG fallback program DB installed=%u db=%08lX records=%lu prefix=%08lX stableRoots=1",
         ok ? 1u : 0u, installed, static_cast<unsigned long>(count), fallbackProgramPrefix_);
    return ok;
}

BOOL SsynengRehost::RegisterProgramRoot(DWORD rootPointer, WORD channelHint) {
    if (!bridgeArmed_ || (!CoreReady() && !InitializeCore())) {
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }
    if (!PointerReadable(rootPointer, 0xA4u)) {
        Logf("SSYNENG program-root registration rejected root=%08lX channel=%u unreadable",
             static_cast<unsigned long>(rootPointer), static_cast<unsigned>(channelHint));
        SetLastError(ERROR_INVALID_ADDRESS);
        return FALSE;
    }

    uint32_t key = 0xffffffffu;
    uint16_t rootType = 0;
#if defined(_MSC_VER)
    __try {
#endif
        const auto* root = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(rootPointer));
        std::memcpy(&rootType, root + 0x04, sizeof(rootType));
        std::memcpy(&key, root + 0xA0, sizeof(key));
#if defined(_MSC_VER)
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        SetLastError(GetExceptionCode());
        return FALSE;
    }
#endif
    if (key == 0xffffffffu) {
        Logf("SSYNENG program-root registration rejected root=%08lX channel=%u key=FFFFFFFF",
             static_cast<unsigned long>(rootPointer), static_cast<unsigned>(channelHint));
        SetLastError(ERROR_INVALID_DATA);
        return FALSE;
    }

    const uint32_t currentDb = ReadObjectU32(0x3C510);
    const uint32_t fallbackDb = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(fallbackProgramDb_));
    if (currentDb && currentDb != fallbackDb) {
        Logf("SSYNENG program-root root=%08lX key=%08lX type=%u channel=%u realDb=%08lX (fallback bypassed)",
             static_cast<unsigned long>(rootPointer), key, static_cast<unsigned>(rootType),
             static_cast<unsigned>(channelHint), currentDb);
        SetLastError(ERROR_SUCCESS);
        return TRUE;
    }

    const uint32_t prefix = key >> 21;
    if (!fallbackProgramPrefixSet_) {
        fallbackProgramPrefix_ = prefix;
        fallbackProgramPrefixSet_ = true;
    } else if (prefix != fallbackProgramPrefix_) {
        Logf("SSYNENG fallback program DB namespace change old=%08lX new=%08lX root=%08lX",
             fallbackProgramPrefix_, prefix, static_cast<unsigned long>(rootPointer));
        // One SSYNENG database has one global prefix.  Prefer the newest loader
        // namespace, but leave existing snapshots intact for diagnostics.
        fallbackProgramPrefix_ = prefix;
    }

    if (!fallbackRootPool_) {
        const SIZE_T poolBytes = static_cast<SIZE_T>(kFallbackMaxPrograms) * kFallbackRootSnapshotBytes;
        fallbackRootPool_ = reinterpret_cast<uint8_t*>(VirtualAlloc(
            nullptr, poolBytes, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE));
        if (!fallbackRootPool_) {
            Logf("SSYNENG stable root pool allocation failed bytes=%lu error=%lu",
                 static_cast<unsigned long>(poolBytes), GetLastError());
            SetLastError(ERROR_NOT_ENOUGH_MEMORY);
            return FALSE;
        }
        std::memset(fallbackRootPool_, 0, poolBytes);
        Logf("SSYNENG stable root pool allocated base=%p bytes=%lu slotBytes=%u",
             fallbackRootPool_, static_cast<unsigned long>(poolBytes), kFallbackRootSnapshotBytes);
    }

    size_t index = static_cast<size_t>(-1);
    for (size_t i = 0; i < fallbackPrograms_.size(); ++i) {
        if (fallbackPrograms_[i].key == key) { index = i; break; }
    }
    bool added = false;
    if (index == static_cast<size_t>(-1)) {
        if (fallbackPrograms_.size() >= kFallbackMaxPrograms) {
            SetLastError(ERROR_NOT_ENOUGH_MEMORY);
            return FALSE;
        }
        index = fallbackPrograms_.size();
        FallbackProgramEntry e{};
        e.key = key;
        e.stableRoot = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(
            fallbackRootPool_ + index * kFallbackRootSnapshotBytes));
        fallbackPrograms_.push_back(e);
        added = true;
    }

    auto& entry = fallbackPrograms_[index];
    uint8_t* stable = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(entry.stableRoot));

    // Determine how much of the transient root is readable.  Observed SynHigh
    // roots are 0x200-byte slots; retain a conservative partial-copy fallback
    // so an unusual final slot still carries all fields used by SSYNENG.
    SIZE_T copyBytes = kFallbackRootSnapshotBytes;
    MEMORY_BASIC_INFORMATION mbi{};
    if (VirtualQuery(reinterpret_cast<const void*>(static_cast<uintptr_t>(rootPointer)), &mbi, sizeof(mbi)) == sizeof(mbi)) {
        const uintptr_t regionEnd = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
        const uintptr_t rootAddr = static_cast<uintptr_t>(rootPointer);
        const SIZE_T available = regionEnd > rootAddr ? static_cast<SIZE_T>(regionEnd - rootAddr) : 0u;
        if (available < copyBytes) copyBytes = available;
    }
    if (copyBytes < 0xA4u) {
        Logf("SSYNENG program-root snapshot rejected root=%08lX readableBytes=%lu",
             static_cast<unsigned long>(rootPointer), static_cast<unsigned long>(copyBytes));
        SetLastError(ERROR_INVALID_ADDRESS);
        return FALSE;
    }

    std::memset(stable, 0, kFallbackRootSnapshotBytes);
#if defined(_MSC_VER)
    __try {
#endif
        std::memcpy(stable, reinterpret_cast<const void*>(static_cast<uintptr_t>(rootPointer)), copyBytes);
#if defined(_MSC_VER)
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG stable root snapshot copy exception=%08lX source=%08lX bytes=%lu",
             GetExceptionCode(), static_cast<unsigned long>(rootPointer), static_cast<unsigned long>(copyBytes));
        SetLastError(GetExceptionCode());
        return FALSE;
    }
#endif

    // Preserve simple self-relative pointers after moving the root object.  Deep
    // sample/model pointers outside the root slot remain the real SynHigh-owned
    // addresses and are intentionally not rewritten.
    unsigned selfFixups = 0;
    for (SIZE_T off = 0; off + 4 <= copyBytes; off += 4) {
        uint32_t value = 0;
        std::memcpy(&value, stable + off, 4);
        if (value >= rootPointer && value < rootPointer + copyBytes) {
            const uint32_t rebased = entry.stableRoot + (value - rootPointer);
            std::memcpy(stable + off, &rebased, 4);
            ++selfFixups;
        }
    }
    // Keep the recovered identity fields explicit after any pointer rebasing.
    std::memcpy(stable + 0x04, &rootType, sizeof(rootType));
    std::memcpy(stable + 0xA0, &key, sizeof(key));

    const bool sourceChanged = entry.sourceRoot != rootPointer;
    entry.sourceRoot = rootPointer;
    entry.rootType = rootType;

    Logf("SSYNENG program-root root=%08lX stable=%08lX key=%08lX type=%u channel=%u fallbackRecords=%u added=%u sourceChanged=%u selfFixups=%u",
         static_cast<unsigned long>(rootPointer), static_cast<unsigned long>(entry.stableRoot), key,
         static_cast<unsigned>(rootType), static_cast<unsigned>(channelHint),
         static_cast<unsigned>(fallbackPrograms_.size()), added ? 1u : 0u,
         sourceChanged ? 1u : 0u, selfFixups);

    TraceProgramRoot(rootPointer, entry.stableRoot);
    if (!RebuildFallbackProgramDatabase()) {
        SetLastError(ERROR_GEN_FAILURE);
        return FALSE;
    }

    // command 41 normally binds by raw root-pointer identity.  Our DB points at
    // the stable snapshot instead, so handle an explicit channel hint ourselves.
    // A zero hint means "registration only" in all observed Reality loads.
    if (channelHint >= 1u && channelHint <= 16u) {
        const uint32_t channels = ReadObjectU32(0x208A0);
        if (PointerReadable(channels, 16u * 0x7A4u)) {
            const uint32_t record = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(
                fallbackProgramDb_ + 0x0C + static_cast<uint32_t>(index) * 0x18u));
            uint8_t* ch = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(
                channels + (static_cast<uint32_t>(channelHint) - 1u) * 0x7A4u));
            std::memcpy(ch + 0x06, &record, sizeof(record));
            Logf("SSYNENG fallback direct channel bind channel=%u key=%08lX record=%08lX stableRoot=%08lX",
                 static_cast<unsigned>(channelHint), key, record, entry.stableRoot);
        }
    }

    DumpSynthState("after stable reconstructed program-root registration");
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

bool SsynengRehost::PointerReadable(uint32_t address, SIZE_T bytes) const {
    if (!address || !bytes) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    const void* p = reinterpret_cast<const void*>(static_cast<uintptr_t>(address));
    if (VirtualQuery(p, &mbi, sizeof(mbi)) != sizeof(mbi)) return false;
    if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
    const uintptr_t begin = reinterpret_cast<uintptr_t>(p);
    const uintptr_t end = begin + bytes;
    const uintptr_t regionEnd = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
    return end >= begin && end <= regionEnd;
}

void SsynengRehost::DumpSynthState(const char* reason) const {
    const uint32_t db = ReadObjectU32(0x3C510);
    const uint32_t prefix = ReadObjectU32(0x3C514);
    const uint32_t channels = ReadObjectU32(0x208A0);
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    uint32_t outputRunning = 0, voiceHead = 0;
    uint16_t outputMode = 0, renderQuantum = 0;
    unsigned activeVoices = 0;
    if (PointerReadable(engine, 0x300u)) {
        const uint8_t* es = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(engine));
        std::memcpy(&renderQuantum, es + 0x14, sizeof(renderQuantum));
        std::memcpy(&voiceHead, es + 0x230, sizeof(voiceHead));
        std::memcpy(&outputMode, es + 0x256, sizeof(outputMode));
        std::memcpy(&outputRunning, es + 0x258, sizeof(outputRunning));

        // A4720 walks the active voice list from engine+0x230 and follows
        // voice+0x30 until the original 0xffffffff sentinel.  Counting the
        // same list tells us whether Note On actually made it through the
        // model constructor/common 884A0 allocator instead of merely changing
        // channel program state.
        uint32_t v = voiceHead;
        while (v && v != 0xffffffffu && activeVoices < 512u && PointerReadable(v, 0xB4u)) {
            if (activeVoices < 4u) {
                const uint8_t* vp = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(v));
                uint32_t type = 0, next = 0, channelPtr = 0;
                uint8_t note = 0, velocity = 0;
                std::memcpy(&type, vp + 0x10, 4);
                std::memcpy(&next, vp + 0x30, 4);
                std::memcpy(&channelPtr, vp + 0xB0, 4);
                std::memcpy(&note, vp + 0x09, 1);
                std::memcpy(&velocity, vp + 0x0A, 1);
                Logf("SSYNENG VOICE%u ptr=%08lX type=%lu note=%u velocity=%u channel=%08lX next=%08lX",
                     activeVoices, v, static_cast<unsigned long>(type),
                     static_cast<unsigned>(note), static_cast<unsigned>(velocity), channelPtr, next);
                v = next;
            } else {
                uint32_t next = 0;
                std::memcpy(&next, reinterpret_cast<const void*>(static_cast<uintptr_t>(v + 0x30u)), 4);
                v = next;
            }
            ++activeVoices;
        }
    }
    uint8_t midiProcessGate = 0;
    if (const auto* p = reinterpret_cast<const uint8_t*>(Ptr(1, 0x20912))) midiProcessGate = *p;
    uint32_t ringWrite = 0, ringRead = 0, ring8 = 0, ringC = 0, ring10 = 0, produced = 0, consumed = 0;
    if (const auto* ring = reinterpret_cast<const uint8_t*>(Ptr(1, 0x1BEE0))) {
        std::memcpy(&ringWrite, ring + 0x00, 4);
        std::memcpy(&ringRead, ring + 0x04, 4);
        std::memcpy(&ring8, ring + 0x08, 4);
        std::memcpy(&ringC, ring + 0x0C, 4);
        std::memcpy(&ring10, ring + 0x10, 4);
        std::memcpy(&produced, ring + 0x14, 4);
        std::memcpy(&consumed, ring + 0x18, 4);
    }
    Logf("SSYNENG synth state reason=%s db=%08lX prefix=%08lX channels=%08lX engine=%08lX ready=%u quantum=%u outputMode=%u outputRunning=%lu midiProcessGate=%u voiceHead=%08lX voices=%u ringW=%lu ringR=%lu produced=%lu consumed=%lu aux=%lu/%lu/%lu",
         reason ? reason : "(none)", db, prefix, channels, engine, CoreReady() ? 1u : 0u,
         static_cast<unsigned>(renderQuantum), static_cast<unsigned>(outputMode), static_cast<unsigned long>(outputRunning),
         static_cast<unsigned>(midiProcessGate), voiceHead, activeVoices, static_cast<unsigned long>(ringWrite),
         static_cast<unsigned long>(ringRead), static_cast<unsigned long>(produced),
         static_cast<unsigned long>(consumed), static_cast<unsigned long>(ring8),
         static_cast<unsigned long>(ringC), static_cast<unsigned long>(ring10));

    if (!PointerReadable(channels, 16u * 0x7A4u)) {
        Logf("SSYNENG channel block unavailable/read-protected");
        return;
    }
    for (unsigned i = 0; i < 16; ++i) {
        const uint8_t* ch = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(channels + i * 0x7A4u));
        uint16_t index = 0, gate = 0;
        uint32_t key = 0, program = 0, root = 0;
        uint8_t programNo = 0, ready = 0;
        std::memcpy(&index, ch + 0x000, sizeof(index));
        std::memcpy(&key, ch + 0x002, sizeof(key));
        std::memcpy(&program, ch + 0x006, sizeof(program));
        std::memcpy(&programNo, ch + 0x276, sizeof(programNo));
        std::memcpy(&gate, ch + 0x7A2, sizeof(gate));
        if (PointerReadable(program, 0x14u)) {
            const uint8_t* prog = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(program));
            std::memcpy(&root, prog + 0x04, sizeof(root));
            std::memcpy(&ready, prog + 0x10, sizeof(ready));
        }
        Logf("SSYNENG CH%02u idx=%u key=%08lX program=%08lX programNo=%u ready=%u root=%08lX gate=%u",
             i, static_cast<unsigned>(index), key, program, static_cast<unsigned>(programNo),
             static_cast<unsigned>(ready), root, static_cast<unsigned>(gate));
    }
}

void SsynengRehost::MarkModernOutputRunning(const char* reason) {
    const uint32_t stateAddress = ReadObjectU32(0x2A5C4);
    if (!PointerReadable(stateAddress, 0x300u)) {
        Logf("SSYNENG modern output state mirror skipped reason=%s invalidState=%08lX",
             reason ? reason : "(none)", stateAddress);
        return;
    }
    auto* state = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(stateAddress));
    uint32_t previous = 0;
    std::memcpy(&previous, state + 0x258, sizeof(previous));
    const uint32_t one = 1;
    const uint16_t zero16 = 0;
    std::memcpy(state + 0x258, &one, sizeof(one));
    std::memcpy(state + 0x0A, &zero16, sizeof(zero16));

    // B6E90 (the original output-open routine) also sets object1+0x20912=1.
    // AA9B0 tests this byte immediately after engine+0x258 and returns before
    // MIDI/render processing when it is zero.  v5/v6 mirrored only +0x258, so
    // MIDI events could be queued forever while the synth worker considered the
    // render transport disabled.  Successful 0x7002 is the NT equivalent of
    // B6E90 success, therefore mirror both pieces of state.
    uint8_t previousProcessGate = 0;
    auto* processGate = reinterpret_cast<uint8_t*>(Ptr(1, 0x20912));
    if (processGate) {
        previousProcessGate = *processGate;
        *processGate = 1;
    }
    Logf("SSYNENG modern output state mirrored running=1 previous=%lu midiProcessGate=1 previousGate=%u state=%08lX reason=%s",
         static_cast<unsigned long>(previous), static_cast<unsigned>(previousProcessGate),
         stateAddress, reason ? reason : "(none)");
}


void SsynengRehost::ConfigureModernRateMixerBridge(DWORD rate, DWORD bits, DWORD channels, const char* reason) {
    // v13.16: keep the engine's own configured-rate/output-mode fields in the
    // same domain as the live modern transport.  v13.14/v13.15 guarded only
    // the legacy PCM descriptor and fold comparison immediate.  Reality's MIDI
    // input selection path can issue service-17 updates that leave engine+0x284
    // and engine+0x256 back in the legacy 22.05-kHz mode without changing the
    // already-running 44.1-kHz DirectSound transport.  Once that happens Reset
    // Synth merely reapplies the old bridge around the wrong engine rate and
    // the pitch/fold bug survives the reset.
    //
    // Reassert these two recovered service-3 fields whenever the modern bridge
    // is configured.  This does not invent a new rate: it mirrors the actual
    // transport rate already captured from the 0x7002 DirectSound handoff.
    if (rate < 8000u || rate > 192000u) return;
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    if (PointerReadable(engine, 0x288u)) {
        auto* state = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(engine));
        uint32_t currentConfiguredRate = 0;
        uint16_t currentOutputMode = 0;
        std::memcpy(&currentConfiguredRate, state + 0x284, sizeof(currentConfiguredRate));
        std::memcpy(&currentOutputMode, state + 0x256, sizeof(currentOutputMode));
        const uint16_t expectedOutputMode = rate == 44100u ? 4u : 2u;
        if (currentConfiguredRate != rate || currentOutputMode != expectedOutputMode) {
            std::memcpy(state + 0x284, &rate, sizeof(rate));
            std::memcpy(state + 0x256, &expectedOutputMode, sizeof(expectedOutputMode));
            Logf("SSYNENG modern engine rate restore configured=%lu->%lu mode=%u->%u reason=%s",
                 static_cast<unsigned long>(currentConfiguredRate), static_cast<unsigned long>(rate),
                 static_cast<unsigned>(currentOutputMode), static_cast<unsigned>(expectedOutputMode),
                 reason ? reason : "(none)");
        }
    }

    // v13.9 proved that object1+0x20915 participates in *two different* pieces
    // of the original engine: the final 22.05 -> 44.1-kHz bus fold and the
    // per-voice sample-step/pitch setup.  Publishing 44100 into that global made
    // the 22-kHz bus audible, but it also changed the 44-kHz voice-rate path and
    // produced the pitch errors demonstrated in the v13.9 video.
    //
    // Before v13.9 the modern transport left +0x20915 at zero.  That state is
    // what the already-working 44.1-kHz voices were built against, and AA9B0
    // still selects the 44.1-kHz final bus for any value other than 22050.
    // Preserve that compatibility selector for a 44.1-kHz modern output, but
    // make only the 8CD20 fold test regard selector 0 as "output is 44.1 kHz".
    // This keeps 44-kHz pitch/step behavior unchanged while restoring the
    // missing 22-kHz intermediate bus to the final 44-kHz mix.
    if (rate < 8000u || rate > 192000u) return;
    if (!(bits == 8u || bits == 16u || bits == 24u || bits == 32u)) return;
    if (channels < 1u || channels > 8u) return;

#pragma pack(push, 1)
    struct LegacyPcmFormat {
        uint16_t formatTag;
        uint32_t sampleRateSelector;
        uint16_t bitsPerSample;
        uint16_t channels;
        uint16_t extra;
    };
#pragma pack(pop)
    static_assert(sizeof(LegacyPcmFormat) == 12, "legacy SSYNENG PCM descriptor must be 12 bytes");

    // 44100 is special in the user-mode rehost.  Keep the pre-v13.9 selector
    // value (0) because the original voice-rate routines use +0x20915 as part
    // of their pitch/step setup.  A true 22050 output still uses the native
    // selector because AA9B0 must choose the 22-kHz final bus in that mode.
    const uint32_t selector = (rate == 44100u) ? 0u : static_cast<uint32_t>(rate);
    const LegacyPcmFormat fmt{1u, selector, static_cast<uint16_t>(bits),
                              static_cast<uint16_t>(channels), 0u};
    auto* dst = reinterpret_cast<uint8_t*>(Ptr(1, 0x20913));
    if (!dst) return;
    std::memcpy(dst, &fmt, sizeof(fmt));

    // In the unmodified VxD, 8CD20 contains:
    //   cmp dword ptr [object1+20915], 44100
    //   jne skip_22_to_44_fold
    // The immediate 44100 lives at object1+8D0A5.  For the modern 44.1-kHz
    // transport, patch only that immediate to 0 so the exact original branch
    // and mixer code run while the compatibility selector stays zero.  This is
    // deliberately narrower than NOPing the branch and naturally leaves a true
    // 22050 output on the old no-fold path.
    auto* foldCompare = reinterpret_cast<uint8_t*>(Ptr(1, 0x8D0A5));
    if (!foldCompare) return;
    uint32_t currentCompare = 0;
    std::memcpy(&currentCompare, foldCompare, sizeof(currentCompare));
    const uint32_t desiredCompare = (rate == 44100u) ? 0u : 44100u;
    if (currentCompare != desiredCompare) {
        if (!(currentCompare == 0u || currentCompare == 44100u)) {
            Logf("SSYNENG modern rate bridge refused unexpected 8CD20 compare immediate=%lu reason=%s",
                 static_cast<unsigned long>(currentCompare), reason ? reason : "(none)");
            return;
        }
        DWORD oldProtect = 0;
        if (!VirtualProtect(foldCompare, sizeof(desiredCompare), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            Logf("SSYNENG modern rate bridge VirtualProtect failed error=%lu reason=%s",
                 GetLastError(), reason ? reason : "(none)");
            return;
        }
        std::memcpy(foldCompare, &desiredCompare, sizeof(desiredCompare));
        FlushInstructionCache(GetCurrentProcess(), foldCompare, sizeof(desiredCompare));
        DWORD ignored = 0;
        VirtualProtect(foldCompare, sizeof(desiredCompare), oldProtect, &ignored);
    }

    Logf("SSYNENG modern rate mixer bridge transportRate=%lu selector20915=%lu foldCompare=%lu bits=%u channels=%u reason=%s",
         static_cast<unsigned long>(rate), static_cast<unsigned long>(selector),
         static_cast<unsigned long>(desiredCompare), static_cast<unsigned>(fmt.bitsPerSample),
         static_cast<unsigned>(fmt.channels), reason ? reason : "(none)");
}

void SsynengRehost::EnsureModernRateMixerBridge(const char* reason) {
    const DWORD rate = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioRate_, 0, 0));
    const DWORD bits = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioBits_, 0, 0));
    const DWORD channels = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioChannels_, 0, 0));
    if (rate < 8000u || rate > 192000u ||
        !(bits == 8u || bits == 16u || bits == 24u || bits == 32u) ||
        channels < 1u || channels > 8u) return;

#pragma pack(push, 1)
    struct LegacyPcmFormatGuard {
        uint16_t formatTag;
        uint32_t sampleRateSelector;
        uint16_t bitsPerSample;
        uint16_t channels;
        uint16_t extra;
    };
#pragma pack(pop)
    static_assert(sizeof(LegacyPcmFormatGuard) == 12, "legacy SSYNENG PCM guard descriptor must be 12 bytes");

    LegacyPcmFormatGuard current{};
    const auto* src = reinterpret_cast<const uint8_t*>(Ptr(1, 0x20913));
    const auto* foldPtr = reinterpret_cast<const uint8_t*>(Ptr(1, 0x8D0A5));
    if (!src || !foldPtr) return;
    std::memcpy(&current, src, sizeof(current));
    uint32_t foldCompare = 0;
    std::memcpy(&foldCompare, foldPtr, sizeof(foldCompare));

    const uint32_t expectedSelector = rate == 44100u ? 0u : static_cast<uint32_t>(rate);
    const uint32_t expectedFold = rate == 44100u ? 0u : 44100u;
    const uint16_t expectedOutputMode = rate == 44100u ? 4u : 2u;
    uint32_t engineConfiguredRate = rate;
    uint16_t engineOutputMode = expectedOutputMode;
    bool engineStateDrifted = false;
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    if (PointerReadable(engine, 0x288u)) {
        const auto* state = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(engine));
        std::memcpy(&engineConfiguredRate, state + 0x284, sizeof(engineConfiguredRate));
        std::memcpy(&engineOutputMode, state + 0x256, sizeof(engineOutputMode));
        engineStateDrifted = engineConfiguredRate != rate || engineOutputMode != expectedOutputMode;
    }

    const bool drifted = current.formatTag != 1u ||
                         current.sampleRateSelector != expectedSelector ||
                         current.bitsPerSample != bits ||
                         current.channels != channels ||
                         current.extra != 0u ||
                         foldCompare != expectedFold ||
                         engineStateDrifted;
    if (!drifted) return;

    Logf("SSYNENG modern rate bridge drift detected selector=%lu expected=%lu foldCompare=%lu expectedFold=%lu engineRate=%lu expectedRate=%lu outputMode=%u expectedMode=%u fmt=%u/%u/%u extra=%u reason=%s",
         static_cast<unsigned long>(current.sampleRateSelector),
         static_cast<unsigned long>(expectedSelector),
         static_cast<unsigned long>(foldCompare),
         static_cast<unsigned long>(expectedFold),
         static_cast<unsigned long>(engineConfiguredRate),
         static_cast<unsigned long>(rate),
         static_cast<unsigned>(engineOutputMode),
         static_cast<unsigned>(expectedOutputMode),
         static_cast<unsigned>(current.formatTag),
         static_cast<unsigned>(current.bitsPerSample),
         static_cast<unsigned>(current.channels),
         static_cast<unsigned>(current.extra),
         reason ? reason : "(none)");
    ConfigureModernRateMixerBridge(rate, bits, channels, reason ? reason : "rate-bridge guard");
}

bool SsynengRehost::QueryModernAudioCursor(DWORD mappedBase, DWORD mappedBytes,
                                           DWORD* playCursor, DWORD* writeCursor) {
    using QueryFn = BOOL (WINAPI*)(LPVOID, DWORD, LPDWORD, LPDWORD);
    static QueryFn query = nullptr;
    static bool resolved = false;
    if (!resolved) {
        resolved = true;
        HMODULE compat = GetModuleHandleA("RealityCompat.dll");
        if (compat) query = reinterpret_cast<QueryFn>(GetProcAddress(compat, "RealityCompat_QueryDirectSoundPosition"));
        Logf("SSYNENG DirectSound cursor bridge resolve compat=%p proc=%p", compat, reinterpret_cast<void*>(query));
    }
    if (!query || !mappedBase || !mappedBytes || !playCursor || !writeCursor) return false;
    return query(reinterpret_cast<LPVOID>(static_cast<uintptr_t>(mappedBase)), mappedBytes,
                 playCursor, writeCursor) != FALSE;
}

void SsynengRehost::ConfigureModernAudio(const void* block, DWORD bytes) {
    if (!block || bytes < 68u) return;
    uint32_t words[17]{};
#if defined(_MSC_VER)
    __try { std::memcpy(words, block, sizeof(words)); }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG host audio configuration unreadable block=%p code=%08lX", block, GetExceptionCode());
        return;
    }
#else
    std::memcpy(words, block, sizeof(words));
#endif
    // The SynMid 0x7002 op=0A block exposes the current DirectSound lock
    // mapping here.  It is valid only until the matching op=0B/Unlock.  word[4] is the flat PCM pointer and
    // word[5] its bytes; words 11..13 are rate/bits/channels.
    const uint32_t buffer = words[4];
    const uint32_t bufferBytes = words[5];
    const uint32_t rate = words[11];
    const uint32_t bits = words[12];
    const uint32_t channels = words[13];

    // Restore the missing 22.05 -> 44.1-kHz mixer fold without changing the
    // pre-v13.9 per-voice rate selector that kept 44.1-kHz tuning correct.
    ConfigureModernRateMixerBridge(rate, bits, channels, "IOCTL 7002 op=0A");

    // object1+0x2090A is *not* the DirectSound ring-buffer size.  It is the
    // amount of PCM produced by one complete AA9B0 callback.  V12/v13 filled
    // it with the 32 KiB DirectSound lock size when the legacy callback-side
    // initialization was missing.  The first successful v13 runtime proved
    // that was too large: each of the two slices rendered 256 stereo frames,
    // but AA9B0 advanced the destination by 16 KiB per slice, leaving long
    // zero gaps.  ResolveNativeCallbackBytes() below reconstructs the span from
    // the active mixer's per-slice frame count once engine+0x14 is ready.
    if (buffer && bufferBytes && PointerReadable(buffer, bufferBytes)) {
        if (audioLockInit_) EnterCriticalSection(&audioLock_);
        const LONG oldBuffer = InterlockedExchange(&modernAudioBuffer_, static_cast<LONG>(buffer));
        InterlockedExchange(&modernAudioBytes_, static_cast<LONG>(bufferBytes));
        if (rate >= 8000u && rate <= 192000u) InterlockedExchange(&modernAudioRate_, static_cast<LONG>(rate));
        if (bits == 8u || bits == 16u || bits == 24u || bits == 32u) InterlockedExchange(&modernAudioBits_, static_cast<LONG>(bits));
        if (channels >= 1u && channels <= 8u) InterlockedExchange(&modernAudioChannels_, static_cast<LONG>(channels));
        if (oldBuffer != static_cast<LONG>(buffer)) {
            renderCursorBytes_ = 0;
            renderCursorPrimed_ = false;
            renderCursorResyncs_ = 0;
        }
        renderFaulted_ = false;
        if (audioLockInit_) LeaveCriticalSection(&audioLock_);
        Logf("SSYNENG host audio mapping buffer=%08lX bytes=%lu rate=%lu bits=%lu channels=%lu op=%lu",
             buffer, static_cast<unsigned long>(bufferBytes), static_cast<unsigned long>(rate),
             static_cast<unsigned long>(bits), static_cast<unsigned long>(channels),
             static_cast<unsigned long>(words[0]));
    } else if (buffer || bufferBytes) {
        Logf("SSYNENG host audio mapping ignored buffer=%08lX bytes=%lu readable=%u",
             buffer, static_cast<unsigned long>(bufferBytes),
             (buffer && bufferBytes && PointerReadable(buffer, std::min<uint32_t>(bufferBytes, 4u))) ? 1u : 0u);
    }
}

void SsynengRehost::DeactivateModernAudio(const char* reason) {
    if (audioLockInit_) EnterCriticalSection(&audioLock_);
    const LONG oldBuffer = InterlockedExchange(&modernAudioBuffer_, 0);
    const LONG oldBytes = InterlockedExchange(&modernAudioBytes_, 0);
    modernAudioRegistered_ = false;
    renderCursorBytes_ = 0;
    renderCursorPrimed_ = false;
    lastScheduledCallbackBytes_ = 0;
    renderFaulted_ = false;
    if (audioLockInit_) LeaveCriticalSection(&audioLock_);
    Logf("SSYNENG modern audio mapping deactivated buffer=%08lX bytes=%lu reason=%s",
         static_cast<unsigned long>(oldBuffer), static_cast<unsigned long>(oldBytes),
         reason ? reason : "(none)");
}

DWORD SsynengRehost::ResolveNativeCallbackBytes(DWORD frameBytes, DWORD outputBytes, bool publish) {
    if (!frameBytes || !outputBytes) return ReadObjectU32(0x2090A);
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    if (!PointerReadable(engine, 0xA8u)) return ReadObjectU32(0x2090A);

    uint16_t slices = 0, mixAFrames = 0, mixBFrames = 0;
    std::memcpy(&slices, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x14u)), sizeof(slices));
    std::memcpy(&mixAFrames, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x76u)), sizeof(mixAFrames));
    std::memcpy(&mixBFrames, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0xA6u)), sizeof(mixBFrames));
    if (!slices || slices > 64u) return ReadObjectU32(0x2090A);

    // AA9B0 chooses engine+0x4C or engine+0x7C from the legacy output sample
    // rate DWORD at object1+0x20915.  22050 (0x5622) selects the 22.05-kHz
    // mixer; 44100 (0xAC44) selects the 44.1-kHz mixer.  v13.8 left this
    // field at zero because the modern backend bypassed B6E90.
    const uint32_t outputRate = ReadObjectU32(0x20915);
    uint32_t perSliceFrames = (outputRate == 0x5622u) ? mixAFrames : mixBFrames;
    if (!perSliceFrames) perSliceFrames = std::max<uint32_t>(mixAFrames, mixBFrames);
    if (!perSliceFrames || perSliceFrames > 8192u) return ReadObjectU32(0x2090A);

    const std::uint64_t derived64 = static_cast<std::uint64_t>(perSliceFrames) *
                                    static_cast<std::uint64_t>(slices) * frameBytes;
    if (derived64 < frameBytes || derived64 > outputBytes || derived64 > 0x100000u)
        return ReadObjectU32(0x2090A);
    const DWORD derived = static_cast<DWORD>(derived64);
    const DWORD current = ReadObjectU32(0x2090A);

    // Trust a plausible native value unless it is the known v12/v13 fallback
    // (the whole DirectSound ring) or otherwise wildly larger than the active
    // mixer geometry.
    const bool replace = current == 0u || current == outputBytes ||
                         current > derived * 4u || (current % frameBytes) != 0u;
    if (publish && replace) {
        if (auto* span = reinterpret_cast<uint8_t*>(Ptr(1, 0x2090A))) {
            std::memcpy(span, &derived, sizeof(derived));
            Logf("SSYNENG recovered native callback span old=%lu new=%lu slices=%u perSliceFrames=%lu frameBytes=%lu outputBytes=%lu outputRate=%lu",
                 static_cast<unsigned long>(current), static_cast<unsigned long>(derived),
                 static_cast<unsigned>(slices), static_cast<unsigned long>(perSliceFrames),
                 static_cast<unsigned long>(frameBytes), static_cast<unsigned long>(outputBytes),
                 static_cast<unsigned long>(outputRate));
            return derived;
        }
    }
    return replace ? derived : current;
}

void SsynengRehost::DumpRenderContract(const char* reason) const {
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    const uint32_t callbackBytes = ReadObjectU32(0x2090A);
    uint16_t slices = 0;
    uint32_t running = 0;
    uint32_t configuredRate = 0;
    uint16_t outputMode = 0;
    uint8_t gate12 = 0;
    uint32_t mixA = 0, mixB = 0, mixA10 = 0, mixB10 = 0;
    uint16_t mixA2A = 0, mixB2A = 0;
    if (PointerReadable(engine, 0x2A0u)) {
        std::memcpy(&slices, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x14u)), sizeof(slices));
        std::memcpy(&running, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x258u)), sizeof(running));
        std::memcpy(&configuredRate, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x284u)), sizeof(configuredRate));
        std::memcpy(&outputMode, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x256u)), sizeof(outputMode));
        std::memcpy(&mixA, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x4Cu)), sizeof(mixA));
        std::memcpy(&mixB, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x7Cu)), sizeof(mixB));
        std::memcpy(&mixA10, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x5Cu)), sizeof(mixA10));
        std::memcpy(&mixB10, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x8Cu)), sizeof(mixB10));
        std::memcpy(&mixA2A, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x76u)), sizeof(mixA2A));
        std::memcpy(&mixB2A, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0xA6u)), sizeof(mixB2A));
    }
    const auto* g12 = reinterpret_cast<const uint8_t*>(Ptr(1, 0x20912));
    if (g12) gate12 = *g12;
    uint16_t formatTag = 0, formatBits = 0, formatChannels = 0, formatExtra = 0;
    uint32_t formatRate = 0;
    if (const auto* format = reinterpret_cast<const uint8_t*>(Ptr(1, 0x20913))) {
        std::memcpy(&formatTag, format + 0, sizeof(formatTag));
        std::memcpy(&formatRate, format + 2, sizeof(formatRate));
        std::memcpy(&formatBits, format + 6, sizeof(formatBits));
        std::memcpy(&formatChannels, format + 8, sizeof(formatChannels));
        std::memcpy(&formatExtra, format + 10, sizeof(formatExtra));
    }
    uint32_t foldCompare = 0;
    if (const auto* imm = reinterpret_cast<const uint8_t*>(Ptr(1, 0x8D0A5)))
        std::memcpy(&foldCompare, imm, sizeof(foldCompare));
    const DWORD transportRate = static_cast<DWORD>(modernAudioRate_);
    Logf("SSYNENG render contract reason=%s engine=%08lX slices=%u callbackBytes=%lu running=%lu configuredRate=%lu outputMode=%u midiProcessGate=%u compatFormat=%u/selector%luHz/%ubit/%uch extra=%u transportRate=%lu foldCompare=%lu mix4C=%08lX mix5C=%08lX mix76count=%u mix7C=%08lX mix8C=%08lX mixA6count=%u",
         reason ? reason : "(none)", engine, static_cast<unsigned>(slices),
         static_cast<unsigned long>(callbackBytes), static_cast<unsigned long>(running),
         static_cast<unsigned long>(configuredRate), static_cast<unsigned>(outputMode),
         static_cast<unsigned>(gate12), static_cast<unsigned>(formatTag),
         static_cast<unsigned long>(formatRate), static_cast<unsigned>(formatBits),
         static_cast<unsigned>(formatChannels), static_cast<unsigned>(formatExtra),
         static_cast<unsigned long>(transportRate), static_cast<unsigned long>(foldCompare),
         mixA, mixA10, static_cast<unsigned>(mixA2A),
         mixB, mixB10, static_cast<unsigned>(mixB2A));
}

DWORD WINAPI SsynengRehost::HostPumpThreadThunk(LPVOID param) {
    auto* self = static_cast<SsynengRehost*>(param);
    return self ? self->HostPumpMain() : 0u;
}

bool SsynengRehost::EnsureHostPump() {
    if (HostPumpDisabled()) return false;
    if (hostPumpThread_) {
        if (hostPumpWakeEvent_) SetEvent(hostPumpWakeEvent_);
        return true;
    }
    if (InterlockedCompareExchange(&hostPumpStarting_, 1, 0) != 0) return hostPumpThread_ != nullptr;
    hostPumpStopEvent_ = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    hostPumpWakeEvent_ = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!hostPumpStopEvent_ || !hostPumpWakeEvent_) {
        if (hostPumpStopEvent_) CloseHandle(hostPumpStopEvent_);
        if (hostPumpWakeEvent_) CloseHandle(hostPumpWakeEvent_);
        hostPumpStopEvent_ = hostPumpWakeEvent_ = nullptr;
        InterlockedExchange(&hostPumpStarting_, 0);
        return false;
    }
    hostPumpThread_ = CreateThread(nullptr, 0, &SsynengRehost::HostPumpThreadThunk, this, 0, nullptr);
    if (!hostPumpThread_) {
        CloseHandle(hostPumpStopEvent_); CloseHandle(hostPumpWakeEvent_);
        hostPumpStopEvent_ = hostPumpWakeEvent_ = nullptr;
        InterlockedExchange(&hostPumpStarting_, 0);
        return false;
    }
    InterlockedExchange(&hostPumpStarting_, 0);
    Logf("SSYNENG host engine pump started thread=%p (native AA9B0/B08C0 MIDI + render clock; direct decoder is fallback only)", hostPumpThread_);
    return true;
}

void SsynengRehost::StopHostPump() {
    HANDLE thread = hostPumpThread_;
    if (!thread) return;
    if (hostPumpStopEvent_) SetEvent(hostPumpStopEvent_);
    if (hostPumpWakeEvent_) SetEvent(hostPumpWakeEvent_);
    if (GetCurrentThreadId() != GetThreadId(thread)) WaitForSingleObject(thread, 3000);
    CloseHandle(thread);
    hostPumpThread_ = nullptr;
    if (hostPumpStopEvent_) CloseHandle(hostPumpStopEvent_);
    if (hostPumpWakeEvent_) CloseHandle(hostPumpWakeEvent_);
    hostPumpStopEvent_ = hostPumpWakeEvent_ = nullptr;
    Logf("SSYNENG host engine pump stopped renderCalls=%lu nativeMidiProgress=%lu midiFallbackEvents=%lu midiFallbackPasses=%lu midiDrained=%lu delayedRetried=%lu delayedPasses=%lu",
         static_cast<unsigned long>(renderCallCount_),
         static_cast<unsigned long>(nativeMidiProgressEvents_),
         static_cast<unsigned long>(nativeMidiFallbackEvents_),
         static_cast<unsigned long>(nativeMidiFallbackPasses_),
         static_cast<unsigned long>(hostMidiDrainCount_),
         static_cast<unsigned long>(hostDelayedMidiRetryCount_),
         static_cast<unsigned long>(hostDelayedMidiRetryPasses_));
}

unsigned SsynengRehost::MidiRingPendingCount(uint32_t* readIndexOut, uint32_t* writeIndexOut) {
    if (!midiLockInit_ || !CoreReady()) return 0;
    auto* ring = reinterpret_cast<uint8_t*>(Ptr(1, 0x1BEE0));
    if (!ring) return 0;
    uint32_t writeIndex = 0, readIndex = 0;
    EnterCriticalSection(&midiLock_);
    std::memcpy(&writeIndex, ring + 0x00, 4);
    std::memcpy(&readIndex, ring + 0x04, 4);
    LeaveCriticalSection(&midiLock_);
    writeIndex &= 0x1ffu;
    readIndex &= 0x1ffu;
    if (readIndexOut) *readIndexOut = readIndex;
    if (writeIndexOut) *writeIndexOut = writeIndex;
    const uint32_t nextUnread = (readIndex + 1u) & 0x1ffu;
    return (writeIndex + 0x200u - nextUnread) & 0x1ffu;
}

void SsynengRehost::ObserveNativeMidiAfterRender(bool rendered) {
    if (!CoreReady()) return;
    uint32_t readIndex = 0, writeIndex = 0;
    const unsigned pending = MidiRingPendingCount(&readIndex, &writeIndex);
    if (nativeMidiLastRead_ == 0xffffffffu) nativeMidiLastRead_ = readIndex;

    const bool progressed = readIndex != nativeMidiLastRead_;
    if (progressed) {
        const DWORD delta = (readIndex + 0x200u - nativeMidiLastRead_) & 0x1ffu;
        nativeMidiProgressEvents_ += delta;
        nativeMidiLastRead_ = readIndex;
        nativeMidiStallQuanta_ = 0;
        if (nativeMidiProgressEvents_ <= 32u ||
            (nativeMidiProgressEvents_ & (nativeMidiProgressEvents_ - 1u)) == 0u) {
            Logf("SSYNENG native B08C0 MIDI progress delta=%lu total=%lu pending=%u ringRead=%lu ringWrite=%lu",
                 static_cast<unsigned long>(delta), static_cast<unsigned long>(nativeMidiProgressEvents_), pending,
                 static_cast<unsigned long>(readIndex), static_cast<unsigned long>(writeIndex));
        }
    } else if (pending) {
        ++nativeMidiStallQuanta_;
    } else {
        nativeMidiStallQuanta_ = 0;
    }

    // AA9B0 contains the original B08C0 MIDI/timing processor.  Normal v13.6
    // operation leaves the ring entirely to that native path.  Keep the old
    // direct-A66B0 drain only as a safety net if the native read cursor fails
    // to move for several complete render quanta.  This preserves the original
    // timing/context required by special type-2 programs without risking a
    // permanently wedged input ring if a future state transition disables
    // B08C0 temporarily.
    const DWORD stallLimit = rendered ? 4u : 8u;
    if (pending && nativeMidiStallQuanta_ >= stallLimit) {
        const unsigned drained = DrainMidiRingHost(256);
        const unsigned delayed = DrainDelayedMidiHost(32);
        if (drained || delayed) {
            ++nativeMidiFallbackPasses_;
            nativeMidiFallbackEvents_ += drained + delayed;
            Logf("SSYNENG native MIDI fallback pass=%lu stalledQuanta=%lu pendingBefore=%u ringRead=%lu ringWrite=%lu drained=%u delayed=%u",
                 static_cast<unsigned long>(nativeMidiFallbackPasses_),
                 static_cast<unsigned long>(nativeMidiStallQuanta_), pending,
                 static_cast<unsigned long>(readIndex), static_cast<unsigned long>(writeIndex), drained, delayed);
        }
        nativeMidiStallQuanta_ = 0;
        MidiRingPendingCount(&nativeMidiLastRead_, nullptr);
    }
}

unsigned SsynengRehost::CountMatchingVoices(unsigned chIndex, BYTE note, uint32_t* firstVoice) const {
    if (firstVoice) *firstVoice = 0;
    const uint32_t channels = ReadObjectU32(0x208A0);
    const uint32_t channelAddress = channels ? channels + (chIndex & 0x0fu) * 0x7A4u : 0u;
    if (!channelAddress) return 0;
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    if (!PointerReadable(engine, 0x234u)) return 0;
    uint32_t voice = 0;
    std::memcpy(&voice, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x230u)), 4);
    unsigned count = 0, guard = 0;
    while (voice && voice != 0xffffffffu && guard++ < 512u && PointerReadable(voice, 0xB4u)) {
        const auto* vp = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(voice));
        uint32_t next = 0, voiceChannel = 0;
        uint8_t voiceNote = 0;
        std::memcpy(&voiceNote, vp + 0x09, 1);
        std::memcpy(&next, vp + 0x30, 4);
        std::memcpy(&voiceChannel, vp + 0xB0, 4);
        if (voiceNote == note && voiceChannel == channelAddress) {
            if (!count && firstVoice) *firstVoice = voice;
            ++count;
        }
        voice = next;
    }
    return count;
}

unsigned SsynengRehost::DrainMidiRingHost(unsigned maxEvents) {
    if (!midiLockInit_ || !CoreReady()) return 0;
    auto* ring = reinterpret_cast<uint8_t*>(Ptr(1, 0x1BEE0));
    auto* decoder = reinterpret_cast<void (__cdecl*)(DWORD)>(Ptr(1, 0xA66B0));
    if (!ring || !decoder) return 0;

    struct Pending { DWORD msg; DWORD timestamp; };
    Pending pending[256]{};
    const unsigned limit = std::min<unsigned>(maxEvents ? maxEvents : 1u, 256u);
    unsigned pendingCount = 0;

    EnterCriticalSection(&midiLock_);
    uint32_t writeIndex = 0, readIndex = 0, consumed = 0;
    std::memcpy(&writeIndex, ring + 0x00, 4);
    std::memcpy(&readIndex, ring + 0x04, 4);
    std::memcpy(&consumed, ring + 0x18, 4);
    writeIndex &= 0x1ffu; readIndex &= 0x1ffu;
    uint32_t next = (readIndex + 1u) & 0x1ffu;
    while (next != writeIndex && pendingCount < limit) {
        const uint8_t* event = ring + 0x1Cu + next * 8u;
        std::memcpy(&pending[pendingCount].msg, event + 0, 4);
        std::memcpy(&pending[pendingCount].timestamp, event + 4, 4);
        ++pendingCount;
        readIndex = next;
        next = (next + 1u) & 0x1ffu;
    }
    if (pendingCount) {
        consumed += pendingCount;
        std::memcpy(ring + 0x04, &readIndex, 4);
        std::memcpy(ring + 0x18, &consumed, 4);
    }
    LeaveCriticalSection(&midiLock_);
    if (!pendingCount) return 0;

    unsigned decoded = 0;
    for (unsigned i = 0; i < pendingCount; ++i) {
        const auto& p = pending[i];
        const DWORD shortMsg = p.msg & 0x00ffffffu;
        const BYTE status = static_cast<BYTE>(shortMsg & 0xffu);
        const BYTE hi = status & 0xF0u;
        const BYTE d1 = static_cast<BYTE>((shortMsg >> 8) & 0x7fu);
        const BYTE d2 = static_cast<BYTE>((shortMsg >> 16) & 0x7fu);
        const unsigned chIndex = status & 0x0fu;
        int diffKind = -1;
        if (hi == 0xC0u) diffKind = 0;
        else if (hi == 0xB0u && d1 == 7u) diffKind = 1;
        else if (hi == 0xB0u && d1 == 10u) diffKind = 2;
        const std::uint64_t diffBit = diffKind >= 0 ? (std::uint64_t{1} << (chIndex * 3u + static_cast<unsigned>(diffKind))) : 0u;
        uint8_t beforeChannel[0x7A4] = {};
        uint8_t afterChannel[0x7A4] = {};
        uint32_t channelAddress = 0;
        bool captureDiff = diffBit && (channelDiffSeen_ & diffBit) == 0u;
        if (captureDiff) {
            const uint32_t channelsBase = ReadObjectU32(0x208A0);
            channelAddress = channelsBase ? channelsBase + chIndex * 0x7A4u : 0u;
            captureDiff = PointerReadable(channelAddress, sizeof(beforeChannel));
            if (captureDiff) std::memcpy(beforeChannel, reinterpret_cast<const void*>(static_cast<uintptr_t>(channelAddress)), sizeof(beforeChannel));
        }
#if defined(_MSC_VER)
        __try {
            decoder(shortMsg);
            ++decoded;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Logf("SSYNENG host MIDI decoder exception=%08lX msg=%08lX", GetExceptionCode(), p.msg);
        }
#else
        decoder(shortMsg); ++decoded;
#endif
        if (hi == 0x90u && d2 != 0u) LogMidiNoteDisposition(shortMsg, "ring");
        if (captureDiff && PointerReadable(channelAddress, sizeof(afterChannel))) {
            std::memcpy(afterChannel, reinterpret_cast<const void*>(static_cast<uintptr_t>(channelAddress)), sizeof(afterChannel));
            LogChannelDiff(shortMsg, chIndex, beforeChannel, afterChannel, sizeof(beforeChannel));
            channelDiffSeen_ |= diffBit;
        }
    }
    if (decoded) {
        hostMidiDrainCount_ += decoded;
        if (hostMidiDrainCount_ <= 32u || (hostMidiDrainCount_ & (hostMidiDrainCount_ - 1u)) == 0u)
            Logf("SSYNENG host MIDI drain decoded=%u total=%lu ringRead=%lu ringWrite=%lu",
                 decoded, static_cast<unsigned long>(hostMidiDrainCount_),
                 static_cast<unsigned long>(readIndex), static_cast<unsigned long>(writeIndex));
    }
    return decoded;
}

void SsynengRehost::LogMidiNoteDisposition(DWORD packedMessage, const char* source) {
    const DWORD msg = packedMessage & 0x00ffffffu;
    const BYTE status = static_cast<BYTE>(msg & 0xffu);
    const BYTE hi = status & 0xf0u;
    const BYTE note = static_cast<BYTE>((msg >> 8) & 0x7fu);
    const BYTE velocity = static_cast<BYTE>((msg >> 16) & 0x7fu);
    if (hi != 0x90u || velocity == 0u) return;

    const unsigned chIndex = status & 0x0fu;
    const uint32_t channels = ReadObjectU32(0x208A0);
    const uint32_t channelAddress = channels ? channels + chIndex * 0x7A4u : 0u;
    uint32_t key = 0, program = 0, root = 0, rootData = 0;
    uint16_t gate = 0, rootType = 0;
    uint8_t ready = 0;
    if (PointerReadable(channelAddress, 0x7A4u)) {
        const auto* ch = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(channelAddress));
        std::memcpy(&key, ch + 0x02, sizeof(key));
        std::memcpy(&program, ch + 0x06, sizeof(program));
        std::memcpy(&gate, ch + 0x7A2, sizeof(gate));
        if (PointerReadable(program, 0x14u)) {
            const auto* prog = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(program));
            std::memcpy(&root, prog + 0x04, sizeof(root));
            std::memcpy(&ready, prog + 0x10, sizeof(ready));
        }
        if (PointerReadable(root, 0xF0u)) {
            const auto* rp = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(root));
            std::memcpy(&rootType, rp + 0x04, sizeof(rootType));
            std::memcpy(&rootData, rp + 0xEC, sizeof(rootData));
        }
    }

    bool delayed = false;
    unsigned delayedCount = 0;
    const auto* delayedTable = reinterpret_cast<const uint32_t*>(Ptr(1, 0x3F648));
    if (delayedTable && PointerReadable(static_cast<uint32_t>(reinterpret_cast<uintptr_t>(delayedTable)), 128u * sizeof(uint32_t))) {
        for (unsigned i = 0; i < 128u; ++i) {
            const uint32_t queued = delayedTable[i] & 0x00ffffffu;
            if (queued) ++delayedCount;
            if (queued == msg) delayed = true;
        }
    }

    uint32_t matchingVoiceAddress = 0;
    const unsigned matchingVoiceCount = CountMatchingVoices(chIndex, note, &matchingVoiceAddress);
    const bool nativeDisposition = source && std::strcmp(source, "native-AA9B0") == 0;
    const unsigned baselineMatches = nativeDisposition
        ? static_cast<unsigned>(InterlockedCompareExchange(&pendingNoteBaselineMatches_, 0, 0)) : 0u;
    const bool newMatchingVoice = matchingVoiceCount > baselineMatches;

    // Programs whose root type is 2 use ABC90 rather than the ordinary A4720
    // voice constructor.  ABC90 first allocates a container voice, then scans
    // the program-data zone table and attaches matching child layers.  A
    // non-null container by itself therefore does *not* prove that the note can
    // sound.  v13.5's activeVoice=1 diagnostic missed exactly this case.
    uint32_t type2ProgramData = 0;
    uint32_t type2ZoneCount = 0;
    unsigned type2Slot104NonZero = 0;
    unsigned type2Slot108NonZero = 0;
    if (rootType == 2u && matchingVoiceAddress && PointerReadable(matchingVoiceAddress, 0x104u)) {
        std::memcpy(&type2ProgramData,
                    reinterpret_cast<const void*>(static_cast<uintptr_t>(matchingVoiceAddress + 0x100u)), 4);
        if (PointerReadable(type2ProgramData, 8u)) {
            std::memcpy(&type2ZoneCount,
                        reinterpret_cast<const void*>(static_cast<uintptr_t>(type2ProgramData + 0x04u)), 4);
            type2ZoneCount = std::min<uint32_t>(type2ZoneCount, 0x3A9u);
            for (uint32_t i = 0; i < type2ZoneCount; ++i) {
                const uint32_t slot104 = matchingVoiceAddress + 0x104u + i * 12u;
                const uint32_t slot108 = matchingVoiceAddress + 0x108u + i * 12u;
                uint32_t p104 = 0, p108 = 0;
                if (PointerReadable(slot104, 4u))
                    std::memcpy(&p104, reinterpret_cast<const void*>(static_cast<uintptr_t>(slot104)), 4);
                if (PointerReadable(slot108, 4u))
                    std::memcpy(&p108, reinterpret_cast<const void*>(static_cast<uintptr_t>(slot108)), 4);
                if (p104) ++type2Slot104NonZero;
                if (p108) ++type2Slot108NonZero;
            }
        }
    }

    // A4720's ordinary (root type 1) voice path first resolves root+0xEC to a
    // model/collection, then scans its 24-byte layer records by key range.  The
    // field trace that motivated v13.8 proves C4/D4 can allocate a voice yet
    // render zero while E4 on the *same* piano program renders normally.  That
    // cannot be a dropped MIDI byte; it is almost certainly a different layer
    // record.  Log each program/note combination once so the next trace tells us
    // exactly which layer was selected and whether its backing object is valid.
    if (rootType == 1u && chIndex < 16u && note < 128u &&
        !genericLayerTraceSeen_[chIndex][note] && PointerReadable(rootData, 0x14u)) {
        genericLayerTraceSeen_[chIndex][note] = true;
        uint32_t modelId = 0, layerTable = 0;
        uint16_t layerCount = 0;
        const auto* model = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(rootData));
        std::memcpy(&modelId, model + 0x04u, 4);
        std::memcpy(&layerCount, model + 0x0Au, 2);
        std::memcpy(&layerTable, model + 0x10u, 4);
        const unsigned boundedCount = std::min<unsigned>(layerCount, 64u);
        int selected = -1;
        uint32_t selectedLayer = 0;
        Logf("SSYNENG generic-layer model ch=%u note=%u root=%08lX model=%08lX modelId=%lu layers=%u table=%08lX voice=%08lX",
             chIndex + 1u, static_cast<unsigned>(note), root, rootData,
             static_cast<unsigned long>(modelId), static_cast<unsigned>(layerCount), layerTable, matchingVoiceAddress);
        if (layerTable && PointerReadable(layerTable, static_cast<SIZE_T>(boundedCount) * 24u)) {
            for (unsigned i = 0; i < boundedCount; ++i) {
                const uint32_t entry = layerTable + i * 24u;
                uint32_t layer = 0;
                std::memcpy(&layer, reinterpret_cast<const void*>(static_cast<uintptr_t>(entry + 4u)), 4);
                uint32_t layerValid = 0, ownerOrData = 0, field628 = 0;
                uint8_t low = 0xffu, high = 0xffu, field62c = 0, field62d = 0;
                bool readable = PointerReadable(layer, 0x630u);
                if (readable) {
                    const auto* lp = reinterpret_cast<const uint8_t*>(static_cast<uintptr_t>(layer));
                    std::memcpy(&layerValid, lp + 0x04u, 4);
                    low = lp[0x08u]; high = lp[0x09u];
                    std::memcpy(&ownerOrData, lp + 0x0Cu, 4);
                    std::memcpy(&field628, lp + 0x628u, 4);
                    field62c = lp[0x62Cu]; field62d = lp[0x62Du];
                    if (note >= low && note <= high && selected < 0) {
                        selected = static_cast<int>(i);
                        selectedLayer = layer;
                    }
                }
                // Always show the selected layer and nearby/key-covering records;
                // for small multisamples (piano/drums) show the entire table.
                if (boundedCount <= 16u || (readable && note >= low && note <= high)) {
                    Logf("SSYNENG generic-layer entry ch=%u note=%u idx=%u entry=%08lX layer=%08lX readable=%u valid=%08lX key=%u..%u data0C=%08lX f628=%08lX f62c=%u f62d=%u",
                         chIndex + 1u, static_cast<unsigned>(note), i, entry, layer, readable ? 1u : 0u,
                         layerValid, static_cast<unsigned>(low), static_cast<unsigned>(high), ownerOrData,
                         field628, static_cast<unsigned>(field62c), static_cast<unsigned>(field62d));
                }
            }
        }
        Logf("SSYNENG generic-layer selected ch=%u note=%u modelId=%lu idx=%d layer=%08lX",
             chIndex + 1u, static_cast<unsigned>(note), static_cast<unsigned long>(modelId), selected, selectedLayer);
    }

    ++noteDispositionCount_;
    const bool type2NoChild = rootType == 2u && matchingVoiceAddress && type2ZoneCount != 0u &&
                              type2Slot104NonZero == 0u && type2Slot108NonZero == 0u;
    const bool suspicious = delayed || !matchingVoiceCount || !program || !ready || gate != 0 || type2NoChild;
    if (suspicious || rootType == 2u || noteDispositionCount_ <= 16u ||
        (noteDispositionCount_ & (noteDispositionCount_ - 1u)) == 0u) {
        Logf("SSYNENG NoteOn disposition source=%s ch=%u note=%u vel=%u key=%08lX program=%08lX ready=%u root=%08lX rootType=%u gate=%u delayed=%u delayedCount=%u activeVoice=%u activeVoices=%u baseline=%u newVoice=%u voice=%08lX type2Data=%08lX rootData=%08lX type2Zones=%lu slot104=%u slot108=%u",
             source ? source : "?", chIndex + 1u, static_cast<unsigned>(note), static_cast<unsigned>(velocity),
             key, program, static_cast<unsigned>(ready), root, static_cast<unsigned>(rootType), static_cast<unsigned>(gate),
             delayed ? 1u : 0u, delayedCount, matchingVoiceCount ? 1u : 0u, matchingVoiceCount, baselineMatches, newMatchingVoice ? 1u : 0u,
             matchingVoiceAddress, type2ProgramData, rootData, static_cast<unsigned long>(type2ZoneCount),
             type2Slot104NonZero, type2Slot108NonZero);
    }
}

unsigned SsynengRehost::DrainDelayedMidiHost(unsigned maxEvents) {
    if (!CoreReady()) return 0;
    using PopDelayedFn = DWORD (__cdecl*)();
    using DecoderFn = void (__cdecl*)(DWORD);
    auto* popDelayed = reinterpret_cast<PopDelayedFn>(Ptr(1, 0xB0630));
    auto* decoder = reinterpret_cast<DecoderFn>(Ptr(1, 0xA66B0));
    if (!popDelayed || !decoder) return 0;

    // B05F0/B0630 implement the original fixed 128-DWORD retry queue.  Pop a
    // batch completely *before* decoding it.  If a still-unready Note On puts
    // itself back with B05F0, it will therefore wait until the next audio tick
    // instead of being popped/requeued forever inside one host callback.
    DWORD pending[128] = {};
    const unsigned limit = std::min<unsigned>(maxEvents ? maxEvents : 1u, 128u);
    unsigned count = 0;
    for (; count < limit; ++count) {
        DWORD msg = 0;
#if defined(_MSC_VER)
        __try {
            msg = popDelayed();
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Logf("SSYNENG delayed MIDI pop exception=%08lX", GetExceptionCode());
            break;
        }
#else
        msg = popDelayed();
#endif
        if (!msg) break;
        pending[count] = msg & 0x00ffffffu;
    }
    if (!count) return 0;

    unsigned decoded = 0;
    for (unsigned i = 0; i < count; ++i) {
        const DWORD msg = pending[i];
#if defined(_MSC_VER)
        __try {
            decoder(msg);
            ++decoded;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Logf("SSYNENG delayed MIDI decoder exception=%08lX msg=%08lX", GetExceptionCode(), msg);
        }
#else
        decoder(msg); ++decoded;
#endif
        const BYTE status = static_cast<BYTE>(msg & 0xffu);
        const BYTE velocity = static_cast<BYTE>((msg >> 16) & 0x7fu);
        if ((status & 0xf0u) == 0x90u && velocity) LogMidiNoteDisposition(msg, "delayed-retry");
    }

    if (decoded) {
        hostDelayedMidiRetryCount_ += decoded;
        ++hostDelayedMidiRetryPasses_;
        if (hostDelayedMidiRetryPasses_ <= 16u ||
            (hostDelayedMidiRetryPasses_ & (hostDelayedMidiRetryPasses_ - 1u)) == 0u) {
            Logf("SSYNENG delayed MIDI retry decoded=%u total=%lu passes=%lu",
                 decoded, static_cast<unsigned long>(hostDelayedMidiRetryCount_),
                 static_cast<unsigned long>(hostDelayedMidiRetryPasses_));
        }
    }
    return decoded;
}

bool SsynengRehost::RenderHostQuantum() {
    if (renderFaulted_ || !startRequested_ || !CoreReady()) return false;

    // Reality's Reset Synth / legacy MIDI reset paths can rewrite the old PCM
    // descriptor after the modern 0x7002 transport has already established the
    // v13.10 split-rate compatibility state.  Reassert only when the descriptor
    // has actually drifted.  This also covers reset paths that bypass the native
    // ResetMidi wrapper and call the original engine service directly.
    EnsureModernRateMixerBridge("render guard after legacy reset");
    // Until a program database exists AA9B0 can only generate silence, while
    // SynHigh may still be mutating its program/resource objects.  Start the
    // recovered DSP clock once the DB bridge has a stable playable program.
    if (ReadObjectU32(0x3C510) == 0) return false;

    const uint32_t outputBuffer = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioBuffer_, 0, 0));
    const uint32_t outputBytes = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioBytes_, 0, 0));
    const uint32_t bits = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioBits_, 0, 0));
    const uint32_t channels = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioChannels_, 0, 0));
    if (!outputBuffer || outputBytes < 256u || !PointerReadable(outputBuffer, std::min<uint32_t>(outputBytes, 4u))) return false;
    const uint32_t frameBytes = std::max<uint32_t>(1u, channels * std::max<uint32_t>(1u, bits / 8u));

    // Recovered AA9B0 ABI (v12): the original SSYNENG worker at 0x968E0
    // passes WORD [engine+0x14] as argument 2.  AA9B0 itself reads
    // object1+0x2090A as the total PCM byte span and divides that span between
    // the callback slices.  V8-v11 incorrectly treated argument 2 as a PCM
    // frame count and called AA9B0(buffer, 256), which changed its internal
    // loop count and pointer arithmetic by two orders of magnitude.
    const uint32_t engine = ReadObjectU32(0x2A5C4);
    if (!PointerReadable(engine, 0x2A0u)) return false;
    uint16_t callbackSlices = 0;
    std::memcpy(&callbackSlices, reinterpret_cast<const void*>(static_cast<uintptr_t>(engine + 0x14u)), sizeof(callbackSlices));
    const uint32_t callbackBytes = ResolveNativeCallbackBytes(frameBytes, outputBytes, true);
    if (!callbackSlices || callbackSlices > 64u || callbackBytes < frameBytes ||
        callbackBytes > outputBytes || (callbackBytes % frameBytes) != 0u) {
        const bool changed = callbackSlices != lastRenderCallbackSlices_ || callbackBytes != lastRenderCallbackBytes_;
        if (changed || renderCallCount_ < 8u) {
            Logf("SSYNENG host AA9B0 contract not ready slices=%u callbackBytes=%lu outputBytes=%lu frameBytes=%lu",
                 static_cast<unsigned>(callbackSlices), static_cast<unsigned long>(callbackBytes),
                 static_cast<unsigned long>(outputBytes), static_cast<unsigned long>(frameBytes));
            DumpRenderContract("AA9B0 contract not ready");
            lastRenderCallbackSlices_ = callbackSlices;
            lastRenderCallbackBytes_ = callbackBytes;
        }
        return false;
    }
    const uint32_t callbackFrames = callbackBytes / frameBytes;
    const DWORD accountingRate = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioRate_, 0, 0));
    if (accountingRate < 8000u) return false;

    if (callbackBytes > renderScratchBytes_) {
        if (renderScratch_) { VirtualFree(renderScratch_, 0, MEM_RELEASE); renderScratch_ = nullptr; renderScratchBytes_ = 0; }
        renderScratch_ = reinterpret_cast<uint8_t*>(VirtualAlloc(nullptr, callbackBytes, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE));
        if (!renderScratch_) {
            Logf("SSYNENG host render scratch allocation failed bytes=%lu error=%lu",
                 static_cast<unsigned long>(callbackBytes), GetLastError());
            return false;
        }
        renderScratchBytes_ = callbackBytes;
        Logf("SSYNENG host render scratch allocated ptr=%p bytes=%lu", renderScratch_, static_cast<unsigned long>(renderScratchBytes_));
    }

    const bool contractChanged = callbackSlices != lastRenderCallbackSlices_ || callbackBytes != lastRenderCallbackBytes_;
    if (contractChanged || renderCallCount_ < 2u) {
        DumpRenderContract(contractChanged ? "AA9B0 contract changed" : "pre-AA9B0");
        lastRenderCallbackSlices_ = callbackSlices;
        lastRenderCallbackBytes_ = callbackBytes;
    }

    // Snapshot the newest externally injected Note On before the native AA9B0
    // callback.  If no newer Note On arrives while AA9B0 runs, the post-render
    // diagnostic below can inspect the exact voice/container state produced by
    // the original B08C0 -> A66B0 path.
    const DWORD pendingNoteSerialSnapshot = static_cast<DWORD>(InterlockedCompareExchange(&pendingNoteSerial_, 0, 0));
    const DWORD pendingNoteMsgSnapshot = static_cast<DWORD>(InterlockedCompareExchange(&pendingNoteMsg_, 0, 0));

    WORD rc = 0xffffu;
    uint32_t pcmPeak = 0, pcmNonZero = 0;
#if defined(_MSC_VER)
    __try {
        std::memset(renderScratch_, 0, callbackBytes);
        rc = RenderWithHostCpuAccounting(renderScratch_, callbackSlices, callbackFrames, accountingRate);
        ProbePcmSpan(static_cast<uint32_t>(reinterpret_cast<uintptr_t>(renderScratch_)),
                     callbackFrames, frameBytes, bits, &pcmPeak, &pcmNonZero);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG host AA9B0 render exception=%08lX scratch=%p slices=%u callbackBytes=%lu frames=%lu",
             GetExceptionCode(), renderScratch_, static_cast<unsigned>(callbackSlices),
             static_cast<unsigned long>(callbackBytes), static_cast<unsigned long>(callbackFrames));
        DumpRenderContract("AA9B0 exception");
        renderFaulted_ = true;
        return false;
    }
#else
    std::memset(renderScratch_, 0, callbackBytes);
    rc = RenderWithHostCpuAccounting(renderScratch_, callbackSlices, callbackFrames, accountingRate);
    ProbePcmSpan(static_cast<uint32_t>(reinterpret_cast<uintptr_t>(renderScratch_)),
                 callbackFrames, frameBytes, bits, &pcmPeak, &pcmNonZero);
#endif

    const DWORD pendingNoteSerialAfter = static_cast<DWORD>(InterlockedCompareExchange(&pendingNoteSerial_, 0, 0));
    if (pendingNoteSerialSnapshot != 0u &&
        pendingNoteSerialSnapshot == pendingNoteSerialAfter &&
        pendingNoteSerialSnapshot != lastTracedPendingNoteSerial_) {
        LogMidiNoteDisposition(pendingNoteMsgSnapshot, "native-AA9B0");
        lastTracedPendingNoteSerial_ = pendingNoteSerialSnapshot;
    }

    // CLAP bridge alpha: publish the recovered PCM before the DirectSound
    // compatibility copy. The x64 plugin consumes this ring asynchronously.
    const bool bridgePublished = clapbridge::PublishAudio(renderScratch_, callbackFrames,
                                                          accountingRate, bits, channels);
    const bool bridgeMuteDs = bridgePublished && clapbridge::MuteDirectSound();

    // Do not let AA9B0 retain or write through DirectSound's transient Lock()
    // pointer.  It always renders into owned scratch above.  Hold audioLock_
    // only for the short copy so an op=0B cannot return to SynMid (and hence
    // cannot Unlock the buffer) until this copy has finished.
    uint32_t copyBuffer = 0, copyBytes = 0, cursor = 0;
    bool copied = false;
    if (audioLockInit_) EnterCriticalSection(&audioLock_);
    copyBuffer = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioBuffer_, 0, 0));
    copyBytes = static_cast<uint32_t>(InterlockedCompareExchange(&modernAudioBytes_, 0, 0));
    if (modernAudioRegistered_ && copyBuffer && copyBytes >= callbackBytes &&
        PointerReadable(copyBuffer, std::min<uint32_t>(copyBytes, 4u))) {
        DWORD playCursor = 0, writeCursor = 0;
        const bool haveDsCursor = QueryModernAudioCursor(copyBuffer, copyBytes, &playCursor, &writeCursor);
        auto ringDistance = [copyBytes](DWORD from, DWORD to) -> DWORD {
            return to >= from ? (to - from) : (copyBytes - from + to);
        };
        auto alignFrame = [frameBytes, copyBytes](DWORD value) -> DWORD {
            value %= copyBytes;
            value -= value % frameBytes;
            return value;
        };

        cursor = alignFrame(renderCursorBytes_);
        bool needResync = !renderCursorPrimed_ || lastScheduledCallbackBytes_ != callbackBytes;
        const char* resyncReason = !renderCursorPrimed_ ? "startup/unprimed" : "callback-size-change";
        if (haveDsCursor && !needResync) {
            playCursor = alignFrame(playCursor);
            writeCursor = alignFrame(writeCursor);
            const DWORD playToWrite = ringDistance(playCursor, writeCursor);
            const DWORD playToCursor = ringDistance(playCursor, cursor);
            const DWORD cursorToPlay = ringDistance(cursor, playCursor);
            // DirectSound's unsafe write window is play..write.  Keep the
            // software producer out of that window and leave one whole
            // callback before playback catches it.  This also corrects small
            // hardware-clock/QPC drift without forcing a full audio reopen.
            if (playToCursor < playToWrite || cursorToPlay <= callbackBytes) {
                needResync = true;
                resyncReason = "cursor-entered-unsafe-window";
            }
        }
        if (needResync && haveDsCursor) {
            cursor = alignFrame(writeCursor);
            renderCursorBytes_ = cursor;
            renderCursorPrimed_ = true;
            lastScheduledCallbackBytes_ = callbackBytes;
            ++renderCursorResyncs_;
            if (renderCursorResyncs_ <= 16u || (renderCursorResyncs_ & (renderCursorResyncs_ - 1u)) == 0u)
                Logf("SSYNENG DirectSound cursor sync #%lu reason=%s play=%lu write=%lu cursor=%lu callbackBytes=%lu ringBytes=%lu",
                     static_cast<unsigned long>(renderCursorResyncs_), resyncReason,
                     static_cast<unsigned long>(playCursor), static_cast<unsigned long>(writeCursor),
                     static_cast<unsigned long>(cursor), static_cast<unsigned long>(callbackBytes),
                     static_cast<unsigned long>(copyBytes));
        } else if (!renderCursorPrimed_) {
            // Cursor bridge unavailable: preserve the old linear fallback, but
            // only after the native render contract is valid.
            renderCursorPrimed_ = true;
            lastScheduledCallbackBytes_ = callbackBytes;
            cursor = 0;
            renderCursorBytes_ = 0;
            Logf("SSYNENG DirectSound cursor bridge unavailable; using zero-phase fallback callbackBytes=%lu",
                 static_cast<unsigned long>(callbackBytes));
        }
        const uint32_t firstBytes = std::min<uint32_t>(callbackBytes, copyBytes - cursor);
        const uint32_t secondBytes = callbackBytes - firstBytes;
#if defined(_MSC_VER)
        __try {
            if (bridgeMuteDs) {
                if (firstBytes) std::memset(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer + cursor)), 0, firstBytes);
                if (secondBytes) std::memset(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer)), 0, secondBytes);
            } else {
                if (firstBytes) std::memcpy(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer + cursor)), renderScratch_, firstBytes);
                if (secondBytes) std::memcpy(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer)), renderScratch_ + firstBytes, secondBytes);
            }
            copied = true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            Logf("SSYNENG host DirectSound handoff exception=%08lX buffer=%08lX cursor=%lu bytes=%lu",
                 GetExceptionCode(), copyBuffer, static_cast<unsigned long>(cursor), static_cast<unsigned long>(callbackBytes));
            copied = false;
        }
#else
        if (bridgeMuteDs) {
            if (firstBytes) std::memset(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer + cursor)), 0, firstBytes);
            if (secondBytes) std::memset(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer)), 0, secondBytes);
        } else {
            if (firstBytes) std::memcpy(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer + cursor)), renderScratch_, firstBytes);
            if (secondBytes) std::memcpy(reinterpret_cast<void*>(static_cast<uintptr_t>(copyBuffer)), renderScratch_ + firstBytes, secondBytes);
        }
        copied = true;
#endif
        if (copied) {
            renderCursorBytes_ = (cursor + callbackBytes) % copyBytes;
            lastScheduledCallbackBytes_ = callbackBytes;
        }
    }
    if (audioLockInit_) LeaveCriticalSection(&audioLock_);

    ++renderCallCount_;
    const bool firstNonZero = pcmNonZero != 0u && !renderEverNonZero_;
    if (pcmNonZero != 0u) renderEverNonZero_ = true;
    const bool important = renderCallCount_ <= 8u || (renderCallCount_ & (renderCallCount_ - 1u)) == 0u ||
                           (renderCallCount_ % 256u) == 0u || firstNonZero ||
                           rc == 0xffffu || !copied;
    if (important) {
        Logf("SSYNENG host AA9B0 render call=%lu scratch=%p output=%08lX cursor=%lu slices=%u callbackBytes=%lu frames=%lu frameBytes=%lu rc=%u copied=%u pcmPeak=%lu pcmNonZero=%lu",
             static_cast<unsigned long>(renderCallCount_), renderScratch_, copyBuffer, static_cast<unsigned long>(cursor),
             static_cast<unsigned>(callbackSlices), static_cast<unsigned long>(callbackBytes),
             static_cast<unsigned long>(callbackFrames), static_cast<unsigned long>(frameBytes),
             static_cast<unsigned>(rc), copied ? 1u : 0u,
             static_cast<unsigned long>(pcmPeak), static_cast<unsigned long>(pcmNonZero));
    }
    return rc != 0xffffu && (copied || bridgePublished);
}

DWORD SsynengRehost::HostPumpMain() {
    LARGE_INTEGER qpf{};
    if (!QueryPerformanceFrequency(&qpf) || qpf.QuadPart <= 0) {
        Logf("SSYNENG host pump: QueryPerformanceFrequency failed; using 1 kHz fallback");
        qpf.QuadPart = 1000;
    }
    LARGE_INTEGER qpc{};
    QueryPerformanceCounter(&qpc);
    std::uint64_t nextRenderQpc = static_cast<std::uint64_t>(qpc.QuadPart);
    std::uint64_t periodRemainder = 0;
    DWORD scheduleFrames = 0, scheduleRate = 0;
    DWORD lateResyncs = 0;

    auto advanceDeadline = [&](DWORD frames, DWORD rate) {
        if (!frames || !rate) return;
        const std::uint64_t numerator = static_cast<std::uint64_t>(frames) *
                                        static_cast<std::uint64_t>(qpf.QuadPart);
        const std::uint64_t whole = numerator / rate;
        const std::uint64_t rem = numerator % rate;
        nextRenderQpc += whole;
        periodRemainder += rem;
        if (periodRemainder >= rate) {
            nextRenderQpc += periodRemainder / rate;
            periodRemainder %= rate;
        }
    };

    Logf("SSYNENG host pump high-resolution clock qpf=%lld", static_cast<long long>(qpf.QuadPart));
    clapbridge::EnsureOpen();
    for (;;) {
        if (hostPumpStopEvent_ && WaitForSingleObject(hostPumpStopEvent_, 0) == WAIT_OBJECT_0) break;
        if (clapbridge::ShutdownRequested()) {
            Logf("RealityCLAP bridge: shutdown requested; posting WM_CLOSE to Reality windows");
            clapbridge::RequestGracefulWindowClose();
            break;
        }

        // Drain DAW MIDI into the already-recovered SSYNENG MIDI ring. This
        // keeps the original B08C0/A66B0 timing/voice path intact.
        clapbridge::MidiEvent bridgeMidi{};
        unsigned bridgeMidiCount = 0;
        while (bridgeMidiCount < 256u && clapbridge::PopMidi(&bridgeMidi)) {
            InjectMidiShort(bridgeMidi.packedMessage, bridgeMidi.timestampMs);
            ++bridgeMidiCount;
        }

        DWORD rate = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioRate_, 0, 0));
        if (rate < 8000u) rate = 44100u;
        const DWORD bits = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioBits_, 0, 0));
        const DWORD channels = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioChannels_, 0, 0));
        const DWORD frameBytes = std::max<DWORD>(1u, channels * std::max<DWORD>(1u, bits / 8u));
        const DWORD outputBytes = static_cast<DWORD>(InterlockedCompareExchange(&modernAudioBytes_, 0, 0));
        const DWORD callbackBytes = ResolveNativeCallbackBytes(frameBytes, outputBytes, true);
        const DWORD callbackFrames = (callbackBytes && frameBytes && (callbackBytes % frameBytes) == 0u)
            ? callbackBytes / frameBytes : 0u;

        QueryPerformanceCounter(&qpc);
        std::uint64_t nowQpc = static_cast<std::uint64_t>(qpc.QuadPart);
        if (callbackFrames != scheduleFrames || rate != scheduleRate) {
            scheduleFrames = callbackFrames;
            scheduleRate = rate;
            periodRemainder = 0;
            nextRenderQpc = nowQpc;
            Logf("SSYNENG host pump schedule frames=%lu rate=%lu exactPeriodUs=%.3f",
                 static_cast<unsigned long>(callbackFrames), static_cast<unsigned long>(rate),
                 callbackFrames && rate ? (static_cast<double>(callbackFrames) * 1000000.0 / static_cast<double>(rate)) : 0.0);
        }

        // v13.6 deliberately does not decode the ring here.  AA9B0 invokes
        // the original B08C0 processor, which owns MIDI timing, admission, the
        // normal ring, and its auxiliary retry queues.  Calling A66B0 directly
        // before AA9B0 bypassed that context and was especially harmful to the
        // special type-2/program-layer path used by programs such as #3.

        if (!callbackFrames) {
            HANDLE waits[2] = { hostPumpStopEvent_, hostPumpWakeEvent_ };
            const DWORD wr = WaitForMultipleObjects(2, waits, FALSE, 5);
            if (wr == WAIT_OBJECT_0) break;
            continue;
        }

        QueryPerformanceCounter(&qpc);
        nowQpc = static_cast<std::uint64_t>(qpc.QuadPart);
        if (nowQpc < nextRenderQpc) {
            const std::uint64_t diff = nextRenderQpc - nowQpc;
            DWORD waitMs = static_cast<DWORD>((diff * 1000ull) / static_cast<std::uint64_t>(qpf.QuadPart));
            if (waitMs == 0) waitMs = 1; // SSYNMIDI32 keeps the multimedia timer at 1 ms.
            if (waitMs > 20) waitMs = 20;
            HANDLE waits[2] = { hostPumpStopEvent_, hostPumpWakeEvent_ };
            const DWORD wr = WaitForMultipleObjects(2, waits, FALSE, waitMs);
            if (wr == WAIT_OBJECT_0) break;
            continue;
        }

        // Keep the deadline anchored to the audio sample clock rather than to
        // GetTickCount64 milliseconds.  v13.2 rounded a 256/44100 quantum
        // (5.804988 ms) to 6 ms, making the producer ~3.36% slow and causing
        // the periodic crackle as DirectSound caught the software write head.
        unsigned catchUp = 0;
        do {
            const bool rendered = RenderHostQuantum();
            ObserveNativeMidiAfterRender(rendered);
            advanceDeadline(callbackFrames, rate);
            ++catchUp;
            QueryPerformanceCounter(&qpc);
            nowQpc = static_cast<std::uint64_t>(qpc.QuadPart);
        } while (nowQpc >= nextRenderQpc && catchUp < 4u);

        if (catchUp >= 4u && nowQpc >= nextRenderQpc) {
            ++lateResyncs;
            nextRenderQpc = nowQpc;
            periodRemainder = 0;
            advanceDeadline(callbackFrames, rate);
            if (lateResyncs <= 8u || (lateResyncs & (lateResyncs - 1u)) == 0u)
                Logf("SSYNENG host pump late resync #%lu catchUp=%u", static_cast<unsigned long>(lateResyncs), catchUp);
        }
    }
    return 0;
}

bool SsynengRehost::InitializeLifecycle() {
    if (lifecycleReady_) return true;
    if (!CoreReady() && !InitializeCore()) return false;
    auto* fn = reinterpret_cast<DWORD (__cdecl*)(DWORD)>(Ptr(1, 0xB1EF0));
    if (!fn) return false;
    DWORD rc = 0;
#if defined(_MSC_VER)
    __try { rc = fn(1); }
    __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG lifecycle initializer exception=%08lX", GetExceptionCode());
        return false;
    }
#else
    rc = fn(1);
#endif
    lifecycleReady_ = (rc == 1u);
    Logf("SSYNENG lifecycle service3 phase B1EF0(1) rc=%lu ready=%u", rc, lifecycleReady_ ? 1u : 0u);
    if (lifecycleReady_) DumpSynthState("after lifecycle init");
    return lifecycleReady_;
}

bool SsynengRehost::TryStartOutput() {
    if (!InitializeLifecycle()) return false;
    const uint32_t stateAddress = ReadObjectU32(0x2A5C4);
    if (!PointerReadable(stateAddress, 0x300u)) {
        Logf("SSYNENG output start deferred: engine state pointer invalid=%08lX", stateAddress);
        return false;
    }
    auto* state = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(stateAddress));
    uint32_t running = 0;
    std::memcpy(&running, state + 0x258, sizeof(running));
    if (running) return true;

    // Service 3 derives the legacy output mode immediately before B6E90:
    // exactly 44100 Hz selects mode 4, every other configured rate selects
    // mode 2 (the old engine's 22050-Hz path). Preserve that state because
    // the downstream DirectSound/WaveOut setup reads +0x256.
    uint32_t configuredRate = 0;
    std::memcpy(&configuredRate, state + 0x284, sizeof(configuredRate));
    const uint16_t outputMode = configuredRate == 44100u ? 4u : 2u;
    std::memcpy(state + 0x256, &outputMode, sizeof(outputMode));
    Logf("SSYNENG service3 output mode rate=%lu mode=%u",
         static_cast<unsigned long>(configuredRate), static_cast<unsigned>(outputMode));

    auto* conflict = reinterpret_cast<WORD (__cdecl*)(DWORD)>(Ptr(1, 0x8DF90));
    auto* openOut = reinterpret_cast<WORD (__cdecl*)()>(Ptr(1, 0xB6E90));
    if (!conflict || !openOut) return false;

    WORD conflictRc = 0;
    WORD openRc = 0xffffu;
#if defined(_MSC_VER)
    __try {
        conflictRc = conflict(2);
        if (conflictRc == 0) openRc = openOut();
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG output start exception=%08lX", GetExceptionCode());
        return false;
    }
#else
    conflictRc = conflict(2);
    if (conflictRc == 0) openRc = openOut();
#endif
    if (conflictRc != 0 || openRc != 0) {
        Logf("SSYNENG output start deferred/failed conflict=%u open=%u (will retry after audio registration)",
             static_cast<unsigned>(conflictRc), static_cast<unsigned>(openRc));
        return false;
    }
    const uint32_t one = 1, zero = 0;
    std::memcpy(state + 0x258, &one, sizeof(one));
    std::memcpy(state + 0x0A, &zero, sizeof(uint16_t));
    legacyOutputOpened_ = true;
    Logf("SSYNENG service3 legacy output running state=%08lX", stateAddress);
    return true;
}

BOOL SsynengRehost::StartEngine() {
    startRequested_ = true;
    if (!InitializeLifecycle()) {
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }

    const uint32_t stateAddress = ReadObjectU32(0x2A5C4);
    if (PointerReadable(stateAddress, 0x300u)) {
        auto* state = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(stateAddress));
        uint32_t configuredRate = 0;
        std::memcpy(&configuredRate, state + 0x284, sizeof(configuredRate));
        const uint16_t outputMode = configuredRate == 44100u ? 4u : 2u;
        std::memcpy(state + 0x256, &outputMode, sizeof(outputMode));
        Logf("SSYNENG service3 output mode rate=%lu mode=%u transport=SynMid/7002",
             static_cast<unsigned long>(configuredRate), static_cast<unsigned>(outputMode));
    }
    // 0x7002 frequently arrives before the synthetic Reality MIDI device is
    // opened.  Service 3 must therefore re-assert the old output-running bit
    // after lifecycle startup as well as at the 0x7002 boundary.
    if (modernAudioRegistered_) {
        MarkModernOutputRunning("service3 after prior 7002");
        ConfigureModernRateMixerBridge(
            static_cast<DWORD>(InterlockedCompareExchange(&modernAudioRate_, 0, 0)),
            static_cast<DWORD>(InterlockedCompareExchange(&modernAudioBits_, 0, 0)),
            static_cast<DWORD>(InterlockedCompareExchange(&modernAudioChannels_, 0, 0)),
            "service3 after prior 7002");
        if (audioLockInit_) EnterCriticalSection(&audioLock_);
        renderCursorPrimed_ = false;
        lastScheduledCallbackBytes_ = 0;
        if (audioLockInit_) LeaveCriticalSection(&audioLock_);
        if (hostPumpWakeEvent_) SetEvent(hostPumpWakeEvent_);
        Logf("SSYNENG service3 completed after early 7002; DirectSound cursor will re-prime against live play/write position");
    }
    EnsureHostPump();

    char legacy[16] = {};
    const DWORD n = GetEnvironmentVariableA("REALITY_LEGACY_OUTPUT_OPEN", legacy, sizeof(legacy));
    if (n && n < sizeof(legacy) &&
        (_stricmp(legacy, "1") == 0 || _stricmp(legacy, "true") == 0 || _stricmp(legacy, "yes") == 0)) {
        Logf("SSYNENG REALITY_LEGACY_OUTPUT_OPEN enabled; attempting original B6E90 backend");
        TryStartOutput();
    }
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

BOOL SsynengRehost::StopEngine() {
    startRequested_ = false;
    StopHostPump();
    if (!bridgeArmed_ || !CoreReady()) return TRUE;
    const uint32_t stateAddress = ReadObjectU32(0x2A5C4);
    auto* reset = reinterpret_cast<void (__cdecl*)()>(Ptr(1, 0xA6050));
    auto* closeOut = reinterpret_cast<WORD (__cdecl*)()>(Ptr(1, 0x964E0));
    auto* releaseMap = reinterpret_cast<void (__cdecl*)()>(Ptr(1, 0x94A10));
    auto* finalCleanup = reinterpret_cast<void (__cdecl*)()>(Ptr(1, 0xAE030));
    WORD closeRc = 0;
#if defined(_MSC_VER)
    __try {
        if (reset) reset();
        if (PointerReadable(stateAddress, 0x300u)) {
            auto* state = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(stateAddress));
            uint16_t present = 0; std::memcpy(&present, state + 0x250, sizeof(present));
            if (legacyOutputOpened_ && present && closeOut) closeRc = closeOut();
            if (legacyOutputOpened_ && present && releaseMap) releaseMap();
            const uint32_t zero = 0; std::memcpy(state + 0x258, &zero, sizeof(zero));
        }
        if (auto* processGate = reinterpret_cast<uint8_t*>(Ptr(1, 0x20912))) *processGate = 0;
        if (finalCleanup) finalCleanup();
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG service4 teardown exception=%08lX", GetExceptionCode());
        SetLastError(GetExceptionCode());
        return FALSE;
    }
#else
    if (reset) reset();
    if (legacyOutputOpened_ && closeOut) closeRc = closeOut();
    if (legacyOutputOpened_ && releaseMap) releaseMap();
    if (auto* processGate = reinterpret_cast<uint8_t*>(Ptr(1, 0x20912))) *processGate = 0;
    if (finalCleanup) finalCleanup();
#endif
    lifecycleReady_ = false;
    modernAudioRegistered_ = false;
    legacyOutputOpened_ = false;
    Logf("SSYNENG service4 teardown closeRc=%u", static_cast<unsigned>(closeRc));
    SetLastError(closeRc ? ERROR_GEN_FAILURE : ERROR_SUCCESS);
    return closeRc ? FALSE : TRUE;
}

BOOL SsynengRehost::ResetMidi(bool fullGmGsReset) {
    if (!CoreReady() && !InitializeCore()) { SetLastError(ERROR_NOT_READY); return FALSE; }
    auto* reset = reinterpret_cast<void (__cdecl*)()>(Ptr(1, 0xA6050));
    if (!reset) { SetLastError(ERROR_PROC_NOT_FOUND); return FALSE; }
#if defined(_MSC_VER)
    __try {
#endif
        reset();
        if (fullGmGsReset) {
            auto* initQueues = reinterpret_cast<void (__cdecl*)()>(Ptr(1, 0xAC880));
            auto* initChannel = reinterpret_cast<void (__cdecl*)(void*)>(Ptr(1, 0xA59D0));
            auto* setup1 = reinterpret_cast<void (__cdecl*)(void*, void*)>(Ptr(1, 0x83320));
            auto* setup2 = reinterpret_cast<void (__cdecl*)(void*, void*)>(Ptr(1, 0xAC2F0));
            auto* setup3 = reinterpret_cast<void (__cdecl*)(DWORD)>(Ptr(1, 0xAB7D0));
            if (initQueues) initQueues();
            const uint32_t channels = ReadObjectU32(0x208A0);
            if (initChannel && PointerReadable(channels, 16u * 0x7A4u)) {
                for (unsigned i = 0; i < 16; ++i)
                    initChannel(reinterpret_cast<void*>(static_cast<uintptr_t>(channels + i * 0x7A4u)));
            }
            if (setup1) setup1(Ptr(1, 0xA100), Ptr(1, 0x3C970));
            if (setup2) setup2(Ptr(1, 0x1E800), Ptr(1, 0x3C970));
            if (setup3) setup3(0);
        }
#if defined(_MSC_VER)
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("SSYNENG MIDI reset exception=%08lX full=%u", GetExceptionCode(), fullGmGsReset ? 1u : 0u);
        SetLastError(GetExceptionCode());
        return FALSE;
    }
#endif
    // The original reset routines are allowed to restore their legacy output
    // format globals.  On the NT/DirectSound rehost the real transport remains
    // at modernAudioRate_, so immediately restore the v13.10 split-rate bridge:
    // 44.1-kHz transport => selector 0 + 8CD20 compare 0.
    ConfigureModernRateMixerBridge(
        static_cast<DWORD>(InterlockedCompareExchange(&modernAudioRate_, 0, 0)),
        static_cast<DWORD>(InterlockedCompareExchange(&modernAudioBits_, 0, 0)),
        static_cast<DWORD>(InterlockedCompareExchange(&modernAudioChannels_, 0, 0)),
        fullGmGsReset ? "post GM/GS reset" : "post MIDI reset");
    EnsureModernRateMixerBridge(fullGmGsReset ? "verify post GM/GS reset" : "verify post MIDI reset");

    Logf("SSYNENG service %s MIDI reset complete", fullGmGsReset ? "0B GM/GS" : "0A");
    DumpRenderContract(fullGmGsReset ? "after GM/GS reset rate restore" : "after MIDI reset rate restore");
    DumpSynthState(fullGmGsReset ? "after GM/GS reset" : "after MIDI reset");
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

BOOL SsynengRehost::InjectMidiShort(DWORD packedMessage, DWORD timestampMs) {
    if (!bridgeArmed_ || !CoreReady()) {
        Logf("SSYNENG MIDI inject rejected armed=%u ready=%u msg=%08lX",
             bridgeArmed_ ? 1u : 0u, CoreReady() ? 1u : 0u, packedMessage);
        SetLastError(ERROR_NOT_READY);
        return FALSE;
    }
    const BYTE status = static_cast<BYTE>(packedMessage & 0xffu);
    if ((status & 0x80u) == 0) { SetLastError(ERROR_INVALID_DATA); return FALSE; }
    const DWORD msg24ForTrace = packedMessage & 0x00ffffffu;
    const BYTE statusHi = status & 0xf0u;
    const BYTE traceNote = static_cast<BYTE>((msg24ForTrace >> 8) & 0x7fu);
    const BYTE traceVelocity = static_cast<BYTE>((msg24ForTrace >> 16) & 0x7fu);
    const bool traceNoteOn = statusHi == 0x90u && traceVelocity != 0u;
    const unsigned traceBaselineMatches = traceNoteOn
        ? CountMatchingVoices(status & 0x0fu, traceNote, nullptr) : 0u;

    // Exact realtime transport recovered from SSYNMIDI.DRV / SSYNENG.VXD:
    // 0x101C bytes, 512 entries, each {packedMidi,timestamp}.
    auto* ring = reinterpret_cast<uint8_t*>(Ptr(1, 0x1BEE0));
    if (!ring || !midiLockInit_) { SetLastError(ERROR_NOT_READY); return FALSE; }

    EnterCriticalSection(&midiLock_);
    uint32_t writeIndex = 0, readIndex = 0;
    std::memcpy(&writeIndex, ring + 0x00, 4);
    std::memcpy(&readIndex, ring + 0x04, 4);
    writeIndex &= 0x1ffu;
    readIndex &= 0x1ffu;
    // readIndex is the last consumed slot; writeIndex is the next free slot.
    // The initial empty state is write=0/read=0x1ff. One slot is reserved to
    // keep empty/full distinguishable, so write==read means full.
    if (writeIndex == readIndex) {
        LeaveCriticalSection(&midiLock_);
        Logf("SSYNENG MIDI event ring full msg=%08lX", packedMessage);
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return FALSE;
    }
    const uint32_t next = (writeIndex + 1u) & 0x1ffu;
    uint8_t* event = ring + 0x1Cu + writeIndex * 8u;
    const uint32_t msg24 = packedMessage & 0x00ffffffu;
    std::memcpy(event + 0, &msg24, 4);
    std::memcpy(event + 4, &timestampMs, 4);
    std::memcpy(ring + 0x00, &next, 4);
    uint32_t produced = 0; std::memcpy(&produced, ring + 0x14, 4); ++produced;
    std::memcpy(ring + 0x14, &produced, 4);
    LeaveCriticalSection(&midiLock_);

    if (traceNoteOn) {
        InterlockedExchange(&pendingNoteBaselineMatches_, static_cast<LONG>(traceBaselineMatches));
        InterlockedExchange(&pendingNoteMsg_, static_cast<LONG>(msg24));
        InterlockedIncrement(&pendingNoteSerial_);
    }

    Logf("SSYNENG MIDI event queued idx=%lu->%lu msg=%08lX time=%lu produced=%lu",
         writeIndex, next, msg24, timestampMs, produced);
    if (hostPumpWakeEvent_) SetEvent(hostPumpWakeEvent_);
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

} // namespace reality
