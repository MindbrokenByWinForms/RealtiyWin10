#include "vmm_bridge.h"
#include "log.h"
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>
#include <new>

namespace reality {
namespace {
uint8_t* g_base = nullptr;
uint32_t g_size = 0;
PVOID g_veh = nullptr;
std::vector<uint32_t> g_sites;
std::unordered_set<uint32_t> g_unknownLogged;
CRITICAL_SECTION g_lock;
bool g_lockInit = false;
HANDLE g_timerQueue = nullptr;
volatile LONG g_timerShutdown = 0;
volatile LONG g_timeoutCreated = 0;
volatile LONG g_timeoutFired = 0;
volatile LONG g_timeoutCancelled = 0;

struct HostTimeout {
    HANDLE timer = nullptr;
    DWORD callback = 0;
    DWORD refData = 0;
    DWORD delayMs = 0;
    volatile LONG cancelled = 0;
};
std::unordered_map<DWORD, HostTimeout*> g_timeouts;

struct HostRingThread {
    HANDLE thread = nullptr;
    DWORD threadId = 0;
    DWORD entry = 0;
    DWORD refData = 0;
};
std::vector<HostRingThread*> g_ringThreads;

// Win95 VWIN32 service 0002h queues a Ring-3 callback to the thread whose
// Ring-0 thread handle was captured by Get_Cur_Thread_Handle.  In the rehost
// we deliberately use the Win32 thread id as that opaque handle.  A normal
// QueueUserAPC is not sufficient here because Reality's UI thread normally
// sits in GetMessage/DispatchMessage rather than an alertable wait.  A
// thread-specific WH_GETMESSAGE hook gives us the important legacy semantic:
// execute the callback later, on the registered application thread.
struct HostUserApc {
    DWORD proc = 0;
    DWORD param = 0;
    DWORD threadId = 0;
    LONG sequence = 0;
};
std::unordered_map<DWORD, std::vector<HostUserApc>> g_userApcQueues;
std::unordered_map<DWORD, HHOOK> g_userApcHooks;
UINT g_userApcMessage = 0;
volatile LONG g_userApcQueued = 0;
volatile LONG g_userApcDelivered = 0;
volatile LONG g_userApcPostFailures = 0;

struct FakeDescriptor {
    uint32_t low = 0;
    uint32_t high = 0;
};
std::unordered_map<uint16_t, FakeDescriptor> g_descriptors;
std::unordered_map<uint16_t, uint16_t> g_selectorAllocCount;
uint16_t g_nextSelector = 0x2007; // TI=1, RPL=3, comfortably below signed 16-bit range.
std::unordered_map<HKEY, std::string> g_virtualRegistryKeys;

struct HostList {
    uint32_t nodeSize = 0;
    std::vector<void*> nodes;
};

#if defined(_MSC_VER) && defined(_M_IX86)
// A VMM timeout callback is entered with EBX=VM handle, EDX=reference data and
// ECX=timeout latency.  SSYNENG's compiler-generated callback thunk converts
// those registers to the four stack arguments expected by its __stdcall C
// routine.  Preserve that legacy register ABI rather than calling the engine
// function with an invented C signature.
static __declspec(naked) void InvokeVmmTimeoutCallback(DWORD, DWORD, DWORD) {
    __asm {
        pushad
        mov eax, [esp + 36]
        mov edx, [esp + 40]
        mov ecx, [esp + 44]
        mov ebx, 1
        xor ebp, ebp
        call eax
        popad
        ret 12
    }
}
#else
static void InvokeVmmTimeoutCallback(DWORD callback, DWORD, DWORD) {
    reinterpret_cast<void (*)()>(static_cast<uintptr_t>(callback))();
}
#endif

static VOID CALLBACK HostTimeoutCallback(PVOID parameter, BOOLEAN) {
    auto* timeout = static_cast<HostTimeout*>(parameter);
    if (!timeout || InterlockedCompareExchange(&g_timerShutdown, 0, 0) != 0 ||
        InterlockedCompareExchange(&timeout->cancelled, 0, 0) != 0) return;
    const LONG sequence = InterlockedIncrement(&g_timeoutFired);
    if (sequence <= 8 || (sequence % 256) == 0) {
        Logf("VMM timeout fire sequence=%ld handle=%p callback=%08lX refData=%08lX delayMs=%lu",
             sequence, timeout, timeout->callback, timeout->refData, timeout->delayMs);
    }
#if defined(_MSC_VER)
    __try {
        InvokeVmmTimeoutCallback(timeout->callback, timeout->refData, timeout->delayMs);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("VMM timeout callback exception code=%08lX handle=%p callback=%08lX refData=%08lX",
             GetExceptionCode(), timeout, timeout->callback, timeout->refData);
    }
#else
    InvokeVmmTimeoutCallback(timeout->callback, timeout->refData, timeout->delayMs);
#endif
}

static DWORD WINAPI HostRingThreadStart(LPVOID parameter) {
    auto* worker = static_cast<HostRingThread*>(parameter);
    if (!worker || !worker->entry) return ERROR_INVALID_PARAMETER;
    Logf("VWIN32 ring-0 worker enter threadId=%lu entry=%08lX refData=%08lX",
         GetCurrentThreadId(), worker->entry, worker->refData);
    DWORD result = ERROR_GEN_FAILURE;
    using RingEntry = DWORD (__cdecl*)(void*);
#if defined(_MSC_VER)
    __try {
        result = reinterpret_cast<RingEntry>(static_cast<uintptr_t>(worker->entry))(
            reinterpret_cast<void*>(static_cast<uintptr_t>(worker->refData)));
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        result = GetExceptionCode();
        Logf("VWIN32 ring-0 worker exception code=%08lX threadId=%lu entry=%08lX refData=%08lX",
             result, GetCurrentThreadId(), worker->entry, worker->refData);
    }
#else
    result = reinterpret_cast<RingEntry>(static_cast<uintptr_t>(worker->entry))(
        reinterpret_cast<void*>(static_cast<uintptr_t>(worker->refData)));
#endif
    Logf("VWIN32 ring-0 worker exit threadId=%lu result=%08lX", GetCurrentThreadId(), result);
    return result;
}

static bool ExecutableUserPointer(DWORD proc) {
    if (!proc) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<const void*>(static_cast<uintptr_t>(proc)), &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS))) return false;
    const DWORD protection = mbi.Protect & 0xffu;
    return protection == PAGE_EXECUTE || protection == PAGE_EXECUTE_READ ||
           protection == PAGE_EXECUTE_READWRITE || protection == PAGE_EXECUTE_WRITECOPY;
}

static void InvokeVwin32UserApc(const HostUserApc& apc) {
    const LONG delivered = InterlockedIncrement(&g_userApcDelivered);
    if (!ExecutableUserPointer(apc.proc)) {
        Logf("VWIN32 QueueUserApc drop sequence=%ld threadId=%lu proc=%08lX param=%08lX reason=non-executable",
             apc.sequence, apc.threadId, apc.proc, apc.param);
        return;
    }
    if (delivered <= 16 || (delivered % 128) == 0) {
        Logf("VWIN32 QueueUserApc deliver sequence=%ld delivered=%ld threadId=%lu proc=%08lX param=%08lX",
             apc.sequence, delivered, apc.threadId, apc.proc, apc.param);
    }
    using ApcProc = void (WINAPI*)(ULONG_PTR);
#if defined(_MSC_VER)
    __try {
        reinterpret_cast<ApcProc>(static_cast<uintptr_t>(apc.proc))(static_cast<ULONG_PTR>(apc.param));
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("VWIN32 QueueUserApc callback exception sequence=%ld code=%08lX threadId=%lu proc=%08lX param=%08lX",
             apc.sequence, GetExceptionCode(), apc.threadId, apc.proc, apc.param);
    }
#else
    reinterpret_cast<ApcProc>(static_cast<uintptr_t>(apc.proc))(static_cast<ULONG_PTR>(apc.param));
#endif
}

static bool TakeUserApc(DWORD threadId, LONG sequence, HostUserApc& out) {
    bool found = false;
    EnterCriticalSection(&g_lock);
    auto qi = g_userApcQueues.find(threadId);
    if (qi != g_userApcQueues.end()) {
        auto& queue = qi->second;
        auto it = std::find_if(queue.begin(), queue.end(), [sequence](const HostUserApc& item) {
            return item.sequence == sequence;
        });
        if (it != queue.end()) {
            out = *it;
            queue.erase(it);
            found = true;
        }
        if (queue.empty()) g_userApcQueues.erase(qi);
    }
    LeaveCriticalSection(&g_lock);
    return found;
}

static LRESULT CALLBACK HostUserApcGetMessageHook(int code, WPARAM wParam, LPARAM lParam) {
    if (code >= 0 && lParam && g_userApcMessage) {
        MSG* message = reinterpret_cast<MSG*>(lParam);
        if (message->message == g_userApcMessage) {
            const LONG sequence = static_cast<LONG>(message->wParam);
            HostUserApc apc{};
            const DWORD threadId = GetCurrentThreadId();
            message->message = WM_NULL;
            message->wParam = 0;
            message->lParam = 0;
            if (TakeUserApc(threadId, sequence, apc)) InvokeVwin32UserApc(apc);
            else Logf("VWIN32 QueueUserApc carrier without queued item sequence=%ld threadId=%lu", sequence, threadId);
        }
    }
    return CallNextHookEx(nullptr, code, wParam, lParam);
}

static HHOOK EnsureUserApcHook(DWORD threadId) {
    if (!threadId) return nullptr;
    EnterCriticalSection(&g_lock);
    auto existing = g_userApcHooks.find(threadId);
    HHOOK hook = existing == g_userApcHooks.end() ? nullptr : existing->second;
    LeaveCriticalSection(&g_lock);
    if (hook) return hook;

    // v13.7 passed hMod=NULL.  That is only reliable when Windows can prove the
    // hook proc belongs to the caller's executable image.  Our proc lives in the
    // rehost DLL, and Windows 10 returned ERROR_INVALID_PARAMETER (87) for every
    // attempt in the field trace.  Resolve the containing HMODULE explicitly.
    HMODULE hookModule = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                       GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       reinterpret_cast<LPCWSTR>(reinterpret_cast<ULONG_PTR>(&HostUserApcGetMessageHook)),
                       &hookModule);

    DWORD ownerPid = 0;
    HANDLE thread = OpenThread(THREAD_QUERY_LIMITED_INFORMATION, FALSE, threadId);
    if (thread) {
        ownerPid = GetProcessIdOfThread(thread);
        CloseHandle(thread);
    }
    if (!ownerPid || ownerPid != GetCurrentProcessId()) {
        Logf("VWIN32 QueueUserApc target-thread validation failed threadId=%lu ownerPid=%lu currentPid=%lu module=%p",
             threadId, ownerPid, GetCurrentProcessId(), hookModule);
        return nullptr;
    }

    HHOOK created = SetWindowsHookExW(WH_GETMESSAGE, HostUserApcGetMessageHook, hookModule, threadId);
    if (!created) {
        Logf("VWIN32 QueueUserApc SetWindowsHookEx failed threadId=%lu ownerPid=%lu module=%p error=%lu",
             threadId, ownerPid, hookModule, GetLastError());
        return nullptr;
    }
    EnterCriticalSection(&g_lock);
    auto inserted = g_userApcHooks.emplace(threadId, created);
    hook = inserted.first->second;
    LeaveCriticalSection(&g_lock);
    if (!inserted.second) UnhookWindowsHookEx(created);
    else Logf("VWIN32 QueueUserApc installed WH_GETMESSAGE hook threadId=%lu hook=%p", threadId, created);
    return hook;
}

static bool QueueVwin32UserApc(DWORD proc, DWORD param, DWORD threadId) {
    const bool executable = ExecutableUserPointer(proc);
    if (!proc || !threadId || !executable) {
        Logf("VWIN32 QueueUserApc rejected threadId=%lu proc=%08lX param=%08lX executable=%u",
             threadId, proc, param, executable ? 1u : 0u);
        return false;
    }
    if (!g_userApcMessage || !EnsureUserApcHook(threadId)) return false;

    HostUserApc apc{};
    apc.proc = proc;
    apc.param = param;
    apc.threadId = threadId;
    apc.sequence = InterlockedIncrement(&g_userApcQueued);
    EnterCriticalSection(&g_lock);
    g_userApcQueues[threadId].push_back(apc);
    LeaveCriticalSection(&g_lock);

    if (!PostThreadMessageW(threadId, g_userApcMessage, static_cast<WPARAM>(apc.sequence), 0)) {
        const DWORD error = GetLastError();
        HostUserApc discarded{};
        TakeUserApc(threadId, apc.sequence, discarded);
        InterlockedIncrement(&g_userApcPostFailures);
        Logf("VWIN32 QueueUserApc PostThreadMessage failed sequence=%ld threadId=%lu proc=%08lX param=%08lX error=%lu",
             apc.sequence, threadId, proc, param, error);
        return false;
    }
    if (apc.sequence <= 16 || (apc.sequence % 128) == 0) {
        Logf("VWIN32 QueueUserApc queued sequence=%ld threadId=%lu proc=%08lX param=%08lX",
             apc.sequence, threadId, proc, param);
    }
    return true;
}

static const char* RegistryRootName(HKEY root) {
    if (root == HKEY_LOCAL_MACHINE) return "HKLM";
    if (root == HKEY_CURRENT_USER) return "HKCU";
    if (root == HKEY_CLASSES_ROOT) return "HKCR";
    return "HKEY";
}

static bool IsSeerEngineRegistryPath(const std::string& path) {
    static const char* const prefixes[] = {
        "HKLM\\SOFTWARE\\Seer Systems, Inc.\\SynthEngine",
        "HKLM\\SOFTWARE\\Seer Systems, Inc.\\Synthesis Engine",
    };
    for (const char* prefix : prefixes) {
        const size_t n = std::strlen(prefix);
        if (path.size() >= n && _strnicmp(path.c_str(), prefix, n) == 0 &&
            (path.size() == n || path[n] == '\\')) return true;
    }
    return false;
}

static bool LookupVirtualRegistryPath(HKEY key, std::string& path) {
    EnterCriticalSection(&g_lock);
    auto it = g_virtualRegistryKeys.find(key);
    const bool found = it != g_virtualRegistryKeys.end();
    if (found) path = it->second;
    LeaveCriticalSection(&g_lock);
    return found;
}

static HKEY CreateVirtualRegistryKey(const std::string& path) {
    HANDLE event = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!event) return nullptr;
    HKEY key = reinterpret_cast<HKEY>(event);
    EnterCriticalSection(&g_lock);
    g_virtualRegistryKeys[key] = path;
    LeaveCriticalSection(&g_lock);
    return key;
}

static bool CloseVirtualRegistryKey(HKEY key) {
    bool found = false;
    EnterCriticalSection(&g_lock);
    auto it = g_virtualRegistryKeys.find(key);
    if (it != g_virtualRegistryKeys.end()) {
        g_virtualRegistryKeys.erase(it);
        found = true;
    }
    LeaveCriticalSection(&g_lock);
    if (found) CloseHandle(reinterpret_cast<HANDLE>(key));
    return found;
}

static std::string JoinRegistryPath(HKEY root, LPCSTR subkey) {
    std::string parent;
    if (!LookupVirtualRegistryPath(root, parent)) parent = RegistryRootName(root);
    if (subkey && *subkey) {
        if (!parent.empty() && parent.back() != '\\') parent.push_back('\\');
        parent += subkey;
    }
    return parent;
}

static LSTATUS CopyVmmRegistryString(const char* value, LPDWORD type,
                                     LPBYTE data, LPDWORD dataBytes) {
    if (!value) return ERROR_FILE_NOT_FOUND;
    if (type) *type = REG_SZ;
    if (!dataBytes) return data ? ERROR_INVALID_PARAMETER : ERROR_SUCCESS;
    const DWORD needed = static_cast<DWORD>(std::strlen(value) + 1);
    if (!data) {
        *dataBytes = needed;
        return ERROR_SUCCESS;
    }
    if (*dataBytes < needed) {
        *dataBytes = needed;
        return ERROR_MORE_DATA;
    }
    std::memcpy(data, value, needed);
    *dataBytes = needed;
    return ERROR_SUCCESS;
}

static bool InRange(const void* p) {
    auto q = reinterpret_cast<uintptr_t>(p);
    auto b = reinterpret_cast<uintptr_t>(g_base);
    return g_base && q >= b && q + 6 <= b + g_size;
}
static void SetCarry(CONTEXT* c, bool set) {
    if (set) c->EFlags |= 1u; else c->EFlags &= ~1u;
}
static DWORD StackArg(const CONTEXT* c, size_t indexAfterReturn) {
    // For VMMJmp-style thunks, ESP still points at the CALL return address.
    auto* p = reinterpret_cast<const DWORD*>(static_cast<uintptr_t>(c->Esp));
    return p[indexAfterReturn + 1];
}
static DWORD IntStackArg(const CONTEXT* c, size_t index) {
    // A handful of SSYNENG wrappers PUSH the VMM arguments and execute INT 20h
    // inline.  At the trap ESP therefore points directly at argument 0 rather
    // than at a CALL return address.
    auto* p = reinterpret_cast<const DWORD*>(static_cast<uintptr_t>(c->Esp));
    return p[index];
}
static FakeDescriptor MakeDescriptor(uint32_t base, uint32_t limit, uint32_t access, uint32_t flags) {
    FakeDescriptor d{};
    d.low = (limit & 0x0000ffffu) | ((base & 0x0000ffffu) << 16);
    d.high = ((base >> 16) & 0xffu)
           | ((access & 0xffu) << 8)
           | (limit & 0x000f0000u)
           | ((flags & 0xf0u) << 16)
           | (base & 0xff000000u);
    return d;
}
static uint32_t DescriptorBase(const FakeDescriptor& d) {
    return ((d.low >> 16) & 0xffffu)
         | ((d.high & 0x000000ffu) << 16)
         | (d.high & 0xff000000u);
}
static uint16_t AllocateFakeSelectors(uint16_t count, const FakeDescriptor& initial) {
    if (!count) count = 1;
    EnterCriticalSection(&g_lock);
    uint16_t first = g_nextSelector;
    const uint32_t last = static_cast<uint32_t>(first) + static_cast<uint32_t>(count - 1u) * 8u;
    if (last >= 0x7fffu) {
        first = 0x2007;
        g_nextSelector = first;
    }
    for (uint16_t i = 0; i < count; ++i) {
        const uint16_t sel = static_cast<uint16_t>(first + i * 8u);
        g_descriptors[sel] = initial;
    }
    g_selectorAllocCount[first] = count;
    g_nextSelector = static_cast<uint16_t>(first + count * 8u);
    LeaveCriticalSection(&g_lock);
    return first;
}
static bool LookupDescriptor(uint16_t selector, FakeDescriptor& out) {
    EnterCriticalSection(&g_lock);
    auto it = g_descriptors.find(static_cast<uint16_t>(selector & 0xfff8u | 0x0007u));
    if (it == g_descriptors.end()) it = g_descriptors.find(selector);
    const bool found = it != g_descriptors.end();
    if (found) out = it->second;
    LeaveCriticalSection(&g_lock);
    return found;
}
static void StoreDescriptor(uint16_t selector, const FakeDescriptor& d) {
    EnterCriticalSection(&g_lock);
    auto it = g_descriptors.find(selector);
    if (it == g_descriptors.end()) {
        const uint16_t normalized = static_cast<uint16_t>(selector & 0xfff8u | 0x0007u);
        g_descriptors[normalized] = d;
    } else {
        it->second = d;
    }
    LeaveCriticalSection(&g_lock);
}
static void TailReturn(CONTEXT* c) {
    auto* p = reinterpret_cast<const DWORD*>(static_cast<uintptr_t>(c->Esp));
    c->Eip = p[0];
    c->Esp += 4;
}
static bool ValidServiceId(uint32_t sid) {
    const uint16_t dev = static_cast<uint16_t>(sid >> 16);
    // SSYNENG uses these known VxD IDs. Restricting the scan avoids treating DSP data as code.
    switch (dev) {
        case 0x0001: case 0x0003: case 0x0004: case 0x0005: case 0x0011:
        case 0x0017: case 0x002A: case 0x0040: case 0x0048: case 0x048B: case 0x044A:
            return true;
        default: return false;
    }
}

static LONG EmulateVmm(CONTEXT* c, uint16_t svcRaw) {
    const uint16_t svc = svcRaw & 0x7fff;
    switch (svc) {
    case 0x0000: // Get_VMM_Version
        c->Eax = 0x040A; // Win98-compatible 4.10-style version word
        c->Ecx = 0;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    case 0x0001: // Get_Cur_VM_Handle
    case 0x0003: // Get_Sys_VM_Handle
        c->Ebx = 1;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x0025: { // Create_Semaphore: initial count in ECX, handle in EAX
        LONG initial = static_cast<LONG>(c->Ecx);
        if (initial < 0) initial = 0;
        HANDLE h = CreateSemaphoreW(nullptr, initial, 0x7fffffff, nullptr);
        c->Eax = static_cast<DWORD>(reinterpret_cast<uintptr_t>(h));
        SetCarry(c, h == nullptr);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0026: { // Destroy_Semaphore: handle in EAX
        HANDLE h = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(c->Eax));
        BOOL ok = h ? CloseHandle(h) : TRUE;
        c->Eax = ok ? 1u : 0u;
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0027: { // Wait_Semaphore: handle EAX. ECX is VMM wait flags.
        HANDLE h = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(c->Eax));
        DWORD r = h ? WaitForSingleObject(h, INFINITE) : WAIT_FAILED;
        c->Eax = (r == WAIT_OBJECT_0) ? 1u : 0u;
        SetCarry(c, r != WAIT_OBJECT_0);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0028: { // Signal_Semaphore
        HANDLE h = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(c->Eax));
        BOOL ok = h ? ReleaseSemaphore(h, 1, nullptr) : FALSE;
        c->Eax = ok ? 1u : 0u;
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0131: { // Signal_Semaphore_No_Switch
        HANDLE h = reinterpret_cast<HANDLE>(static_cast<uintptr_t>(c->Eax));
        BOOL ok = h ? ReleaseSemaphore(h, 1, nullptr) : FALSE;
        c->Eax = ok ? 1u : 0u;
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    case 0x003A: // Call_When_Idle
        // Reality registers one housekeeping callback at 0x8FE70. In this build it
        // simply returns zero, so accepting the registration is equivalent for bring-up.
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    case 0x003C: { // Set_Global_Time_Out
        // At the INT20 boundary the VMM ABI supplies delay in EAX, callback
        // thunk in ESI and caller reference data in EDX. The wrapper later
        // copies ESI to EAX, so return our opaque timer handle through ESI.
        const DWORD delay = c->Eax ? c->Eax : 1u;
        const DWORD callback = c->Esi;
        const DWORD refData = c->Edx;
        if (!g_timerQueue || !callback || InterlockedCompareExchange(&g_timerShutdown, 0, 0) != 0) {
            c->Esi = 0;
            SetCarry(c, true);
            Logf("VMM Set_Global_Time_Out rejected callback=%08lX refData=%08lX delayMs=%lu shutdown=%ld",
                 callback, refData, delay, g_timerShutdown);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        auto* timeout = new (std::nothrow) HostTimeout();
        if (!timeout) {
            c->Esi = 0;
            SetCarry(c, true);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        timeout->callback = callback;
        timeout->refData = refData;
        timeout->delayMs = delay;
        const BOOL ok = CreateTimerQueueTimer(&timeout->timer, g_timerQueue,
            HostTimeoutCallback, timeout, delay, 0, WT_EXECUTEONLYONCE);
        if (!ok) {
            Logf("VMM Set_Global_Time_Out CreateTimerQueueTimer failed error=%lu", GetLastError());
            delete timeout;
            c->Esi = 0;
            SetCarry(c, true);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        const DWORD handle = static_cast<DWORD>(reinterpret_cast<uintptr_t>(timeout));
        EnterCriticalSection(&g_lock);
        g_timeouts[handle] = timeout;
        LeaveCriticalSection(&g_lock);
        const LONG sequence = InterlockedIncrement(&g_timeoutCreated);
        if (sequence <= 8 || (sequence % 256) == 0) {
            Logf("VMM Set_Global_Time_Out sequence=%ld handle=%p callback=%08lX refData=%08lX delayMs=%lu",
                 sequence, timeout, callback, refData, delay);
        }
        c->Esi = handle;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x003E: { // Cancel_Time_Out: opaque handle in ESI
        const DWORD handle = c->Esi;
        HostTimeout* timeout = nullptr;
        EnterCriticalSection(&g_lock);
        auto it = g_timeouts.find(handle);
        if (it != g_timeouts.end()) timeout = it->second;
        LeaveCriticalSection(&g_lock);
        BOOL ok = TRUE;
        if (timeout && InterlockedExchange(&timeout->cancelled, 1) == 0 && timeout->timer) {
            ok = DeleteTimerQueueTimer(g_timerQueue, timeout->timer, nullptr);
            if (!ok && GetLastError() == ERROR_IO_PENDING) ok = TRUE;
        }
        const LONG sequence = InterlockedIncrement(&g_timeoutCancelled);
        if (sequence <= 8 || (sequence % 256) == 0 || !timeout || !ok) {
            Logf("VMM Cancel_Time_Out sequence=%ld handle=%08lX known=%u -> %u error=%lu",
                 sequence, handle, timeout ? 1u : 0u, ok ? 1u : 0u, ok ? 0ul : GetLastError());
        }
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x003F: // Get_System_Time
        c->Eax = GetTickCount();
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x0108: { // Get_Cur_Thread_Handle
        // SSYNENG's wrapper at object1+B9B48 copies EDI to EAX after the VMM
        // call, so the legacy result register is EDI.  Previous builds wrote
        // only EAX and therefore stored a stale thread token for the later
        // VWIN32_QueueUserApc program/resource callback.
        const DWORD token = GetCurrentThreadId();
        c->Edi = token;
        c->Eax = token; // harmless convenience for inline callers
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    case 0x0144: // Get_System_Time_Address
        // Win9x optionally exposed a pointer to VMM's millisecond counter.  Returning
        // NULL is explicitly handled by SSYNENG: it falls back to Get_System_Time,
        // which is already backed by GetTickCount() above.
        c->Eax = 0;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x007A: { // _BuildDescriptorDWORDs (inline INT wrapper)
        const uint32_t base   = IntStackArg(c, 0);
        const uint32_t limit  = IntStackArg(c, 1);
        const uint32_t access = IntStackArg(c, 2);
        const uint32_t flags  = IntStackArg(c, 3);
        const FakeDescriptor d = MakeDescriptor(base, limit, access, flags);
        // The original helper returns the descriptor's low DWORD in EAX and high
        // DWORD in EDX.  SSYNENG subsequently passes EDX,EAX to Allocate_LDT.
        c->Eax = d.low;
        c->Edx = d.high;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0078: { // _Allocate_LDT_Selector (inline INT wrapper)
        // Stack order at INT20: VM, descriptor-high, descriptor-low, count, flags.
        const uint32_t high = IntStackArg(c, 1);
        const uint32_t low  = IntStackArg(c, 2);
        uint32_t count32 = IntStackArg(c, 3);
        if (!count32 || count32 > 0x100u) count32 = 1;
        FakeDescriptor d{low, high};
        const uint16_t sel = AllocateFakeSelectors(static_cast<uint16_t>(count32), d);
        c->Eax = sel;
        c->Edx = 0; // secondary VMM result is unused by Reality's one allocation caller
        SetCarry(c, sel == 0);
        Logf("VMM LDT: allocated selector=%04X count=%lu base=%08lX", sel, count32, DescriptorBase(d));
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x006E: { // _SelectorMapFlat (VMMJmp): VM, selector, flags
        const uint16_t sel = static_cast<uint16_t>(StackArg(c, 1));
        FakeDescriptor d{};
        if (LookupDescriptor(sel, d)) {
            c->Eax = DescriptorBase(d);
            SetCarry(c, false);
        } else {
            // A selector unknown to our synthetic LDT may still be one of NT's
            // ordinary flat user selectors.  Ask the OS before reporting failure.
            LDT_ENTRY e{};
            if (GetThreadSelectorEntry(GetCurrentThread(), sel, &e)) {
                c->Eax = static_cast<DWORD>(e.BaseLow)
                       | (static_cast<DWORD>(e.HighWord.Bytes.BaseMid) << 16)
                       | (static_cast<DWORD>(e.HighWord.Bytes.BaseHi) << 24);
                SetCarry(c, false);
            } else {
                c->Eax = 0xffffffffu;
                SetCarry(c, true);
            }
        }
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x007B: { // _GetDescriptor (inline INT): selector, VM, flags
        const uint16_t sel = static_cast<uint16_t>(IntStackArg(c, 0));
        FakeDescriptor d{};
        if (LookupDescriptor(sel, d)) {
            c->Eax = d.low;
            c->Edx = d.high;
            SetCarry(c, false);
        } else {
            c->Eax = 0;
            c->Edx = 0;
            SetCarry(c, true);
        }
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x007C: { // _SetDescriptor (VMMJmp): selector, VM, high, low, flags
        const uint16_t sel = static_cast<uint16_t>(StackArg(c, 0));
        FakeDescriptor d{};
        d.high = StackArg(c, 2);
        d.low  = StackArg(c, 3);
        StoreDescriptor(sel, d);
        c->Eax = 1;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0079: { // _Free_LDT_Selector (VMMJmp): VM, selector, flags
        const uint16_t sel = static_cast<uint16_t>(StackArg(c, 1));
        EnterCriticalSection(&g_lock);
        uint16_t count = 1;
        auto ai = g_selectorAllocCount.find(sel);
        if (ai != g_selectorAllocCount.end()) { count = ai->second; g_selectorAllocCount.erase(ai); }
        for (uint16_t i = 0; i < count; ++i) g_descriptors.erase(static_cast<uint16_t>(sel + i * 8u));
        LeaveCriticalSection(&g_lock);
        c->Eax = 1;
        SetCarry(c, false);
        Logf("VMM LDT: freed selector=%04X count=%u", sel, static_cast<unsigned>(count));
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    case 0x004F: { // _HeapAllocate (VMMJmp thunk): size, flags on caller stack
        SIZE_T n = StackArg(c, 0);
        void* p = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, n ? n : 1);
        c->Eax = static_cast<DWORD>(reinterpret_cast<uintptr_t>(p));
        SetCarry(c, p == nullptr);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0051: { // _HeapFree (VMMJmp thunk): pointer, flags
        void* p = reinterpret_cast<void*>(static_cast<uintptr_t>(StackArg(c, 0)));
        BOOL ok = !p || HeapFree(GetProcessHeap(), 0, p);
        c->Eax = ok ? 1u : 0u;
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0053: { // _PageAllocate. Wrapper has pushed 8 VMM args; arg0 is page count.
        auto* sp = reinterpret_cast<DWORD*>(static_cast<uintptr_t>(c->Esp));
        DWORD pages = sp ? sp[0] : 0;
        const DWORD pType = sp ? sp[1] : 0;
        const DWORD vm = sp ? sp[2] : 0;
        const DWORD alignMask = sp ? sp[3] : 0;
        const DWORD flags = sp ? sp[7] : 0;
        SIZE_T bytes = static_cast<SIZE_T>(pages ? pages : 1) * 4096u;
        void* p = VirtualAlloc(nullptr, bytes, MEM_RESERVE|MEM_COMMIT, PAGE_READWRITE);
        DWORD pv = static_cast<DWORD>(reinterpret_cast<uintptr_t>(p));
        // Real VMM returns an allocation handle in EAX and the ring-0 linear
        // address in EDX.  Keeping EAX==EDX is intentional for now because our
        // PageFree shim accepts the same process pointer; ECX is the allocation
        // byte count and EBX would be the physical address when requested.
        c->Eax = pv;
        c->Edx = pv;
        c->Ecx = static_cast<DWORD>(bytes);
        c->Ebx = 0;
        SetCarry(c, p == nullptr);
        Logf("VMM _PageAllocate pages=%lu bytes=%lu pType=%08lX vm=%08lX align=%08lX flags=%08lX -> handle=%08lX linear=%08lX",
             pages, static_cast<DWORD>(bytes), pType, vm, alignMask, flags, c->Eax, c->Edx);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0055: { // _PageFree (VMMJmp thunk)
        void* p = reinterpret_cast<void*>(static_cast<uintptr_t>(StackArg(c, 0)));
        BOOL ok = !p || VirtualFree(p, 0, MEM_RELEASE);
        c->Eax = ok ? 1u : 0u;
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x005A: { // _GetFreePageCount: return pages in EAX and largest run in EDX
        MEMORYSTATUSEX ms{}; ms.dwLength = sizeof(ms); GlobalMemoryStatusEx(&ms);
        uint64_t pages = ms.ullAvailPhys / 4096u;
        if (pages > 0xffffffffu) pages = 0xffffffffu;
        c->Eax = static_cast<DWORD>(pages);
        c->Edx = static_cast<DWORD>(pages);
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0063: // _LinPageLock
    case 0x0064: // _LinPageUnLock
    case 0x0067: // _PageCheckLinRange
        c->Eax = 1;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x0081: { // Hook_VMM_Fault
        // SSYNENG installs Win9x ring-0 fault hooks for #7/#0E and one private
        // fault vector.  NT user mode cannot install those VMM hooks, but the
        // recovered callers treat only EAX==0xFFFFFFFF as failure.  The guarded
        // user-mode engine paths already replace the privileged fault handlers,
        // so acknowledge registration with an opaque success value.
        const DWORD a0 = IntStackArg(c, 0);
        const DWORD a1 = IntStackArg(c, 1);
        const DWORD a2 = IntStackArg(c, 2);
        c->Eax = 0;
        SetCarry(c, false);
        Logf("VMM Hook_VMM_Fault compatibility no-op success args=%08lX,%08lX,%08lX", a0, a1, a2);
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    case 0x0082: // Begin_Nest_V86_Exec
    case 0x0083: // Begin_Nest_Exec
    case 0x0085: // Resume_Exec
    case 0x0086: // End_Nest_Exec
    case 0x008B: // Begin_Use_Locked_PM_Stack
    case 0x008C: // End_Use_Locked_PM_Stack
    case 0x008D: // Save_Client_State (EDI -> Client_Reg_Struc)
    case 0x008E: // Restore_Client_State (ESI -> Client_Reg_Struc)
        // Ring-3 process execution is already on an NT-managed protected-mode
        // stack and nested VM execution is a no-op in the rehost. Keep the
        // matching save/restore calls as successful no-ops too; v13.6.1 was
        // incorrectly returning the generic unknown-service failure here.
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x009B: { // List_Create: EAX flags, ECX node bytes; result ESI
        auto* list = new (std::nothrow) HostList();
        if (list) list->nodeSize = c->Ecx ? c->Ecx : 1;
        c->Esi = static_cast<DWORD>(reinterpret_cast<uintptr_t>(list));
        SetCarry(c, list == nullptr);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x009C: { // List_Destroy: ESI list
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        if (list) {
            for (void* n : list->nodes) HeapFree(GetProcessHeap(), 0, n);
            delete list;
        }
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x009D: { // List_Allocate: ESI list; result EAX
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* n = list ? HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, list->nodeSize) : nullptr;
        c->Eax = static_cast<DWORD>(reinterpret_cast<uintptr_t>(n));
        SetCarry(c, n == nullptr);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x009E: { // List_Attach: ESI list, EAX node
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* n = reinterpret_cast<void*>(static_cast<uintptr_t>(c->Eax));
        if (list && n && std::find(list->nodes.begin(), list->nodes.end(), n) == list->nodes.end()) list->nodes.push_back(n);
        SetCarry(c, !(list && n));
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x009F: { // List_Attach_Tail
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* n = reinterpret_cast<void*>(static_cast<uintptr_t>(c->Eax));
        if (list && n && std::find(list->nodes.begin(), list->nodes.end(), n) == list->nodes.end()) list->nodes.push_back(n);
        SetCarry(c, !(list && n));
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x00A1: { // List_Remove: ESI list, EAX node
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* n = reinterpret_cast<void*>(static_cast<uintptr_t>(c->Eax));
        bool ok = false;
        if (list) {
            auto it = std::find(list->nodes.begin(), list->nodes.end(), n);
            if (it != list->nodes.end()) { list->nodes.erase(it); ok = true; }
        }
        SetCarry(c, !ok);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x00A2: { // List_Deallocate: ESI list, EAX node
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* n = reinterpret_cast<void*>(static_cast<uintptr_t>(c->Eax));
        if (list && n) {
            auto it = std::find(list->nodes.begin(), list->nodes.end(), n);
            if (it != list->nodes.end()) list->nodes.erase(it);
            HeapFree(GetProcessHeap(), 0, n);
        }
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x00A3: { // List_Get_First: ESI list -> EAX
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        c->Eax = (list && !list->nodes.empty()) ? static_cast<DWORD>(reinterpret_cast<uintptr_t>(list->nodes.front())) : 0;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x00A4: { // List_Get_Next: ESI list, EAX current -> EAX next
        auto* list = reinterpret_cast<HostList*>(static_cast<uintptr_t>(c->Esi));
        void* cur = reinterpret_cast<void*>(static_cast<uintptr_t>(c->Eax));
        void* next = nullptr;
        if (list) {
            auto it = std::find(list->nodes.begin(), list->nodes.end(), cur);
            if (it != list->nodes.end() && ++it != list->nodes.end()) next = *it;
        }
        c->Eax = static_cast<DWORD>(reinterpret_cast<uintptr_t>(next));
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }

    // Win9x VMM registry services. SSYNENG uses these during 0x9001 startup to
    // read SOFTWARE\\Seer Systems, Inc.\\SynthEngine\ and related values.
    // The VMM stack ABI matches the legacy Win32 Reg* argument order.
    case 0x012B: // Cancel_Call_When_Idle
        // Paired with Reality's single no-op idle callback registration above.
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;

    case 0x0148: { // RegOpenKey
        HKEY root = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR sub = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        PHKEY out = reinterpret_cast<PHKEY>(static_cast<uintptr_t>(StackArg(c, 2)));
        const std::string path = JoinRegistryPath(root, sub);
        LSTATUS r = ERROR_INVALID_PARAMETER;
        if (out && IsSeerEngineRegistryPath(path)) {
            *out = CreateVirtualRegistryKey(path);
            r = *out ? ERROR_SUCCESS : ERROR_NOT_ENOUGH_MEMORY;
            Logf("VMM VirtualRegistry: RegOpenKey path=%s -> %ld fake=%p (no registry write)",
                 path.c_str(), r, out ? *out : nullptr);
        } else {
            r = RegOpenKeyA(root, sub, out);
            Logf("VMM RegistryTrace: RegOpenKey path=%s -> %ld handle=%p",
                 path.c_str(), r, out ? *out : nullptr);
        }
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0149: { // RegCloseKey
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        const bool fake = CloseVirtualRegistryKey(key);
        LSTATUS r = fake ? ERROR_SUCCESS : RegCloseKey(key);
        Logf("VMM %s: RegCloseKey key=%p -> %ld", fake ? "VirtualRegistry" : "RegistryTrace", key, r);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014A: { // RegCreateKey
        HKEY root = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR sub = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        PHKEY out = reinterpret_cast<PHKEY>(static_cast<uintptr_t>(StackArg(c, 2)));
        const std::string path = JoinRegistryPath(root, sub);
        LSTATUS r = ERROR_INVALID_PARAMETER;
        if (out) {
            *out = CreateVirtualRegistryKey(path);
            r = *out ? ERROR_SUCCESS : ERROR_NOT_ENOUGH_MEMORY;
        }
        Logf("VMM VirtualRegistry: RegCreateKey path=%s -> %ld fake=%p (suppressed real registry create)",
             path.c_str(), r, out ? *out : nullptr);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014B: { // RegDeleteKey
        HKEY root = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR sub = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        const std::string path = JoinRegistryPath(root, sub);
        LSTATUS r = ERROR_SUCCESS;
        Logf("VMM VirtualRegistry: RegDeleteKey path=%s -> success (suppressed real registry delete)",
             path.c_str());
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014C: { // RegEnumKey
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        DWORD index = StackArg(c, 1);
        LPSTR name = reinterpret_cast<LPSTR>(static_cast<uintptr_t>(StackArg(c, 2)));
        DWORD chars = StackArg(c, 3);
        std::string path;
        const bool fake = LookupVirtualRegistryPath(key, path);
        LSTATUS r = fake ? ERROR_NO_MORE_ITEMS : RegEnumKeyA(key, index, name, chars);
        Logf("VMM %s: RegEnumKey key=%p index=%lu -> %ld",
             fake ? "VirtualRegistry" : "RegistryTrace", key, index, r);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014D: { // RegQueryValue
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR sub = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        LPSTR data = reinterpret_cast<LPSTR>(static_cast<uintptr_t>(StackArg(c, 2)));
        PLONG bytes = reinterpret_cast<PLONG>(static_cast<uintptr_t>(StackArg(c, 3)));
        std::string path;
        const bool fake = LookupVirtualRegistryPath(key, path);
        LSTATUS r = ERROR_FILE_NOT_FOUND;
        if (fake && sub && _stricmp(sub, "Version") == 0) {
            DWORD cb = bytes && *bytes > 0 ? static_cast<DWORD>(*bytes) : 0;
            r = CopyVmmRegistryString("1.5.5", nullptr, reinterpret_cast<LPBYTE>(data), bytes ? &cb : nullptr);
            if (bytes) *bytes = static_cast<LONG>(cb);
        } else if (!fake) {
            r = RegQueryValueA(key, sub, data, bytes);
        }
        Logf("VMM %s: RegQueryValue key=%p path=%s sub=%s -> %ld bytes=%ld",
             fake ? "VirtualRegistry" : "RegistryTrace", key,
             fake ? path.c_str() : "(real)", sub ? sub : "(default)", r,
             bytes ? *bytes : 0l);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014E: { // RegSetValue
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR sub = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        DWORD type = StackArg(c, 2);
        LPCSTR data = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 3)));
        DWORD bytes = StackArg(c, 4);
        LSTATUS r = ERROR_SUCCESS;
        Logf("VMM VirtualRegistry: RegSetValue key=%p sub=%s type=%lu bytes=%lu -> success (suppressed real registry write)",
             key, sub ? sub : "(default)", type, bytes);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x014F: { // RegDeleteValue
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR name = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        LSTATUS r = ERROR_SUCCESS;
        Logf("VMM VirtualRegistry: RegDeleteValue key=%p value=%s -> success (suppressed real registry delete)",
             key, name ? name : "(default)");
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0150: { // RegEnumValue
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        DWORD index = StackArg(c, 1);
        LPSTR value = reinterpret_cast<LPSTR>(static_cast<uintptr_t>(StackArg(c, 2)));
        LPDWORD valueChars = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 3)));
        LPDWORD reserved = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 4)));
        LPDWORD type = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 5)));
        LPBYTE data = reinterpret_cast<LPBYTE>(static_cast<uintptr_t>(StackArg(c, 6)));
        LPDWORD dataBytes = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 7)));
        std::string path;
        const bool fake = LookupVirtualRegistryPath(key, path);
        LSTATUS r = fake ? ERROR_NO_MORE_ITEMS :
            RegEnumValueA(key, index, value, valueChars, reserved, type, data, dataBytes);
        Logf("VMM %s: RegEnumValue key=%p index=%lu -> %ld",
             fake ? "VirtualRegistry" : "RegistryTrace", key, index, r);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0151: { // RegQueryValueEx
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR name = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        LPDWORD reserved = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 2)));
        LPDWORD type = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 3)));
        LPBYTE data = reinterpret_cast<LPBYTE>(static_cast<uintptr_t>(StackArg(c, 4)));
        LPDWORD dataBytes = reinterpret_cast<LPDWORD>(static_cast<uintptr_t>(StackArg(c, 5)));
        std::string path;
        const bool fake = LookupVirtualRegistryPath(key, path);
        LSTATUS r = ERROR_FILE_NOT_FOUND;
        if (fake && name && _stricmp(name, "Version") == 0) {
            r = CopyVmmRegistryString("1.5.5", type, data, dataBytes);
        } else if (!fake) {
            r = RegQueryValueExA(key, name, reserved, type, data, dataBytes);
        }
        Logf("VMM %s: RegQueryValueEx key=%p path=%s value=%s -> %ld type=%lu bytes=%lu",
             fake ? "VirtualRegistry" : "RegistryTrace", key,
             fake ? path.c_str() : "(real)", name ? name : "(default)", r,
             type ? *type : 0ul, dataBytes ? *dataBytes : 0ul);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0152: { // RegSetValueEx
        HKEY key = reinterpret_cast<HKEY>(static_cast<uintptr_t>(StackArg(c, 0)));
        LPCSTR name = reinterpret_cast<LPCSTR>(static_cast<uintptr_t>(StackArg(c, 1)));
        DWORD reserved = StackArg(c, 2);
        DWORD type = StackArg(c, 3);
        const BYTE* data = reinterpret_cast<const BYTE*>(static_cast<uintptr_t>(StackArg(c, 4)));
        DWORD dataBytes = StackArg(c, 5);
        LSTATUS r = ERROR_SUCCESS;
        Logf("VMM VirtualRegistry: RegSetValueEx key=%p value=%s type=%lu bytes=%lu -> success (suppressed real registry write)",
             key, name ? name : "(default)", type, dataBytes);
        c->Eax = static_cast<DWORD>(r); SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    default:
        return EXCEPTION_CONTINUE_SEARCH;
    }
}

static LONG EmulateVtd(CONTEXT* c, uint16_t svcRaw) {
    const uint16_t svc = svcRaw & 0x7fff;
    switch (svc) {
    case 0x0007: { // VTD_Get_Real_Time: EDX:EAX in 1,193,182-Hz timer ticks
        LARGE_INTEGER qpc{}, freq{};
        if (!QueryPerformanceCounter(&qpc) || !QueryPerformanceFrequency(&freq) || freq.QuadPart <= 0) {
            const uint64_t ticks = (static_cast<uint64_t>(GetTickCount()) * 1193182ull) / 1000ull;
            c->Eax = static_cast<DWORD>(ticks);
            c->Edx = static_cast<DWORD>(ticks >> 32);
        } else {
            const uint64_t q = static_cast<uint64_t>(qpc.QuadPart);
            const uint64_t f = static_cast<uint64_t>(freq.QuadPart);
            // Quotient/remainder form avoids overflowing q*1193182 on long uptimes.
            const uint64_t ticks = (q / f) * 1193182ull + ((q % f) * 1193182ull) / f;
            c->Eax = static_cast<DWORD>(ticks);
            c->Edx = static_cast<DWORD>(ticks >> 32);
        }
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    default:
        return EXCEPTION_CONTINUE_SEARCH;
    }
}

static LONG EmulatePerf(CONTEXT* c, uint16_t svcRaw) {
    const uint16_t svc = svcRaw & 0x7fff;
    switch (svc) {
    case 0x0000: // PERF_Get_Version / availability probe
        // PERF.VXD is an optional Win9x profiling helper, not part of synthesis.
        // Returning zero tells SSYNENG not to install its profiling callbacks.
        c->Eax = 0;
        SetCarry(c, false);
        Logf("PERF.VXD compatibility: optional profiler reported unavailable");
        return EXCEPTION_CONTINUE_EXECUTION;
    case 0x0001:
    case 0x0002:
    case 0x0003:
    case 0x0004:
        // Defensive no-ops if a later build reaches these despite service 0=0.
        c->Eax = 0;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    default:
        return EXCEPTION_CONTINUE_SEARCH;
    }
}

static LONG EmulateVwin32(CONTEXT* c, uint16_t svcRaw) {
    const uint16_t svc = svcRaw & 0x7fff;
    switch (svc) {
    case 0x0002: { // _VWIN32_QueueUserApc(pR3Proc, Param, hThread)
        // B9F2C is a VxDCall tail thunk. ESP therefore still points at the
        // CALL return address and StackArg() exposes the three pushed arguments.
        const DWORD proc = StackArg(c, 0);
        const DWORD param = StackArg(c, 1);
        const DWORD threadToken = StackArg(c, 2);
        static volatile LONG requestCount = 0;
        const LONG request = InterlockedIncrement(&requestCount);
        if (request <= 16 || (request % 128) == 0) {
            Logf("VWIN32 QueueUserApc request #%ld proc=%08lX param=%08lX threadToken=%lu callerTid=%lu esp=%08lX",
                 request, proc, param, threadToken, GetCurrentThreadId(), c->Esp);
        }
        const bool queued = QueueVwin32UserApc(proc, param, threadToken);
        // The original VWIN32 service is VOID. Avoid inventing a carry failure
        // that the legacy caller never consumed; EAX is diagnostic only.
        c->Eax = queued ? 1u : 0u;
        SetCarry(c, false);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    case 0x0013: { // _VWIN32_CreateRing0Thread
        // Recovered wrapper ABI: ECX=stack bytes, EDX=thread reference data,
        // EBX=entry point, ESI=legacy flags; EAX returns the thread handle and
        // EDX the thread id. The original entry is a cdecl routine taking the
        // reference-data pointer, so a WINAPI host thunk bridges CreateThread.
        auto* worker = new (std::nothrow) HostRingThread();
        if (!worker) {
            c->Eax = 0; c->Edx = 0; SetCarry(c, true);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        worker->entry = c->Ebx;
        worker->refData = c->Edx;
        const SIZE_T stackBytes = c->Ecx ? static_cast<SIZE_T>(c->Ecx) : 0;
        worker->thread = CreateThread(nullptr, stackBytes, HostRingThreadStart,
                                      worker, 0, &worker->threadId);
        if (!worker->thread) {
            const DWORD error = GetLastError();
            Logf("VWIN32 _CreateRing0Thread failed entry=%08lX refData=%08lX stack=%lu flags=%08lX error=%lu",
                 worker->entry, worker->refData, c->Ecx, c->Esi, error);
            delete worker;
            c->Eax = 0; c->Edx = 0; SetCarry(c, true);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        EnterCriticalSection(&g_lock);
        g_ringThreads.push_back(worker);
        LeaveCriticalSection(&g_lock);
        c->Eax = static_cast<DWORD>(reinterpret_cast<uintptr_t>(worker->thread));
        c->Edx = worker->threadId;
        SetCarry(c, false);
        Logf("VWIN32 _CreateRing0Thread -> handle=%p threadId=%lu entry=%08lX refData=%08lX stack=%lu flags=%08lX",
             worker->thread, worker->threadId, worker->entry, worker->refData, c->Ecx, c->Esi);
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    default:
        return EXCEPTION_CONTINUE_SEARCH;
    }
}

static LONG CALLBACK BridgeVeh(EXCEPTION_POINTERS* ep) {
    if (!ep || ep->ExceptionRecord->ExceptionCode != EXCEPTION_BREAKPOINT || !ep->ContextRecord) return EXCEPTION_CONTINUE_SEARCH;
    auto* site = reinterpret_cast<uint8_t*>(ep->ExceptionRecord->ExceptionAddress);
    if (!InRange(site) || site[0] != 0xCC || site[1] != 0x20) return EXCEPTION_CONTINUE_SEARCH;
    uint32_t sid = 0; std::memcpy(&sid, site+2, 4);
    if (!ValidServiceId(sid)) return EXCEPTION_CONTINUE_SEARCH;

    CONTEXT* c = ep->ContextRecord;
    uint16_t dev = static_cast<uint16_t>(sid >> 16);
    uint16_t svcRaw = static_cast<uint16_t>(sid);
    LONG handled = EXCEPTION_CONTINUE_SEARCH;
    if (dev == 0x0001) handled = EmulateVmm(c, svcRaw);
    else if (dev == 0x0005) handled = EmulateVtd(c, svcRaw);
    else if (dev == 0x002A) handled = EmulateVwin32(c, svcRaw);
    else if (dev == 0x0048) handled = EmulatePerf(c, svcRaw);

    if (handled == EXCEPTION_CONTINUE_SEARCH) {
        EnterCriticalSection(&g_lock);
        if (g_unknownLogged.insert(sid).second) Logf("VMM bridge unimplemented service id=%08X site=%p", sid, site);
        LeaveCriticalSection(&g_lock);
        // Conservative compatibility result: report failure through EAX/CF but keep tracing alive.
        c->Eax = 0;
        SetCarry(c, true);
    }

    if (svcRaw & 0x8000) TailReturn(c);  // VMMJmp/VxDCall tail thunk
    else c->Eip = static_cast<DWORD>(reinterpret_cast<uintptr_t>(site + 6));
    return EXCEPTION_CONTINUE_EXECUTION;
}
}

bool InstallVmmBridge(uint8_t* object1Base, uint32_t object1Size) {
    if (!object1Base || object1Size < 0x1000 || g_veh) return false;
    g_base = object1Base; g_size = object1Size;
    InitializeCriticalSection(&g_lock); g_lockInit = true;
    InterlockedExchange(&g_timerShutdown, 0);
    InterlockedExchange(&g_userApcQueued, 0);
    InterlockedExchange(&g_userApcDelivered, 0);
    InterlockedExchange(&g_userApcPostFailures, 0);
    g_userApcMessage = RegisterWindowMessageW(L"RealityCompat.SSYNENG.VWIN32.UserAPC.v13.8");
    if (!g_userApcMessage)
        Logf("VMM bridge: RegisterWindowMessage for VWIN32 QueueUserApc failed error=%lu", GetLastError());
    else
        Logf("VWIN32 QueueUserApc carrier message=%04X", g_userApcMessage);
    g_timerQueue = CreateTimerQueue();
    if (!g_timerQueue) {
        Logf("VMM bridge: CreateTimerQueue failed error=%lu", GetLastError());
        DeleteCriticalSection(&g_lock); g_lockInit=false; g_base=nullptr; g_size=0;
        return false;
    }
    g_veh = AddVectoredExceptionHandler(1, BridgeVeh);
    if (!g_veh) {
        DeleteTimerQueueEx(g_timerQueue, INVALID_HANDLE_VALUE); g_timerQueue=nullptr;
        DeleteCriticalSection(&g_lock); g_lockInit=false; g_base=nullptr; g_size=0; return false;
    }

    // Patch only syntactically valid SSYNENG service IDs. This finds the concentrated
    // thunk bank plus the inline Begin/Resume/End_Nest_Exec sequences.
    for (uint32_t i=0; i+6<=object1Size; ++i) {
        if (object1Base[i] != 0xCD || object1Base[i+1] != 0x20) continue;
        uint32_t sid=0; std::memcpy(&sid, object1Base+i+2, 4);
        if (!ValidServiceId(sid)) continue;
        object1Base[i] = 0xCC;
        g_sites.push_back(i);
    }
    FlushInstructionCache(GetCurrentProcess(), object1Base, object1Size);
    Logf("armed SSYNENG VMM bridge: %u INT20 sites; Win32 global-timeout scheduler ready", static_cast<unsigned>(g_sites.size()));
    return !g_sites.empty();
}


bool CreateLegacyFarPointer(void* flatBase, uint32_t bytes, uint32_t* farPointer) {
    if (!flatBase || !farPointer || !g_lockInit) return false;
    const uintptr_t raw = reinterpret_cast<uintptr_t>(flatBase);
    if (raw > 0xffffffffu) return false;
    const uint32_t limit = bytes ? bytes - 1u : 0u;
    // Access/flag bits are not consumed by our _SelectorMapFlat emulation, but
    // keep a conventional present ring-3 read/write data descriptor shape.
    const FakeDescriptor d = MakeDescriptor(static_cast<uint32_t>(raw), limit, 0xF2u, 0x40u);
    const uint16_t sel = AllocateFakeSelectors(1, d);
    if (!sel) return false;
    *farPointer = static_cast<uint32_t>(sel) << 16;
    Logf("VMM LDT: host far pointer flat=%p bytes=%lu selector=%04X far=%08lX",
         flatBase, static_cast<unsigned long>(bytes), sel, static_cast<unsigned long>(*farPointer));
    return true;
}

void DestroyLegacyFarPointer(uint32_t farPointer) {
    if (!g_lockInit || !farPointer) return;
    const uint16_t sel = static_cast<uint16_t>(farPointer >> 16);
    EnterCriticalSection(&g_lock);
    uint16_t count = 1;
    auto ai = g_selectorAllocCount.find(sel);
    if (ai != g_selectorAllocCount.end()) { count = ai->second; g_selectorAllocCount.erase(ai); }
    for (uint16_t i = 0; i < count; ++i)
        g_descriptors.erase(static_cast<uint16_t>(sel + i * 8u));
    LeaveCriticalSection(&g_lock);
    Logf("VMM LDT: host far pointer released selector=%04X count=%u", sel, static_cast<unsigned>(count));
}

void UninstallVmmBridge() {
    InterlockedExchange(&g_timerShutdown, 1);
    if (g_timerQueue) {
        EnterCriticalSection(&g_lock);
        for (const auto& entry : g_timeouts)
            InterlockedExchange(&entry.second->cancelled, 1);
        LeaveCriticalSection(&g_lock);
        DeleteTimerQueueEx(g_timerQueue, INVALID_HANDLE_VALUE);
        g_timerQueue = nullptr;
        for (const auto& entry : g_timeouts) delete entry.second;
        g_timeouts.clear();
    }
    // Stop Ring-3 APC delivery before releasing any rehosted callback code.
    std::vector<HHOOK> userApcHooks;
    EnterCriticalSection(&g_lock);
    for (const auto& entry : g_userApcHooks) if (entry.second) userApcHooks.push_back(entry.second);
    g_userApcHooks.clear();
    g_userApcQueues.clear();
    LeaveCriticalSection(&g_lock);
    for (HHOOK hook : userApcHooks) UnhookWindowsHookEx(hook);
    if (g_userApcQueued || g_userApcDelivered || g_userApcPostFailures) {
        Logf("VWIN32 QueueUserApc shutdown queued=%ld delivered=%ld postFailures=%ld",
             g_userApcQueued, g_userApcDelivered, g_userApcPostFailures);
    }
    g_userApcMessage = 0;

    // The original engine normally signals its worker during shutdown. Do not
    // release the rehost image while a failed legacy cleanup leaves that worker
    // executing inside it.
    for (HostRingThread* worker : g_ringThreads) {
        if (!worker) continue;
        if (worker->thread) {
            const DWORD wait = WaitForSingleObject(worker->thread, 2000);
            if (wait == WAIT_TIMEOUT) {
                Logf("VWIN32 ring-0 worker did not stop during engine shutdown; terminating compatibility worker threadId=%lu",
                     worker->threadId);
                TerminateThread(worker->thread, ERROR_OPERATION_ABORTED);
                WaitForSingleObject(worker->thread, 1000);
            }
            CloseHandle(worker->thread);
        }
        delete worker;
    }
    g_ringThreads.clear();
    if (g_base) {
        for (uint32_t i : g_sites) if (i < g_size && g_base[i] == 0xCC && g_base[i+1] == 0x20) g_base[i] = 0xCD;
        FlushInstructionCache(GetCurrentProcess(), g_base, g_size);
    }
    g_sites.clear(); g_unknownLogged.clear();
    g_descriptors.clear(); g_selectorAllocCount.clear(); g_nextSelector = 0x2007;
    for (const auto& entry : g_virtualRegistryKeys)
        CloseHandle(reinterpret_cast<HANDLE>(entry.first));
    g_virtualRegistryKeys.clear();
    if (g_veh) RemoveVectoredExceptionHandler(g_veh);
    g_veh=nullptr; g_base=nullptr; g_size=0;
    if (g_lockInit) { DeleteCriticalSection(&g_lock); g_lockInit=false; }
}
} // namespace reality
