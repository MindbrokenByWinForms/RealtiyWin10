#include "voice_trace.h"
#include "log.h"
#include <cstring>

namespace reality {
namespace {
struct Site { uint32_t off; uint8_t len, kind, cond; uint32_t arg;
    uint8_t expected[8], mask[8]; };
static const Site sites[] = {
#include "voice_trace_sites.inc"
};
uint8_t* base = nullptr;
PVOID handler = nullptr;
volatile LONG sequence = 0;
thread_local DWORD noteId = 0, channel = 0, message = 0;
thread_local unsigned lines = 0;

// ReadProcessMemory returns failure for stale pointers without introducing an
// access violation inside the exception handler. A zero value with ok=0 is not
// evidence that a field in the target was zero.
uint32_t Read(uint32_t p, unsigned n=4, bool* ok=nullptr) {
    uint32_t v=0; SIZE_T done=0;
    bool good = p && p != 0xffffffffu &&
        ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<void*>(static_cast<uintptr_t>(p)),
                          &v,n,&done) && done==n;
    if(ok) *ok=good;
    return good ? v : 0;
}
void LogLayerRegion(DWORD id, const char* stage, uint32_t layer) {
    MEMORY_BASIC_INFORMATION mbi{};
    const SIZE_T queried = layer ? VirtualQuery(reinterpret_cast<void*>(static_cast<uintptr_t>(layer)), &mbi, sizeof(mbi)) : 0;
    bool o630=false,o634=false,o638=false,o63c=false,o640=false,o644=false;
    const uint32_t f630=Read(layer+0x630,4,&o630);
    const uint32_t f634=Read(layer+0x634,4,&o634);
    const uint32_t f638=Read(layer+0x638,4,&o638);
    const uint32_t f63c=Read(layer+0x63c,4,&o63c);
    const uint32_t f640=Read(layer+0x640,4,&o640);
    const uint32_t f644=Read(layer+0x644,4,&o644);
    bool span800 = false;
    if (queried && mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) {
        const uintptr_t regionStart = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
        const uintptr_t regionEnd = regionStart + mbi.RegionSize;
        span800 = static_cast<uintptr_t>(layer) >= regionStart && static_cast<uintptr_t>(layer) + 0x800u <= regionEnd;
    }
    Logf("VOICEPATH layer-region id=%lu stage=%s ptr=%08lX query=%u span800=%u base=%p alloc=%p region=%lu state=%08lX protect=%08lX type=%08lX fields630/634/638/63C/640/644=%08lX/%08lX/%08lX/%08lX/%08lX/%08lX reads=%u%u%u%u%u%u",
         id, stage ? stage : "(none)", static_cast<unsigned long>(layer), queried ? 1u : 0u, span800 ? 1u : 0u,
         queried ? mbi.BaseAddress : nullptr, queried ? mbi.AllocationBase : nullptr,
         queried ? static_cast<unsigned long>(mbi.RegionSize) : 0ul,
         queried ? static_cast<unsigned long>(mbi.State) : 0ul,
         queried ? static_cast<unsigned long>(mbi.Protect) : 0ul,
         queried ? static_cast<unsigned long>(mbi.Type) : 0ul,
         f630,f634,f638,f63c,f640,f644,
         o630?1:0,o634?1:0,o638?1:0,o63c?1:0,o640?1:0,o644?1:0);
}
bool Taken(unsigned cc, DWORD flags) {
    const bool c=flags&1, p=flags&4, z=flags&64, s=flags&128, o=flags&2048;
    switch(cc) {
    case 0:return o; case 1:return !o; case 2:return c; case 3:return !c;
    case 4:return z; case 5:return !z; case 6:return c||z; case 7:return !c&&!z;
    case 8:return s; case 9:return !s; case 10:return p; case 11:return !p;
    case 12:return s!=o; case 13:return s==o; case 14:return z||s!=o;
    default:return !z&&s==o;
    }
}
bool Push(CONTEXT* c, uint32_t value) {
    SIZE_T done=0;
    if(!WriteProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(static_cast<uintptr_t>(c->Esp-4)),
                           &value,4,&done) || done!=4) return false;
    c->Esp-=4; return true;
}
LONG CALLBACK Trace(EXCEPTION_POINTERS* ep) {
    if(!base) return EXCEPTION_CONTINUE_SEARCH;
    if(ep->ExceptionRecord->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && noteId && noteId<=32) {
        const auto* er=ep->ExceptionRecord;
        Logf("VOICEFAULT id=%lu pc=%p code=%08lX operation=%lu address=%08lX",noteId,er->ExceptionAddress,er->ExceptionCode,
             er->NumberParameters>0?static_cast<DWORD>(er->ExceptionInformation[0]):0,
             er->NumberParameters>1?static_cast<DWORD>(er->ExceptionInformation[1]):0);
        noteId=0;
    }
    if(ep->ExceptionRecord->ExceptionCode!=EXCEPTION_BREAKPOINT) return EXCEPTION_CONTINUE_SEARCH;
    const uintptr_t addr=reinterpret_cast<uintptr_t>(ep->ExceptionRecord->ExceptionAddress);
    const uintptr_t b=reinterpret_cast<uintptr_t>(base);
    if(addr<b || addr-b>0xba080) return EXCEPTION_CONTINUE_SEARCH;
    const Site* site=nullptr;
    for(const auto& x:sites) if(x.off==addr-b) { site=&x;break; }
    if(!site) return EXCEPTION_CONTINUE_SEARCH;
    const DWORD lastError=GetLastError();
    CONTEXT* c=ep->ContextRecord;
    const auto& x=*site;
    if(x.off==0xa4bd0) {
        noteId=static_cast<DWORD>(InterlockedIncrement(&sequence)); lines=0;
        message=Read(c->Esp+4); channel=Read(c->Esp+8);
    }
    uint32_t next=static_cast<uint32_t>(addr+x.len);
    if(x.kind==1 && Taken(x.cond,c->EFlags)) next=static_cast<uint32_t>(b+x.arg);
    if(noteId && noteId<=32 && lines++<512) {
        const uint32_t record=Read(channel+6), root=Read(record+4);
        bool modelOk=false;
        const uint32_t model=Read(root+0xec,4,&modelOk);
        const uint32_t engine=Read(static_cast<uint32_t>(b+0x2a5c4));
        bool idOk=false, layersOk=false, tableOk=false;
        const uint32_t modelId=Read(model+4,4,&idOk);
        const uint32_t layerCount=Read(model+0xa,2,&layersOk), layerTable=Read(model+0x10,4,&tableOk);
        const uint32_t ctor=modelId<30 ? Read(static_cast<uint32_t>(b+0x3bdbc+modelId*4)):0;
        Logf("VOICEPATH id=%lu tid=%lu pc=%05X next=%05X msg=%08X ch=%08X chGate=%u rec=%08X ready=%u root=%08X type=%u modelRead=%u model=%08X modelId=%u layers=%u layerTable=%08X fieldReads=%u%u%u ctor=%08X head=%08X EAX=%08lX EBX=%08lX ECX=%08lX EDX=%08lX ESI=%08lX EDI=%08lX flags=%08lX",
             noteId,GetCurrentThreadId(),x.off,next-static_cast<uint32_t>(b),message,channel,Read(channel+0x7a2,2),record,Read(record+0x10,1),root,Read(root+4,2),modelOk?1:0,model,modelId,layerCount,layerTable,idOk?1:0,layersOk?1:0,tableOk?1:0,ctor,Read(engine+0x230),c->Eax,c->Ebx,c->Ecx,c->Edx,c->Esi,c->Edi,c->EFlags);
        if(x.off==0x8bc40) {
            const uint32_t lo=Read(static_cast<uint32_t>(b+0x3c06c)), hi=Read(static_cast<uint32_t>(b+0x3c070));
            unsigned freeSlots=0, count=0;
            if(lo && hi>=lo && hi-lo<0x200000u)
                for(uint32_t v=lo;v<=hi;v+=0x2cf0) { ++count;if(Read(v+8,1)==0 && Read(v+0x30)==0xffffffffu)++freeSlots; }
            Logf("VOICEPOOL id=%lu first=%08X last=%08X slots=%u free=%u cpuLoad=%u cpuLimit=%u voiceLimit=%u costDivisor=%u",noteId,lo,hi,count,freeSlots,Read(engine+0x264),Read(engine+0x244,2),Read(engine+0x248,2),Read(static_cast<uint32_t>(b+0x3f2dc)));
        }
        if(x.off>=0x6e768 && x.off<=0x6e781)
            Logf("VOICEPATH velocity id=%lu slot=%lu layer=%08lX zone=%08lX enabled=%u low=%u high=%u excluded=%u velocity=%u",noteId,c->Ecx,c->Esi,c->Eax,Read(c->Eax,1),Read(c->Eax+1,1),Read(c->Eax+2,1),Read(c->Eax+0xf9,1),c->Edx&65535);
        if(x.off==0xa4929 || x.off==0xa4933) { // key-range comparisons; EAX is selected layer
            Logf("VOICEPATH layer id=%lu ptr=%08lX low=%u high=%u note=%u",noteId,c->Eax,Read(c->Eax+8,1),Read(c->Eax+9,1),c->Esi&65535);
            if(x.off==0xa4929) LogLayerRegion(noteId,"key-selected",c->Eax);
        }
        if(x.off==0x884a0) { // generic runtime-voice allocator; arg2 is the selected layer
            bool layerOk=false;
            const uint32_t layer=Read(c->Esp+8,4,&layerOk);
            Logf("VOICEPATH allocator-layer id=%lu ptr=%08lX read=%u",noteId,layer,layerOk?1u:0u);
            if(layerOk) LogLayerRegion(noteId,"allocator-entry",layer);
        }
    }
    // Emulate only the generated control-flow instructions and entry PUSH EBP.
    // Original flags and floating-point/SIMD state stay in the OS CONTEXT.
    // No trap flag, temporary unpatching, or executable trampoline is needed.
    if(x.kind==2) {
        bool ok=false;next=Read(c->Esp,4,&ok);
        if(!ok) return EXCEPTION_CONTINUE_SEARCH;
        c->Esp+=4;
        if(x.off>=0xa4bd0 && x.off<0xa4cf8) noteId=0;
    } else if(x.kind==3) {
        if(!Push(c,c->Ebp)) return EXCEPTION_CONTINUE_SEARCH;
    } else if(x.kind==4 || x.kind==5) {
        if(x.kind==5) {
            bool ok=false;
            next=Read(static_cast<uint32_t>(b+x.arg+c->Esi*4),4,&ok);
            if(!ok) return EXCEPTION_CONTINUE_SEARCH;
        } else next=static_cast<uint32_t>(b+x.arg);
        if(!Push(c,static_cast<uint32_t>(addr+x.len))) return EXCEPTION_CONTINUE_SEARCH;
    }
    c->Eip=next;
    SetLastError(lastError);
    return EXCEPTION_CONTINUE_EXECUTION;
}
}
void TraceProgramRoot(uint32_t source, uint32_t stable) {
    if(!handler) return;
    bool sourceOk=false, stableOk=false;
    const uint32_t sm=Read(source+0xec,4,&sourceOk), dm=Read(stable+0xec,4,&stableOk);
    Logf("VOICEPATH snapshot source=%08X stable=%08X sourceEC=%08X sourceRead=%u stableEC=%08X stableRead=%u modelId=%u layers=%u layerTable=%08X",source,stable,sm,sourceOk?1:0,dm,stableOk?1:0,Read(dm+4),Read(dm+0xa,2),Read(dm+0x10));
}
bool InstallVoiceTrace(uint8_t* image) {
    char enabled[8]{};
    // Diagnostic build: enabled by default, REALITY_VOICE_TRACE=0 disables it.
    if(GetEnvironmentVariableA("REALITY_VOICE_TRACE",enabled,sizeof(enabled)) && enabled[0]=='0') return true;
    if(handler) return base==image;
    for(const auto& x:sites) for(unsigned i=0;i<x.len;++i)
        if((image[x.off+i]&x.mask[i])!=(x.expected[i]&x.mask[i])) {
            Logf("VOICEPATH signature mismatch pc=%05X byte=%u; trace not installed",x.off,i);return false;
        }
    DWORD old=0;
    if(!VirtualProtect(image,0xba080,PAGE_EXECUTE_READWRITE,&old)) return false;
    base=image; sequence=0;
    handler=AddVectoredExceptionHandler(1,Trace);
    if(handler) for(const auto& x:sites) image[x.off]=0xcc;
    else base=nullptr;
    FlushInstructionCache(GetCurrentProcess(),image,0xba080);
    DWORD ignored=0;VirtualProtect(image,0xba080,old,&ignored);
    Logf("VOICEPATH enabled=%u sites=%u firstNotes=32 perNoteLineLimit=512",handler?1:0,static_cast<unsigned>(sizeof(sites)/sizeof(sites[0])));
    return handler!=nullptr;
}
void UninstallVoiceTrace() {
    // Called after the host pump and VMM workers are stopped, before image free.
    if(!handler)return;
    DWORD old=0;
    if(VirtualProtect(base,0xba080,PAGE_EXECUTE_READWRITE,&old)) {
        for(const auto& x:sites) base[x.off]=x.expected[0];
        FlushInstructionCache(GetCurrentProcess(),base,0xba080);
        DWORD ignored=0;VirtualProtect(base,0xba080,old,&ignored);
    }
    RemoveVectoredExceptionHandler(handler);handler=nullptr;base=nullptr;
}
}
