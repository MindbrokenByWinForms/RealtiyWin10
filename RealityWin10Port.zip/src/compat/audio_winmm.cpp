#include "audio_winmm.h"
#include "iathook.h"
#include "log.h"
#include <mmsystem.h>
#ifndef DIRECTSOUND_VERSION
#define DIRECTSOUND_VERSION 0x0700
#endif
#include <dsound.h>
#include <cstring>
#include <cstdint>
#include <climits>
#include <algorithm>
#include <mutex>
#include <unordered_map>
#include <vector>
#if defined(_MSC_VER)
#include <intrin.h>
#pragma intrinsic(_ReturnAddress)
#endif

static decltype(&waveOutGetNumDevs) RealWaveOutGetNumDevs = waveOutGetNumDevs;
static decltype(&waveOutGetDevCapsA) RealWaveOutGetDevCapsA = waveOutGetDevCapsA;
static decltype(&waveOutOpen) RealWaveOutOpen = waveOutOpen;
static decltype(&waveOutClose) RealWaveOutClose = waveOutClose;
static decltype(&waveOutPrepareHeader) RealWaveOutPrepareHeader = waveOutPrepareHeader;
static decltype(&waveOutWrite) RealWaveOutWrite = waveOutWrite;
static decltype(&waveOutReset) RealWaveOutReset = waveOutReset;
static decltype(&waveOutUnprepareHeader) RealWaveOutUnprepareHeader = waveOutUnprepareHeader;
static volatile LONG g_waveWriteCount = 0;
static volatile LONG g_waveResetCount = 0;

// SynMid prepares its complete ring before SSYNENG begins filling it.  During
// output replacement it expects the Win9x wave driver to set WHDR_DONE on all
// prepared headers after waveOutReset, including headers that were prepared but
// never submitted.  Modern winmm only promises to return queued buffers, so an
// unsubmitted header can remain WHDR_PREPARED forever and SynMid's UI-thread
// cleanup loop repeatedly calls waveOutReset.  Retain the small set of headers
// per open handle and reproduce the legacy completion transition after a
// successful reset.
static std::mutex g_waveHeaderMutex;
static std::unordered_map<HWAVEOUT, std::vector<LPWAVEHDR>> g_waveHeaders;

static void TrackWaveHandle(HWAVEOUT h) {
    if (!h) return;
    std::lock_guard<std::mutex> lock(g_waveHeaderMutex);
    g_waveHeaders[h];
}

static void ForgetWaveHandle(HWAVEOUT h) {
    std::lock_guard<std::mutex> lock(g_waveHeaderMutex);
    g_waveHeaders.erase(h);
}

static void TrackWaveHeader(HWAVEOUT h, LPWAVEHDR header) {
    if (!h || !header) return;
    std::lock_guard<std::mutex> lock(g_waveHeaderMutex);
    auto& headers = g_waveHeaders[h];
    if (std::find(headers.begin(), headers.end(), header) == headers.end())
        headers.push_back(header);
}

static void ForgetWaveHeader(HWAVEOUT h, LPWAVEHDR header) {
    std::lock_guard<std::mutex> lock(g_waveHeaderMutex);
    auto it = g_waveHeaders.find(h);
    if (it == g_waveHeaders.end()) return;
    auto& headers = it->second;
    headers.erase(std::remove(headers.begin(), headers.end(), header), headers.end());
}

static bool MarkLegacyHeaderDone(LPWAVEHDR header) {
    if (!header) return false;
#if defined(_MSC_VER)
    __try {
#endif
        header->dwFlags &= ~WHDR_INQUEUE;
        header->dwFlags |= WHDR_DONE;
        return true;
#if defined(_MSC_VER)
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("AudioWinMM: tracked wave header became unreadable header=%p", header);
        return false;
    }
#endif
}

static unsigned CompleteLegacyResetHeaders(HWAVEOUT h) {
    unsigned completed = 0;
    std::lock_guard<std::mutex> lock(g_waveHeaderMutex);
    auto it = g_waveHeaders.find(h);
    if (it == g_waveHeaders.end()) return 0;
    for (LPWAVEHDR header : it->second) {
        if (MarkLegacyHeaderDone(header)) ++completed;
    }
    return completed;
}

using DirectSoundCreateFn = HRESULT (WINAPI*)(LPCGUID, LPDIRECTSOUND*, LPUNKNOWN);
using DirectSoundEnumerateAFn = HRESULT (WINAPI*)(LPDSENUMCALLBACKA, LPVOID);
using DsCreateSoundBufferFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSound*, LPCDSBUFFERDESC,
                                                           LPDIRECTSOUNDBUFFER*, LPUNKNOWN);
using DsSetCooperativeLevelFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSound*, HWND, DWORD);
using DsBufferGetCurrentPositionFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, LPDWORD, LPDWORD);
using DsBufferGetStatusFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, LPDWORD);
using DsBufferLockFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, DWORD, DWORD,
                                                    LPVOID*, LPDWORD, LPVOID*, LPDWORD, DWORD);
using DsBufferPlayFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, DWORD, DWORD, DWORD);
using DsBufferSetPositionFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, DWORD);
using DsBufferSetFormatFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, LPCWAVEFORMATEX);
using DsBufferStopFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*);
using DsBufferUnlockFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*, LPVOID, DWORD, LPVOID, DWORD);
using DsBufferRestoreFn = HRESULT (STDMETHODCALLTYPE*)(IDirectSoundBuffer*);
static DirectSoundCreateFn RealDirectSoundCreate = nullptr;
static DirectSoundEnumerateAFn RealDirectSoundEnumerateA = nullptr;
static DsCreateSoundBufferFn RealDsCreateSoundBuffer = nullptr;
static DsSetCooperativeLevelFn RealDsSetCooperativeLevel = nullptr;

// DirectSound health state.  The legacy application uses DSSCL_WRITEPRIMARY
// as a capability test and later displays a Win9x-era warning when that path
// is not considered "true primary".  On NT, dsound.dll may legitimately map
// the primary buffer through the system mixer.  Track what actually succeeded
// so the compatibility layer can distinguish a real audio failure from the
// stale warning path.
static volatile LONG g_dsPrimaryCreated = 0;
static volatile LONG g_dsPrimaryFormatted = 0;
static volatile LONG g_dsSecondaryPlayed = 0;
static volatile LONG g_dsPrimaryFallback = 0;
static IDirectSoundBuffer* volatile g_dsLastPrimaryBuffer = nullptr;

bool RealityAudioDirectSoundPrimaryHealthy() {
    return InterlockedCompareExchange(&g_dsPrimaryCreated, 0, 0) != 0 &&
           InterlockedCompareExchange(&g_dsPrimaryFormatted, 0, 0) != 0;
}

bool RealityAudioDirectSoundTransportHealthy() {
    return RealityAudioDirectSoundPrimaryHealthy() ||
           InterlockedCompareExchange(&g_dsSecondaryPlayed, 0, 0) != 0;
}

bool RealityAudioDirectSoundUsingPrimaryFallback() {
    return InterlockedCompareExchange(&g_dsPrimaryFallback, 0, 0) != 0;
}

// Primary and secondary DirectSound buffers can use different vtables.  Keep
// their original methods in fixed process-lifetime records so hooks never rely
// on destructible STL state during audio callbacks or process shutdown.
struct DsBufferMethods {
    void** vtable = nullptr;
    DsBufferGetCurrentPositionFn getCurrentPosition = nullptr;
    DsBufferGetStatusFn getStatus = nullptr;
    DsBufferLockFn lock = nullptr;
    DsBufferPlayFn play = nullptr;
    DsBufferSetPositionFn setPosition = nullptr;
    DsBufferSetFormatFn setFormat = nullptr;
    DsBufferStopFn stop = nullptr;
    DsBufferUnlockFn unlock = nullptr;
    DsBufferRestoreFn restore = nullptr;
    volatile LONG statusCalls = 0;
    volatile LONG lockCalls = 0;
    volatile LONG playCalls = 0;
    volatile LONG positionCalls = 0;
    volatile LONG unlockCalls = 0;
};
static SRWLOCK g_dsBufferLock = SRWLOCK_INIT;
static DsBufferMethods g_dsBufferMethods[8] = {};

struct DsLockedRegion {
    IDirectSoundBuffer* buffer = nullptr;
    LPVOID p1 = nullptr;
    DWORD n1 = 0;
    LPVOID p2 = nullptr;
    DWORD n2 = 0;
};
static DsLockedRegion g_dsLockedRegions[8] = {};
static volatile LONG g_dsCursorQueryCalls = 0;

static void TrackDsLockedRegion(IDirectSoundBuffer* buffer, LPVOID p1, DWORD n1, LPVOID p2, DWORD n2) {
    if (!buffer || (!p1 && !p2)) return;
    AcquireSRWLockExclusive(&g_dsBufferLock);
    DsLockedRegion* slot = nullptr;
    for (auto& item : g_dsLockedRegions) {
        // DirectSound often reuses the same 32-KiB lock address when Reality
        // rebuilds its secondary buffer (exactly what the performance-mode
        // toggle does).  Prefer the newest owner of a mapped address so the
        // engine never queries the play cursor from a retired buffer object.
        if ((p1 && (item.p1 == p1 || item.p2 == p1)) || item.buffer == buffer) {
            slot = &item; break;
        }
        if (!slot && !item.buffer) slot = &item;
    }
    if (slot) { slot->buffer = buffer; slot->p1 = p1; slot->n1 = n1; slot->p2 = p2; slot->n2 = n2; }
    ReleaseSRWLockExclusive(&g_dsBufferLock);
}

static void ForgetDsLockedRegion(IDirectSoundBuffer* buffer, LPVOID p1) {
    AcquireSRWLockExclusive(&g_dsBufferLock);
    for (auto& item : g_dsLockedRegions) {
        if (item.buffer == buffer && (!p1 || item.p1 == p1)) { item = {}; break; }
    }
    ReleaseSRWLockExclusive(&g_dsBufferLock);
}

static DsBufferMethods* FindDsBufferMethods(IDirectSoundBuffer* self) {
    if (!self) return nullptr;
    void** vtable = *reinterpret_cast<void***>(self);
    DsBufferMethods* found = nullptr;
    AcquireSRWLockShared(&g_dsBufferLock);
    for (auto& item : g_dsBufferMethods) {
        if (item.vtable == vtable) { found = &item; break; }
    }
    ReleaseSRWLockShared(&g_dsBufferLock);
    return found;
}

static const char* MmResultName(MMRESULT r) {
    switch (r) {
    case MMSYSERR_NOERROR: return "MMSYSERR_NOERROR";
    case MMSYSERR_ERROR: return "MMSYSERR_ERROR";
    case MMSYSERR_BADDEVICEID: return "MMSYSERR_BADDEVICEID";
    case MMSYSERR_NOTENABLED: return "MMSYSERR_NOTENABLED";
    case MMSYSERR_ALLOCATED: return "MMSYSERR_ALLOCATED/already-in-use";
    case MMSYSERR_INVALHANDLE: return "MMSYSERR_INVALHANDLE";
    case MMSYSERR_NODRIVER: return "MMSYSERR_NODRIVER";
    case MMSYSERR_NOMEM: return "MMSYSERR_NOMEM";
    case MMSYSERR_NOTSUPPORTED: return "MMSYSERR_NOTSUPPORTED";
    case MMSYSERR_BADERRNUM: return "MMSYSERR_BADERRNUM";
    case MMSYSERR_INVALFLAG: return "MMSYSERR_INVALFLAG";
    case MMSYSERR_INVALPARAM: return "MMSYSERR_INVALPARAM";
    case WAVERR_BADFORMAT: return "WAVERR_BADFORMAT";
    case WAVERR_STILLPLAYING: return "WAVERR_STILLPLAYING";
    case WAVERR_UNPREPARED: return "WAVERR_UNPREPARED";
    case WAVERR_SYNC: return "WAVERR_SYNC";
    default: return "unknown";
    }
}

static const char* DsResultName(HRESULT hr) {
    if (hr == DS_OK) return "DS_OK";
    if (hr == DSERR_ALLOCATED) return "DSERR_ALLOCATED/already-in-use";
    if (hr == DSERR_BADFORMAT) return "DSERR_BADFORMAT";
    if (hr == DSERR_BUFFERLOST) return "DSERR_BUFFERLOST";
    if (hr == DSERR_CONTROLUNAVAIL) return "DSERR_CONTROLUNAVAIL";
    if (hr == DSERR_INVALIDCALL) return "DSERR_INVALIDCALL";
    if (hr == DSERR_INVALIDPARAM) return "DSERR_INVALIDPARAM";
    if (hr == DSERR_NODRIVER) return "DSERR_NODRIVER";
    if (hr == DSERR_OUTOFMEMORY) return "DSERR_OUTOFMEMORY";
    if (hr == DSERR_PRIOLEVELNEEDED) return "DSERR_PRIOLEVELNEEDED";
    if (hr == DSERR_UNSUPPORTED) return "DSERR_UNSUPPORTED";
    return "unknown";
}

static const char* DsCoopName(DWORD level) {
    switch (level) {
    case DSSCL_NORMAL: return "DSSCL_NORMAL";
    case DSSCL_PRIORITY: return "DSSCL_PRIORITY";
    case DSSCL_EXCLUSIVE: return "DSSCL_EXCLUSIVE";
    case DSSCL_WRITEPRIMARY: return "DSSCL_WRITEPRIMARY";
    default: return "unknown";
    }
}

static HRESULT STDMETHODCALLTYPE HookDsBufferGetStatus(IDirectSoundBuffer* self, LPDWORD status) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->getStatus ? m->getStatus(self, status) : DSERR_INVALIDCALL;
    const LONG call = m ? InterlockedIncrement(&m->statusCalls) : 0;
    if (call <= 16 || FAILED(hr) || (call > 0 && (call & (call - 1)) == 0))
        Logf("AudioDirectSoundBuffer: GetStatus #%ld self=%p -> %08lX (%s) status=%08lX",
             call, self, static_cast<unsigned long>(hr), DsResultName(hr),
             status && SUCCEEDED(hr) ? *status : 0ul);
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferRestore(IDirectSoundBuffer* self) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->restore ? m->restore(self) : DSERR_INVALIDCALL;
    Logf("AudioDirectSoundBuffer: Restore self=%p -> %08lX (%s)", self,
         static_cast<unsigned long>(hr), DsResultName(hr));
    return hr;
}

static HRESULT RestoreLostBuffer(IDirectSoundBuffer* self, DsBufferMethods* m, const char* caller) {
    HRESULT restore = m && m->restore ? m->restore(self) : DSERR_INVALIDCALL;
    Logf("AudioDirectSoundBuffer: %s saw DSERR_BUFFERLOST; Restore -> %08lX (%s)",
         caller, static_cast<unsigned long>(restore), DsResultName(restore));
    return restore;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferLock(IDirectSoundBuffer* self, DWORD offset, DWORD bytes,
    LPVOID* p1, LPDWORD n1, LPVOID* p2, LPDWORD n2, DWORD flags) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->lock ? m->lock(self, offset, bytes, p1, n1, p2, n2, flags) : DSERR_INVALIDCALL;
    if (hr == DSERR_BUFFERLOST && SUCCEEDED(RestoreLostBuffer(self, m, "Lock")))
        hr = m->lock(self, offset, bytes, p1, n1, p2, n2, flags);
    const LONG call = m ? InterlockedIncrement(&m->lockCalls) : 0;
    if (call <= 16 || FAILED(hr))
        Logf("AudioDirectSoundBuffer: Lock #%ld self=%p off=%lu bytes=%lu flags=%08lX -> %08lX (%s) ptrs=%p/%p spans=%lu+%lu",
             call, self, offset, bytes, flags, static_cast<unsigned long>(hr), DsResultName(hr),
             p1 && SUCCEEDED(hr) ? *p1 : nullptr, p2 && SUCCEEDED(hr) ? *p2 : nullptr,
             n1 && SUCCEEDED(hr) ? *n1 : 0ul, n2 && SUCCEEDED(hr) ? *n2 : 0ul);
    if (SUCCEEDED(hr))
        TrackDsLockedRegion(self, p1 ? *p1 : nullptr, n1 ? *n1 : 0, p2 ? *p2 : nullptr, n2 ? *n2 : 0);
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferPlay(IDirectSoundBuffer* self, DWORD reserved1,
    DWORD priority, DWORD flags) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->play ? m->play(self, reserved1, priority, flags) : DSERR_INVALIDCALL;
    if (hr == DSERR_BUFFERLOST && SUCCEEDED(RestoreLostBuffer(self, m, "Play")))
        hr = m->play(self, reserved1, priority, flags);
    if (SUCCEEDED(hr) && self != g_dsLastPrimaryBuffer)
        InterlockedExchange(&g_dsSecondaryPlayed, 1);
    const LONG call = m ? InterlockedIncrement(&m->playCalls) : 0;
    Logf("AudioDirectSoundBuffer: Play #%ld self=%p flags=%08lX -> %08lX (%s)",
         call, self, flags, static_cast<unsigned long>(hr), DsResultName(hr));
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferSetPosition(IDirectSoundBuffer* self, DWORD position) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->setPosition ? m->setPosition(self, position) : DSERR_INVALIDCALL;
    const LONG call = m ? InterlockedIncrement(&m->positionCalls) : 0;
    if (call <= 16 || FAILED(hr) || (call > 0 && (call & (call - 1)) == 0))
        Logf("AudioDirectSoundBuffer: SetCurrentPosition #%ld self=%p position=%lu -> %08lX (%s)",
             call, self, position, static_cast<unsigned long>(hr), DsResultName(hr));
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferSetFormat(IDirectSoundBuffer* self, LPCWAVEFORMATEX fmt) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->setFormat ? m->setFormat(self, fmt) : DSERR_INVALIDCALL;
    if (SUCCEEDED(hr) && self == g_dsLastPrimaryBuffer)
        InterlockedExchange(&g_dsPrimaryFormatted, 1);
    Logf("AudioDirectSoundBuffer: SetFormat self=%p rate=%lu bits=%u ch=%u -> %08lX (%s)",
         self, fmt ? fmt->nSamplesPerSec : 0ul,
         fmt ? static_cast<unsigned>(fmt->wBitsPerSample) : 0u,
         fmt ? static_cast<unsigned>(fmt->nChannels) : 0u,
         static_cast<unsigned long>(hr), DsResultName(hr));
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferStop(IDirectSoundBuffer* self) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->stop ? m->stop(self) : DSERR_INVALIDCALL;
    Logf("AudioDirectSoundBuffer: Stop self=%p -> %08lX (%s)", self,
         static_cast<unsigned long>(hr), DsResultName(hr));
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookDsBufferUnlock(IDirectSoundBuffer* self, LPVOID p1, DWORD n1,
    LPVOID p2, DWORD n2) {
    auto* m = FindDsBufferMethods(self);
    HRESULT hr = m && m->unlock ? m->unlock(self, p1, n1, p2, n2) : DSERR_INVALIDCALL;
    const LONG call = m ? InterlockedIncrement(&m->unlockCalls) : 0;
    if (call <= 16 || FAILED(hr))
        Logf("AudioDirectSoundBuffer: Unlock #%ld self=%p spans=%lu+%lu -> %08lX (%s)",
             call, self, n1, n2, static_cast<unsigned long>(hr), DsResultName(hr));
    if (SUCCEEDED(hr)) ForgetDsLockedRegion(self, p1);
    return hr;
}

extern "C" BOOL WINAPI RealityCompat_QueryDirectSoundPosition(
    LPVOID mappedBase, DWORD mappedBytes, LPDWORD playCursor, LPDWORD writeCursor) {
    if (!mappedBase || !mappedBytes || !playCursor || !writeCursor) { SetLastError(ERROR_INVALID_PARAMETER); return FALSE; }
    IDirectSoundBuffer* buffer = nullptr;
    DsBufferGetCurrentPositionFn getPosition = nullptr;
    AcquireSRWLockShared(&g_dsBufferLock);
    for (const auto& region : g_dsLockedRegions) {
        const bool first = region.p1 == mappedBase && region.n1 >= mappedBytes;
        const bool split = region.p1 == mappedBase && (region.n1 + region.n2) >= mappedBytes;
        if (!region.buffer || (!first && !split)) continue;
        buffer = region.buffer;
        void** vt = *reinterpret_cast<void***>(buffer);
        for (const auto& methods : g_dsBufferMethods) {
            if (methods.vtable == vt) { getPosition = methods.getCurrentPosition; break; }
        }
        break;
    }
    ReleaseSRWLockShared(&g_dsBufferLock);
    if (!buffer || !getPosition) { SetLastError(ERROR_NOT_FOUND); return FALSE; }
    DWORD play = 0, write = 0;
    const HRESULT hr = getPosition(buffer, &play, &write);
    if (FAILED(hr)) { SetLastError(ERROR_GEN_FAILURE); return FALSE; }
    *playCursor = play % mappedBytes;
    *writeCursor = write % mappedBytes;
    const LONG call = InterlockedIncrement(&g_dsCursorQueryCalls);
    if (call <= 8 || (call & (call - 1)) == 0)
        Logf("AudioDirectSoundBuffer: cursor query #%ld self=%p mapped=%p/%lu play=%lu write=%lu",
             call, buffer, mappedBase, mappedBytes, *playCursor, *writeCursor);
    SetLastError(ERROR_SUCCESS);
    return TRUE;
}

static bool PatchDirectSoundBuffer(IDirectSoundBuffer* buffer) {
    if (!buffer) return false;
    void** vtable = *reinterpret_cast<void***>(buffer);
    if (!vtable) return false;

    AcquireSRWLockExclusive(&g_dsBufferLock);
    DsBufferMethods* m = nullptr;
    for (auto& item : g_dsBufferMethods) {
        if (item.vtable == vtable) { m = &item; break; }
    }
    if (!m) {
        for (auto& item : g_dsBufferMethods) {
            if (!item.vtable) { m = &item; break; }
        }
    }
    if (!m) {
        ReleaseSRWLockExclusive(&g_dsBufferLock);
        Logf("AudioDirectSoundBuffer: no free vtable trace records for buffer=%p", buffer);
        return false;
    }
    if (m->vtable == vtable) {
        ReleaseSRWLockExclusive(&g_dsBufferLock);
        return true;
    }

    m->vtable = vtable;
    m->getCurrentPosition = reinterpret_cast<DsBufferGetCurrentPositionFn>(vtable[4]);
    m->getStatus = reinterpret_cast<DsBufferGetStatusFn>(vtable[9]);
    m->lock = reinterpret_cast<DsBufferLockFn>(vtable[11]);
    m->play = reinterpret_cast<DsBufferPlayFn>(vtable[12]);
    m->setPosition = reinterpret_cast<DsBufferSetPositionFn>(vtable[13]);
    m->setFormat = reinterpret_cast<DsBufferSetFormatFn>(vtable[14]);
    m->stop = reinterpret_cast<DsBufferStopFn>(vtable[18]);
    m->unlock = reinterpret_cast<DsBufferUnlockFn>(vtable[19]);
    m->restore = reinterpret_cast<DsBufferRestoreFn>(vtable[20]);

    struct Slot { unsigned index; void* hook; const char* name; };
    const Slot slots[] = {
        {9, reinterpret_cast<void*>(&HookDsBufferGetStatus), "GetStatus"},
        {11, reinterpret_cast<void*>(&HookDsBufferLock), "Lock"},
        {12, reinterpret_cast<void*>(&HookDsBufferPlay), "Play"},
        {13, reinterpret_cast<void*>(&HookDsBufferSetPosition), "SetCurrentPosition"},
        {14, reinterpret_cast<void*>(&HookDsBufferSetFormat), "SetFormat"},
        {18, reinterpret_cast<void*>(&HookDsBufferStop), "Stop"},
        {19, reinterpret_cast<void*>(&HookDsBufferUnlock), "Unlock"},
        {20, reinterpret_cast<void*>(&HookDsBufferRestore), "Restore"},
    };
    bool all = true;
    for (const auto& slotInfo : slots) {
        void** slot = &vtable[slotInfo.index];
        DWORD oldProtect = 0;
        if (!VirtualProtect(slot, sizeof(*slot), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            Logf("AudioDirectSoundBuffer: %s vtable VirtualProtect failed error=%lu",
                 slotInfo.name, GetLastError());
            all = false;
            continue;
        }
        *slot = slotInfo.hook;
        DWORD ignored = 0;
        VirtualProtect(slot, sizeof(*slot), oldProtect, &ignored);
        FlushInstructionCache(GetCurrentProcess(), slot, sizeof(*slot));
    }
    ReleaseSRWLockExclusive(&g_dsBufferLock);
    Logf("AudioDirectSoundBuffer: hooked buffer=%p vtable=%p methods=%s",
         buffer, vtable, all ? "complete" : "partial");
    return all;
}

static HRESULT STDMETHODCALLTYPE HookDsCreateSoundBuffer(IDirectSound* self,
    LPCDSBUFFERDESC desc, LPDIRECTSOUNDBUFFER* buffer, LPUNKNOWN outer) {
    const WAVEFORMATEX* fmt = desc ? desc->lpwfxFormat : nullptr;
    Logf("AudioDirectSound: CreateSoundBuffer ENTER self=%p flags=%08lX bytes=%lu format=%s rate=%lu bits=%u ch=%u",
         self, desc ? desc->dwFlags : 0ul, desc ? desc->dwBufferBytes : 0ul,
         fmt ? "present" : "NULL/primary", fmt ? fmt->nSamplesPerSec : 0ul,
         fmt ? static_cast<unsigned>(fmt->wBitsPerSample) : 0u,
         fmt ? static_cast<unsigned>(fmt->nChannels) : 0u);
    const HRESULT hr = RealDsCreateSoundBuffer ?
        RealDsCreateSoundBuffer(self, desc, buffer, outer) : DSERR_INVALIDCALL;
    Logf("AudioDirectSound: CreateSoundBuffer result=%08lX (%s) buffer=%p",
         static_cast<unsigned long>(hr), DsResultName(hr), buffer ? *buffer : nullptr);
    if (SUCCEEDED(hr) && buffer && *buffer) {
        if (desc && (desc->dwFlags & DSBCAPS_PRIMARYBUFFER)) {
            g_dsLastPrimaryBuffer = *buffer;
            InterlockedExchange(&g_dsPrimaryCreated, 1);
            // A newly-created primary must prove its format again.
            InterlockedExchange(&g_dsPrimaryFormatted, 0);
            Logf("AudioDirectSound: primary buffer accepted by modern dsound.dll buffer=%p", *buffer);
        }
        PatchDirectSoundBuffer(*buffer);
    }
    return hr;
}

static bool ShouldFallbackPrimaryCoop(HRESULT hr) {
    return hr == DSERR_ALLOCATED || hr == DSERR_UNSUPPORTED ||
           hr == DSERR_PRIOLEVELNEEDED || hr == DSERR_INVALIDCALL ||
           hr == DSERR_CONTROLUNAVAIL;
}

static HRESULT STDMETHODCALLTYPE HookDsSetCooperativeLevel(IDirectSound* self, HWND wnd, DWORD level) {
    if (!RealDsSetCooperativeLevel) return DSERR_INVALIDCALL;

    // Preserve Reality's requested semantics first.  Earlier clean-rehost
    // builds unconditionally converted DSSCL_WRITEPRIMARY to DSSCL_PRIORITY.
    // That made the real API calls succeed but caused Reality's own legacy
    // "primary buffer unavailable" branch to remain active.  Modern dsound.dll
    // is capable of accepting WRITEPRIMARY on some endpoints, so try it before
    // falling back.
    HRESULT hr = RealDsSetCooperativeLevel(self, wnd, level);
    Logf("AudioDirectSound: SetCooperativeLevel self=%p hwnd=%p requested=%s native -> %08lX (%s)",
         self, wnd, DsCoopName(level), static_cast<unsigned long>(hr), DsResultName(hr));

    if ((level == DSSCL_EXCLUSIVE || level == DSSCL_WRITEPRIMARY) &&
        FAILED(hr) && ShouldFallbackPrimaryCoop(hr)) {
        const HRESULT fallback = RealDsSetCooperativeLevel(self, wnd, DSSCL_PRIORITY);
        Logf("AudioDirectSound: SetCooperativeLevel %s rejected; fallback DSSCL_PRIORITY -> %08lX (%s)",
             DsCoopName(level), static_cast<unsigned long>(fallback), DsResultName(fallback));
        if (SUCCEEDED(fallback)) {
            InterlockedExchange(&g_dsPrimaryFallback, 1);
            return fallback;
        }
        hr = fallback;
    }

    if (hr == DSERR_ALLOCATED && level != DSSCL_NORMAL) {
        const HRESULT retry = RealDsSetCooperativeLevel(self, wnd, DSSCL_NORMAL);
        Logf("AudioDirectSound: SetCooperativeLevel already-in-use retry DSSCL_NORMAL -> %08lX (%s)",
             static_cast<unsigned long>(retry), DsResultName(retry));
        if (SUCCEEDED(retry)) {
            InterlockedExchange(&g_dsPrimaryFallback, 1);
            hr = retry;
        }
    }
    return hr;
}

static bool PatchDirectSoundObject(IDirectSound* ds) {
    if (!ds) return false;
    auto** vtable = *reinterpret_cast<void***>(ds);
    if (!vtable) return false;

    struct MethodPatch { unsigned index; void* hook; void** original; const char* name; };
    MethodPatch patches[] = {
        { 3, reinterpret_cast<void*>(&HookDsCreateSoundBuffer),
          reinterpret_cast<void**>(&RealDsCreateSoundBuffer), "CreateSoundBuffer" },
        { 6, reinterpret_cast<void*>(&HookDsSetCooperativeLevel),
          reinterpret_cast<void**>(&RealDsSetCooperativeLevel), "SetCooperativeLevel" },
    };
    bool all = true;
    for (auto& patch : patches) {
        void** slot = &vtable[patch.index];
        if (*slot == patch.hook) continue;
        if (*patch.original && *slot != *patch.original) {
            Logf("AudioDirectSound: %s vtable differs from previously hooked object; leaving object unchanged",
                 patch.name);
            all = false;
            continue;
        }
        if (!*patch.original) *patch.original = *slot;
        DWORD oldProtect = 0;
        if (!VirtualProtect(slot, sizeof(*slot), PAGE_EXECUTE_READWRITE, &oldProtect)) {
            Logf("AudioDirectSound: %s vtable VirtualProtect failed error=%lu", patch.name, GetLastError());
            all = false;
            continue;
        }
        *slot = patch.hook;
        DWORD ignored = 0;
        VirtualProtect(slot, sizeof(*slot), oldProtect, &ignored);
        FlushInstructionCache(GetCurrentProcess(), slot, sizeof(*slot));
        Logf("AudioDirectSound: hooked IDirectSound::%s object=%p original=%p",
             patch.name, ds, *patch.original);
    }
    return all;
}

static HRESULT WINAPI HookDirectSoundCreate(LPCGUID guid, LPDIRECTSOUND* ds, LPUNKNOWN outer) {
    Logf("AudioDirectSound: DirectSoundCreate ENTER guid=%p outer=%p", guid, outer);
    HRESULT hr = RealDirectSoundCreate ?
        RealDirectSoundCreate(guid, ds, outer) : DSERR_INVALIDCALL;
    if (hr == DSERR_ALLOCATED && guid && RealDirectSoundCreate) {
        Logf("AudioDirectSound: selected endpoint already allocated; retrying default shared device");
        hr = RealDirectSoundCreate(nullptr, ds, outer);
    }
    Logf("AudioDirectSound: DirectSoundCreate result=%08lX (%s) object=%p",
         static_cast<unsigned long>(hr), DsResultName(hr), ds ? *ds : nullptr);
    if (SUCCEEDED(hr) && ds && *ds) PatchDirectSoundObject(*ds);
    return hr;
}

struct DsEnumContext {
    LPDSENUMCALLBACKA callback;
    LPVOID context;
    unsigned count;
};

static BOOL CALLBACK TraceDirectSoundEnum(LPGUID guid, LPCSTR description,
                                           LPCSTR module, LPVOID opaque) {
    auto* ctx = reinterpret_cast<DsEnumContext*>(opaque);
    if (ctx) ++ctx->count;
    Logf("AudioDirectSound: enumerate item=%u guid=%p description=%s module=%s",
         ctx ? ctx->count : 0u, guid, description ? description : "(null)",
         module ? module : "(null)");
    return ctx && ctx->callback ? ctx->callback(guid, description, module, ctx->context) : TRUE;
}

static HRESULT WINAPI HookDirectSoundEnumerateA(LPDSENUMCALLBACKA callback, LPVOID context) {
    DsEnumContext wrapped{callback, context, 0};
    Logf("AudioDirectSound: DirectSoundEnumerateA ENTER callback=%p", callback);
    const HRESULT hr = RealDirectSoundEnumerateA ?
        RealDirectSoundEnumerateA(&TraceDirectSoundEnum, &wrapped) : DSERR_INVALIDCALL;
    Logf("AudioDirectSound: DirectSoundEnumerateA result=%08lX (%s) count=%u",
         static_cast<unsigned long>(hr), DsResultName(hr), wrapped.count);
    return hr;
}

FARPROC WrapRealityDirectSoundProc(LPCSTR name, FARPROC proc) {
    if (!name || !proc || (reinterpret_cast<ULONG_PTR>(name) >> 16) == 0) return proc;
    if (_stricmp(name, "DirectSoundCreate") == 0) {
        RealDirectSoundCreate = reinterpret_cast<DirectSoundCreateFn>(proc);
        return reinterpret_cast<FARPROC>(&HookDirectSoundCreate);
    }
    if (_stricmp(name, "DirectSoundEnumerateA") == 0) {
        RealDirectSoundEnumerateA = reinterpret_cast<DirectSoundEnumerateAFn>(proc);
        return reinterpret_cast<FARPROC>(&HookDirectSoundEnumerateA);
    }
    return proc;
}

// Internal SynMid audio-manager trace points recovered from Reality 1.5 / SynMid 1.5.5.
// These are CALL sites, not function-entry overwrites, so the original routines remain
// intact and can be invoked by the compatibility wrappers.
using ThisBoolFn = unsigned char (__thiscall*)(void*);
static ThisBoolFn RealAudioOutputManagerInit = nullptr;   // SynMid RVA 0x0903F
static ThisBoolFn RealAudioSharedBlockSetup  = nullptr;   // SynMid RVA 0x092A4
static ThisBoolFn RealAudioEnumerateBuild    = nullptr;   // SynMid RVA 0x08A76
static volatile LONG g_audioProbeDone = 0;

static bool PatchRelativeCall(HMODULE module, DWORD callRva, DWORD expectedTargetRva,
                              void* replacement, void** originalTarget) {
    auto* base = reinterpret_cast<unsigned char*>(module);
    auto* p = base + callRva;
    if (p[0] != 0xE8) {
        Logf("AudioTrace: call-site signature mismatch RVA=%08lX opcode=%02X", callRva, p[0]);
        return false;
    }
    std::int32_t oldRel = 0;
    std::memcpy(&oldRel, p + 1, sizeof(oldRel));
    auto* oldTarget = p + 5 + oldRel;
    const DWORD oldTargetRva = static_cast<DWORD>(oldTarget - base);
    if (oldTargetRva != expectedTargetRva) {
        Logf("AudioTrace: call-site target mismatch RVA=%08lX expected=%08lX actual=%08lX",
             callRva, expectedTargetRva, oldTargetRva);
        return false;
    }

    const std::intptr_t delta = reinterpret_cast<unsigned char*>(replacement) - (p + 5);
    if (delta < INT32_MIN || delta > INT32_MAX) {
        Logf("AudioTrace: hook target out of rel32 range callRVA=%08lX hook=%p", callRva, replacement);
        return false;
    }
    const std::int32_t newRel = static_cast<std::int32_t>(delta);
    DWORD oldProt = 0;
    if (!VirtualProtect(p, 5, PAGE_EXECUTE_READWRITE, &oldProt)) {
        Logf("AudioTrace: VirtualProtect failed callRVA=%08lX error=%lu", callRva, GetLastError());
        return false;
    }
    std::memcpy(p + 1, &newRel, sizeof(newRel));
    FlushInstructionCache(GetCurrentProcess(), p, 5);
    DWORD tmp = 0;
    VirtualProtect(p, 5, oldProt, &tmp);
    if (originalTarget) *originalTarget = oldTarget;
    Logf("AudioTrace: patched CALL SynMidRVA=%08lX originalTargetRVA=%08lX -> hook=%p",
         callRva, oldTargetRva, replacement);
    return true;
}

static void LogAudioObject(const char* where, void* self) {
    if (!self) {
        Logf("AudioTrace: %s this=NULL", where);
        return;
    }
#ifdef _MSC_VER
    __try {
#endif
        const auto* b = reinterpret_cast<const unsigned char*>(self);
        const DWORD current = *reinterpret_cast<const DWORD*>(b + 0x04);
        const DWORD entries = *reinterpret_cast<const DWORD*>(b + 0x08);
        const DWORD names = *reinterpret_cast<const DWORD*>(b + 0x0C);
        const DWORD count = *reinterpret_cast<const DWORD*>(b + 0x10);
        const DWORD sharedToken = *reinterpret_cast<const DWORD*>(b + 0x78);
        const DWORD sharedSize = *reinterpret_cast<const DWORD*>(b + 0x7C);
        Logf("AudioTrace: %s this=%p current=%08lX entries=%08lX names=%08lX count=%lu sharedToken=%08lX sharedSize=%lu",
             where, self, current, entries, names, count, sharedToken, sharedSize);
#ifdef _MSC_VER
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("AudioTrace: %s this=%p fields unreadable", where, self);
    }
#endif
}

static void ProbeHostWaveOutOnce() {
    if (InterlockedCompareExchange(&g_audioProbeDone, 1, 0) != 0) return;
    const UINT n = RealWaveOutGetNumDevs ? RealWaveOutGetNumDevs() : 0;
    Logf("AudioProbe: native Windows waveOutGetNumDevs=%u", n);
    for (UINT i = 0; i < n; ++i) {
        WAVEOUTCAPSA caps{};
        const MMRESULT r = RealWaveOutGetDevCapsA ?
            RealWaveOutGetDevCapsA(i, &caps, sizeof(caps)) : MMSYSERR_NODRIVER;
        if (r == MMSYSERR_NOERROR) {
            Logf("AudioProbe: native id=%u name=%s channels=%u formats=%08lX support=%08lX",
                 i, caps.szPname, static_cast<unsigned>(caps.wChannels),
                 static_cast<unsigned long>(caps.dwFormats),
                 static_cast<unsigned long>(caps.dwSupport));
        } else {
            Logf("AudioProbe: native id=%u caps failed mmresult=%u", i, static_cast<unsigned>(r));
        }
    }

    WAVEFORMATEX fmt{};
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = 2;
    fmt.nSamplesPerSec = 44100;
    fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = static_cast<WORD>(fmt.nChannels * fmt.wBitsPerSample / 8);
    fmt.nAvgBytesPerSec = fmt.nSamplesPerSec * fmt.nBlockAlign;
    const MMRESULT q = RealWaveOutOpen ?
        RealWaveOutOpen(nullptr, WAVE_MAPPER, &fmt, 0, 0, WAVE_FORMAT_QUERY) : MMSYSERR_NODRIVER;
    Logf("AudioProbe: WAVE_MAPPER format query PCM 44100/16/stereo -> mmresult=%u", static_cast<unsigned>(q));
}

static unsigned char __fastcall HookAudioSharedBlockSetup(void* self, void*) {
    LogAudioObject("shared-block setup ENTER", self);
    const unsigned char r = RealAudioSharedBlockSetup ? RealAudioSharedBlockSetup(self) : 0;
    LogAudioObject(r ? "shared-block setup OK" : "shared-block setup FAILED", self);
    return r;
}

static unsigned char __fastcall HookAudioEnumerateBuild(void* self, void*) {
    LogAudioObject("device enumerate/build ENTER", self);
    ProbeHostWaveOutOnce();
    const unsigned char r = RealAudioEnumerateBuild ? RealAudioEnumerateBuild(self) : 0;
    LogAudioObject(r ? "device enumerate/build OK" : "device enumerate/build FAILED", self);
    return r;
}

static unsigned char __fastcall HookAudioOutputManagerInit(void* self, void*) {
    LogAudioObject("output-manager init ENTER", self);
    ProbeHostWaveOutOnce();
    const unsigned char r = RealAudioOutputManagerInit ? RealAudioOutputManagerInit(self) : 0;
    LogAudioObject(r ? "output-manager init OK" : "output-manager init FAILED", self);
    return r;
}

static bool PatchInternalAudioTrace(HMODULE synMid) {
    void* origMain = nullptr;
    void* origShared = nullptr;
    void* origBuild = nullptr;

    // Main initialization routine RVA 0x3382B calls AudioOutputManager::Init
    // at call-site RVA 0x33A3F.
    const bool a = PatchRelativeCall(synMid, 0x00033A3F, 0x0000903F,
                                    reinterpret_cast<void*>(&HookAudioOutputManagerInit), &origMain);
    // AudioOutputManager::Init itself calls the shared-block setup at RVA 0x9067
    // and the actual device-list builder at RVA 0x9078.
    const bool b = PatchRelativeCall(synMid, 0x00009067, 0x000092A4,
                                    reinterpret_cast<void*>(&HookAudioSharedBlockSetup), &origShared);
    const bool c = PatchRelativeCall(synMid, 0x00009078, 0x00008A76,
                                    reinterpret_cast<void*>(&HookAudioEnumerateBuild), &origBuild);

    if (a) RealAudioOutputManagerInit = reinterpret_cast<ThisBoolFn>(origMain);
    if (b) RealAudioSharedBlockSetup = reinterpret_cast<ThisBoolFn>(origShared);
    if (c) RealAudioEnumerateBuild = reinterpret_cast<ThisBoolFn>(origBuild);

    Logf("AudioTrace: internal SynMid audio-manager tracing MainInit=%d SharedBlock=%d EnumerateBuild=%d",
         a, b, c);
    return a && b && c;
}

static bool PatchLegacyDirectSoundVersionGate(HMODULE synMid) {
    // Reality 1.5's DirectSound availability probe (SynMid RVA 0x9D4B)
    // requires BOTH dsound.dll and the Win9x-only dsound.vxd to have a
    // sufficiently new file version.  NT has no dsound.vxd, so the probe
    // always returns false before DirectSoundEnumerateA is ever called.
    // On modern Windows, dsound.dll itself provides the compatibility layer;
    // short-circuit this obsolete Win9x VxD version test.
    unsigned char* p = reinterpret_cast<unsigned char*>(synMid) + 0x00009D4B;
    static const unsigned char expected[] = { 0x55,0x8B,0xEC,0x6A,0xFF,0x68 };
    static const unsigned char replacement[] = { 0xB8,0x01,0x00,0x00,0x00,0xC3 }; // mov eax,1; ret
    if (std::memcmp(p, expected, sizeof(expected)) != 0) {
        Logf("AudioDirectSound: legacy version-gate signature mismatch at %p RVA=00009D4B; not patching", p);
        return false;
    }
    DWORD oldProt=0;
    if (!VirtualProtect(p, sizeof(replacement), PAGE_EXECUTE_READWRITE, &oldProt)) {
        Logf("AudioDirectSound: VirtualProtect failed error=%lu", GetLastError());
        return false;
    }
    std::memcpy(p, replacement, sizeof(replacement));
    FlushInstructionCache(GetCurrentProcess(), p, sizeof(replacement));
    DWORD tmp=0; VirtualProtect(p, sizeof(replacement), oldProt, &tmp);
    Logf("AudioDirectSound: bypassed Win9x dsound.vxd version gate at SynMidRVA=00009D4B (modern dsound.dll allowed)");
    return true;
}

static UINT DefaultMapperId() {
    return RealWaveOutGetNumDevs ? RealWaveOutGetNumDevs() : 0;
}

static UINT WINAPI HookWaveOutGetNumDevs() {
    UINT real = RealWaveOutGetNumDevs ? RealWaveOutGetNumDevs() : 0;
    Logf("AudioWinMM: waveOutGetNumDevs real=%u + Windows Default Audio mapper", real);
    // Append one synthetic list entry. Its public list id is 'real'; opening
    // that entry is translated back to WAVE_MAPPER below.
    return real + 1;
}

static MMRESULT WINAPI HookWaveOutGetDevCapsA(UINT_PTR id, LPWAVEOUTCAPSA caps, UINT cb) {
    const UINT mapperId = DefaultMapperId();
    if (id == mapperId) {
        if (!caps || cb == 0) return MMSYSERR_INVALPARAM;
        WAVEOUTCAPSA out{};
        out.wMid = 0xFFFF;
        out.wPid = 0x0002;
        out.vDriverVersion = 0x0403;
        strncpy_s(out.szPname, MAXPNAMELEN, "Windows Default Audio", _TRUNCATE);
        out.dwFormats = WAVE_FORMAT_1M08 | WAVE_FORMAT_1S08 |
                        WAVE_FORMAT_1M16 | WAVE_FORMAT_1S16 |
                        WAVE_FORMAT_2M08 | WAVE_FORMAT_2S08 |
                        WAVE_FORMAT_2M16 | WAVE_FORMAT_2S16 |
                        WAVE_FORMAT_4M08 | WAVE_FORMAT_4S08 |
                        WAVE_FORMAT_4M16 | WAVE_FORMAT_4S16;
        out.wChannels = 2;
        out.dwSupport = WAVECAPS_VOLUME | WAVECAPS_LRVOLUME;
        std::memcpy(caps, &out, cb < sizeof(out) ? cb : sizeof(out));
        Logf("AudioWinMM: caps synthetic id=%u name=Windows Default Audio -> WAVE_MAPPER", mapperId);
        return MMSYSERR_NOERROR;
    }

    MMRESULT r = RealWaveOutGetDevCapsA ? RealWaveOutGetDevCapsA(id, caps, cb) : MMSYSERR_NODRIVER;
    if (r == MMSYSERR_NOERROR && caps) {
        Logf("AudioWinMM: caps real id=%lu name=%s channels=%u formats=%08lX support=%08lX",
             static_cast<unsigned long>(id), caps->szPname,
             static_cast<unsigned>(caps->wChannels),
             static_cast<unsigned long>(caps->dwFormats),
             static_cast<unsigned long>(caps->dwSupport));
    } else {
        Logf("AudioWinMM: caps real id=%lu failed mmresult=%u",
             static_cast<unsigned long>(id), static_cast<unsigned>(r));
    }
    return r;
}

static MMRESULT WINAPI HookWaveOutOpen(LPHWAVEOUT out, UINT id, LPCWAVEFORMATEX fmt,
                                       DWORD_PTR callback, DWORD_PTR instance, DWORD flags) {
    const UINT mapperId = DefaultMapperId();
    UINT actualId = id == mapperId ? WAVE_MAPPER : id;
    if (fmt) {
        Logf("AudioWinMM: waveOutOpen requested id=%u actual=%s rate=%lu bits=%u ch=%u block=%u avg=%lu flags=%08lX",
             id, actualId == WAVE_MAPPER ? "WAVE_MAPPER" : "numbered",
             static_cast<unsigned long>(fmt->nSamplesPerSec),
             static_cast<unsigned>(fmt->wBitsPerSample),
             static_cast<unsigned>(fmt->nChannels),
             static_cast<unsigned>(fmt->nBlockAlign),
             static_cast<unsigned long>(fmt->nAvgBytesPerSec),
             static_cast<unsigned long>(flags));
    } else {
        Logf("AudioWinMM: waveOutOpen requested id=%u actual=%s fmt=NULL flags=%08lX",
             id, actualId == WAVE_MAPPER ? "WAVE_MAPPER" : "numbered",
             static_cast<unsigned long>(flags));
    }
    MMRESULT r = RealWaveOutOpen ? RealWaveOutOpen(out, actualId, fmt, callback, instance, flags)
                                 : MMSYSERR_NODRIVER;
    Logf("AudioWinMM: waveOutOpen result=%u (%s) handle=%p", static_cast<unsigned>(r),
         MmResultName(r), out ? *out : nullptr);

    // An old saved numeric waveOut id can now point to an endpoint held in
    // exclusive mode or to a device that no longer exists.  For a real open
    // (never for WAVE_FORMAT_QUERY), retry through today's default mapper and
    // then the remaining numbered endpoints.  A successful retry is a normal
    // shared WinMM stream; it does not steal or close another application's
    // device.
    const bool canRetry = (flags & WAVE_FORMAT_QUERY) == 0 && RealWaveOutOpen &&
                          (r == MMSYSERR_ALLOCATED || r == MMSYSERR_BADDEVICEID ||
                           r == MMSYSERR_NODRIVER);
    if (canRetry && actualId != WAVE_MAPPER) {
        if (out) *out = nullptr;
        const MMRESULT retry = RealWaveOutOpen(out, WAVE_MAPPER, fmt, callback, instance, flags);
        Logf("AudioWinMM: waveOutOpen fallback WAVE_MAPPER -> %u (%s) handle=%p",
             static_cast<unsigned>(retry), MmResultName(retry), out ? *out : nullptr);
        r = retry;
    }
    if (canRetry && r != MMSYSERR_NOERROR) {
        const UINT count = RealWaveOutGetNumDevs ? RealWaveOutGetNumDevs() : 0;
        for (UINT candidate = 0; candidate < count; ++candidate) {
            if (candidate == actualId) continue;
            if (out) *out = nullptr;
            const MMRESULT retry = RealWaveOutOpen(out, candidate, fmt, callback, instance, flags);
            Logf("AudioWinMM: waveOutOpen fallback numbered id=%u -> %u (%s) handle=%p",
                 candidate, static_cast<unsigned>(retry), MmResultName(retry), out ? *out : nullptr);
            r = retry;
            if (r == MMSYSERR_NOERROR) break;
        }
    }
    if (r == MMSYSERR_NOERROR && (flags & WAVE_FORMAT_QUERY) == 0 && out && *out)
        TrackWaveHandle(*out);
    return r;
}

static MMRESULT WINAPI HookWaveOutClose(HWAVEOUT h) {
    Logf("AudioWinMM: waveOutClose handle=%p", h);
    MMRESULT r = RealWaveOutClose ? RealWaveOutClose(h) : MMSYSERR_INVALHANDLE;
    Logf("AudioWinMM: waveOutClose result=%u (%s)", static_cast<unsigned>(r), MmResultName(r));
    if (r == MMSYSERR_NOERROR) ForgetWaveHandle(h);
    return r;
}

static MMRESULT WINAPI HookWaveOutPrepareHeader(HWAVEOUT h, LPWAVEHDR header, UINT cb) {
    const MMRESULT r = RealWaveOutPrepareHeader ?
        RealWaveOutPrepareHeader(h, header, cb) : MMSYSERR_INVALHANDLE;
    Logf("AudioWinMM: waveOutPrepareHeader handle=%p header=%p bytes=%lu flags=%08lX -> %u (%s)",
         h, header, header ? header->dwBufferLength : 0ul,
         header ? header->dwFlags : 0ul, static_cast<unsigned>(r), MmResultName(r));
    if (r == MMSYSERR_NOERROR) TrackWaveHeader(h, header);
    return r;
}

static MMRESULT WINAPI HookWaveOutWrite(HWAVEOUT h, LPWAVEHDR header, UINT cb) {
    const LONG sequence = InterlockedIncrement(&g_waveWriteCount);
    const MMRESULT r = RealWaveOutWrite ?
        RealWaveOutWrite(h, header, cb) : MMSYSERR_INVALHANDLE;
    if (sequence <= 8 || (sequence % 128) == 0 || r != MMSYSERR_NOERROR) {
        Logf("AudioWinMM: waveOutWrite sequence=%ld handle=%p header=%p bytes=%lu -> %u (%s)",
             sequence, h, header, header ? header->dwBufferLength : 0ul,
             static_cast<unsigned>(r), MmResultName(r));
    }
    return r;
}

static MMRESULT WINAPI HookWaveOutReset(HWAVEOUT h) {
    const MMRESULT r = RealWaveOutReset ? RealWaveOutReset(h) : MMSYSERR_INVALHANDLE;
    const unsigned completed = r == MMSYSERR_NOERROR ? CompleteLegacyResetHeaders(h) : 0;
    const LONG sequence = InterlockedIncrement(&g_waveResetCount);
    void* caller = nullptr;
#if defined(_MSC_VER)
    caller = _ReturnAddress();
#endif
    HMODULE synMid = GetModuleHandleA("SynMid.dll");
    const ULONG_PTR callerValue = reinterpret_cast<ULONG_PTR>(caller);
    const ULONG_PTR synBase = reinterpret_cast<ULONG_PTR>(synMid);
    const DWORD callerRva = caller && synMid && callerValue >= synBase
        ? static_cast<DWORD>(callerValue - synBase) : 0xffffffffu;
    if (sequence <= 8 || (sequence & (sequence - 1)) == 0 || r != MMSYSERR_NOERROR) {
        Logf("AudioWinMM: waveOutReset sequence=%ld handle=%p -> %u (%s); legacy-completed=%u caller=%p SynMidRVA=%08lX",
             sequence, h, static_cast<unsigned>(r), MmResultName(r), completed,
             caller, callerRva);
    }
    return r;
}

static MMRESULT WINAPI HookWaveOutUnprepareHeader(HWAVEOUT h, LPWAVEHDR header, UINT cb) {
    const MMRESULT r = RealWaveOutUnprepareHeader ?
        RealWaveOutUnprepareHeader(h, header, cb) : MMSYSERR_INVALHANDLE;
    Logf("AudioWinMM: waveOutUnprepareHeader handle=%p header=%p flags=%08lX -> %u (%s)",
         h, header, header ? header->dwFlags : 0ul,
         static_cast<unsigned>(r), MmResultName(r));
    if (r == MMSYSERR_NOERROR) ForgetWaveHeader(h, header);
    return r;
}

bool PatchRealityAudioWinmm(HMODULE synMid) {
    if (!synMid) return false;
    Logf("SynMid WinMM audio patch begin base=%p", synMid);
    bool ds = PatchLegacyDirectSoundVersionGate(synMid);
    void* old = nullptr;
    bool a = PatchImport(synMid, "WINMM.dll", "waveOutGetNumDevs", (void*)&HookWaveOutGetNumDevs, &old);
    if (a && old) RealWaveOutGetNumDevs = reinterpret_cast<decltype(RealWaveOutGetNumDevs)>(old);
    old = nullptr;
    bool b = PatchImport(synMid, "WINMM.dll", "waveOutGetDevCapsA", (void*)&HookWaveOutGetDevCapsA, &old);
    if (b && old) RealWaveOutGetDevCapsA = reinterpret_cast<decltype(RealWaveOutGetDevCapsA)>(old);
    old = nullptr;
    bool c = PatchImport(synMid, "WINMM.dll", "waveOutOpen", (void*)&HookWaveOutOpen, &old);
    if (c && old) RealWaveOutOpen = reinterpret_cast<decltype(RealWaveOutOpen)>(old);
    old = nullptr;
    bool d = PatchImport(synMid, "WINMM.dll", "waveOutClose", (void*)&HookWaveOutClose, &old);
    if (d && old) RealWaveOutClose = reinterpret_cast<decltype(RealWaveOutClose)>(old);
    old = nullptr;
    bool e = PatchImport(synMid, "WINMM.dll", "waveOutPrepareHeader", (void*)&HookWaveOutPrepareHeader, &old);
    if (e && old) RealWaveOutPrepareHeader = reinterpret_cast<decltype(RealWaveOutPrepareHeader)>(old);
    old = nullptr;
    bool f = PatchImport(synMid, "WINMM.dll", "waveOutWrite", (void*)&HookWaveOutWrite, &old);
    if (f && old) RealWaveOutWrite = reinterpret_cast<decltype(RealWaveOutWrite)>(old);
    old = nullptr;
    bool g = PatchImport(synMid, "WINMM.dll", "waveOutReset", (void*)&HookWaveOutReset, &old);
    if (g && old) RealWaveOutReset = reinterpret_cast<decltype(RealWaveOutReset)>(old);
    old = nullptr;
    bool h = PatchImport(synMid, "WINMM.dll", "waveOutUnprepareHeader", (void*)&HookWaveOutUnprepareHeader, &old);
    if (h && old) RealWaveOutUnprepareHeader = reinterpret_cast<decltype(RealWaveOutUnprepareHeader)>(old);
    const bool trace = PatchInternalAudioTrace(synMid);
    Logf("SynMid audio patch complete DirectSoundGate=%d WaveGetNum=%d WaveGetCaps=%d WaveOpen=%d WaveClose=%d WavePrepare=%d WaveWrite=%d WaveReset=%d WaveUnprepare=%d InternalTrace=%d",
         ds,a,b,c,d,e,f,g,h,trace);
    return ds && a && b && c && d;
}
