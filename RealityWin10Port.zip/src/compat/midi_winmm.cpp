#include "midi_winmm.h"
#include "iathook.h"
#include "log.h"
#include "native_midi.h"
#include <mmsystem.h>
#include <cstring>

static decltype(&midiOutGetNumDevs) RealMidiOutGetNumDevs = midiOutGetNumDevs;
static decltype(&midiOutGetDevCapsA) RealMidiOutGetDevCapsA = midiOutGetDevCapsA;
static decltype(&midiOutOpen) RealMidiOutOpen = midiOutOpen;
static decltype(&midiOutClose) RealMidiOutClose = midiOutClose;
static decltype(&midiOutShortMsg) RealMidiOutShortMsg = midiOutShortMsg;
static decltype(&midiOutLongMsg) RealMidiOutLongMsg = midiOutLongMsg;
static decltype(&midiOutReset) RealMidiOutReset = midiOutReset;
static decltype(&midiOutGetVolume) RealMidiOutGetVolume = midiOutGetVolume;
static decltype(&midiOutSetVolume) RealMidiOutSetVolume = midiOutSetVolume;
static decltype(&midiConnect) RealMidiConnect = midiConnect;
static decltype(&midiDisconnect) RealMidiDisconnect = midiDisconnect;
static decltype(&midiInGetNumDevs) RealMidiInGetNumDevs = midiInGetNumDevs;
static decltype(&midiInGetDevCapsA) RealMidiInGetDevCapsA = midiInGetDevCapsA;
static decltype(&midiInOpen) RealMidiInOpen = midiInOpen;
static decltype(&midiInStart) RealMidiInStart = midiInStart;
static decltype(&midiInStop) RealMidiInStop = midiInStop;
static decltype(&midiInClose) RealMidiInClose = midiInClose;

static HMIDIOUT g_realityMidiOut = nullptr;
static HMIDI g_connectedMidi = nullptr;
static volatile LONG g_midiMoreDataCount = 0;

static UINT RealityMidiDeviceId() {
    return RealMidiOutGetNumDevs ? RealMidiOutGetNumDevs() : 0;
}

static bool IsRealityMidiHandle(HMIDIOUT h) {
    return h && h == g_realityMidiOut;
}

static void CALLBACK BridgeMidiInCallback(HMIDIIN hmi, UINT msg, DWORD_PTR instance,
                                          DWORD_PTR p1, DWORD_PTR p2) {
    (void)instance;
    switch (msg) {
        case MIM_OPEN:  Logf("WinMM MIDI-IN: opened handle=%p", hmi); break;
        case MIM_CLOSE: Logf("WinMM MIDI-IN: closed handle=%p", hmi); break;
        case MIM_DATA:
            NativeMidiCaptureShort(static_cast<DWORD>(p1), static_cast<DWORD>(p2));
            break;
#ifdef MIM_MOREDATA
        case MIM_MOREDATA: {
            // WinMM can use MIM_MOREDATA when a high-rate input source (for
            // example loopMIDI) has more short messages waiting.  It carries
            // exactly the same packed MIDI payload as MIM_DATA and must not be
            // discarded.  v13.4 ignored this notification entirely.
            const LONG count = InterlockedIncrement(&g_midiMoreDataCount);
            if (count <= 16 || (count & (count - 1)) == 0)
                Logf("WinMM MIDI-IN: MIM_MOREDATA #%ld handle=%p packed=%08lX time=%lu",
                     count, hmi, static_cast<unsigned long>(p1), static_cast<unsigned long>(p2));
            NativeMidiCaptureShort(static_cast<DWORD>(p1), static_cast<DWORD>(p2));
            break;
        }
#endif
        case MIM_ERROR:
            Logf("WinMM MIDI-IN: MIM_ERROR handle=%p packed=%08lX time=%lu", hmi,
                 static_cast<unsigned long>(p1), static_cast<unsigned long>(p2));
            break;
        case MIM_LONGERROR:
            Logf("WinMM MIDI-IN: MIM_LONGERROR handle=%p hdr=%p time=%lu", hmi,
                 reinterpret_cast<void*>(p1), static_cast<unsigned long>(p2));
            break;
        case MIM_LONGDATA: {
            auto* hdr = reinterpret_cast<MIDIHDR*>(p1);
            if (hdr && hdr->lpData) {
                const MMRESULT r = NativeMidiHandleLongData(reinterpret_cast<const BYTE*>(hdr->lpData),
                                                             hdr->dwBytesRecorded ? hdr->dwBytesRecorded : hdr->dwBufferLength,
                                                             static_cast<DWORD>(p2));
                Logf("WinMM MIDI-IN: long/SysEx data handle=%p bytes=%lu result=%u", hmi,
                     static_cast<unsigned long>(hdr->dwBytesRecorded ? hdr->dwBytesRecorded : hdr->dwBufferLength),
                     static_cast<unsigned>(r));
            }
            break;
        }
        default:
            break;
    }
}

static UINT WINAPI HookMidiOutGetNumDevs() {
    UINT real = RealMidiOutGetNumDevs ? RealMidiOutGetNumDevs() : 0;
    Logf("WinMM MIDI: midiOutGetNumDevs real=%u + Reality", real);
    return real + 1;
}

static MMRESULT WINAPI HookMidiOutGetDevCapsA(UINT_PTR id, LPMIDIOUTCAPSA caps, UINT cb) {
    const UINT synthId = RealityMidiDeviceId();
    if (id == synthId || (g_realityMidiOut && reinterpret_cast<HMIDIOUT>(id) == g_realityMidiOut)) {
        if (!caps || cb == 0) return MMSYSERR_INVALPARAM;
        MIDIOUTCAPSA out{};
        out.wMid = 0xFFFF;
        out.wPid = 0x0001;
        out.vDriverVersion = 0x0403;
        strncpy_s(out.szPname, MAXPNAMELEN, "Reality", _TRUNCATE);
        out.wTechnology = MOD_SYNTH;
        out.wVoices = 64;
        out.wNotes = 64;
        out.wChannelMask = 0xFFFF;
        out.dwSupport = MIDICAPS_VOLUME;
        std::memcpy(caps, &out, cb < sizeof(out) ? cb : sizeof(out));
        Logf("WinMM MIDI: caps synthetic id=%u name=Reality (exact legacy product name)", synthId);
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutGetDevCapsA ? RealMidiOutGetDevCapsA(id, caps, cb) : MMSYSERR_NODRIVER;
}

static MMRESULT WINAPI HookMidiOutOpen(LPHMIDIOUT out, UINT id, DWORD_PTR callback,
                                       DWORD_PTR instance, DWORD flags) {
    const UINT synthId = RealityMidiDeviceId();
    if (id == synthId) {
        if (!out) return MMSYSERR_INVALPARAM;
        if (g_realityMidiOut) {
            CloseHandle(reinterpret_cast<HANDLE>(g_realityMidiOut));
            g_realityMidiOut = nullptr;
        }
        HANDLE h = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!h) return MMSYSERR_NOMEM;
        g_realityMidiOut = reinterpret_cast<HMIDIOUT>(h);
        if (!NativeMidiOpenDevice(0, callback, instance, flags)) {
            Logf("WinMM MIDI: SSYNMIDI32 device open failed error=%lu", GetLastError());
            CloseHandle(h); g_realityMidiOut = nullptr;
            return MMSYSERR_ERROR;
        }
        *out = g_realityMidiOut;
        Logf("WinMM MIDI: opened synthetic Reality id=%u handle=%p callback=%p flags=%08lX; engine lifecycle started",
             id, g_realityMidiOut, reinterpret_cast<void*>(callback), flags);
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutOpen ? RealMidiOutOpen(out, id, callback, instance, flags) : MMSYSERR_NODRIVER;
}

static MMRESULT WINAPI HookMidiOutClose(HMIDIOUT h) {
    if (IsRealityMidiHandle(h)) {
        Logf("WinMM MIDI: closed synthetic Reality handle=%p", h);
        if (g_connectedMidi) g_connectedMidi = nullptr;
        NativeMidiCloseDevice(0);
        CloseHandle(reinterpret_cast<HANDLE>(h));
        g_realityMidiOut = nullptr;
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutClose ? RealMidiOutClose(h) : MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiOutShortMsg(HMIDIOUT h, DWORD packedMessage) {
    if (IsRealityMidiHandle(h)) {
        Logf("WinMM MIDI: synthetic short message handle=%p msg=%08lX -> SSYNENG event ring",
             h, static_cast<unsigned long>(packedMessage));
        NativeMidiCaptureShort(packedMessage, timeGetTime());
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutShortMsg ? RealMidiOutShortMsg(h, packedMessage) : MMSYSERR_INVALHANDLE;
}

static bool IsGmOrGsReset(const BYTE* p, DWORD n) {
    if (!p || n < 6) return false;
    // Universal Non-Realtime: F0 7E <device> 09 01 ... F7
    if (n >= 6 && p[0]==0xF0 && p[1]==0x7E && p[3]==0x09 && p[4]==0x01) return true;
    // Roland GS reset prefix: F0 41 10 42 12 40 00 7F 00 ... F7
    if (n >= 10 && p[0]==0xF0 && p[1]==0x41 && p[2]==0x10 && p[3]==0x42 &&
        p[4]==0x12 && p[5]==0x40 && p[6]==0x00 && p[7]==0x7F && p[8]==0x00) return true;
    return false;
}

static void ForwardLongMidiStream(const BYTE* p, DWORD n) {
    BYTE running=0; DWORD i=0;
    while (i<n) {
        BYTE b=p[i++];
        if (b>=0xF8) { NativeMidiCaptureShort(b,timeGetTime()); continue; }
        if (b==0xF0) { while (i<n && p[i++]!=0xF7) {} running=0; continue; }
        if (b&0x80) running=b; else { if (!running) continue; --i; b=running; }
        const BYTE hi=b&0xF0;
        if (hi<0x80 || hi>0xE0) { running=0; continue; }
        const DWORD need=(hi==0xC0 || hi==0xD0)?1u:2u;
        if (i+need>n) break;
        BYTE d1=p[i++]&0x7F, d2=need==2?(p[i++]&0x7F):0;
        NativeMidiCaptureShort(static_cast<DWORD>(b)|(static_cast<DWORD>(d1)<<8)|(static_cast<DWORD>(d2)<<16),timeGetTime());
    }
}

static MMRESULT WINAPI HookMidiOutLongMsg(HMIDIOUT h, LPMIDIHDR hdr, UINT cb) {
    if (IsRealityMidiHandle(h)) {
        if (!hdr || cb < sizeof(MIDIHDR) || !hdr->lpData) return MMSYSERR_INVALPARAM;
        const BYTE* p=reinterpret_cast<const BYTE*>(hdr->lpData);
        const DWORD n=hdr->dwBufferLength;
        const MMRESULT r = NativeMidiHandleLongData(p, n, timeGetTime());
        Logf("WinMM MIDI: SSYNMIDI32 long-message path bytes=%lu result=%u",n,static_cast<unsigned>(r));
        return r;
    }
    return RealMidiOutLongMsg?RealMidiOutLongMsg(h,hdr,cb):MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiOutReset(HMIDIOUT h) {
    if (IsRealityMidiHandle(h)) {
        const bool ok = NativeMidiReset(false);
        Logf("WinMM MIDI: reset synthetic Reality handle=%p -> original service 0A result=%u", h, ok?1u:0u);
        return ok ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    }
    return RealMidiOutReset ? RealMidiOutReset(h) : MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiOutGetVolume(HMIDIOUT h, LPDWORD volume) {
    if (IsRealityMidiHandle(h)) {
        if (!volume) return MMSYSERR_INVALPARAM;
        *volume = NativeMidiGetVolume();
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutGetVolume ? RealMidiOutGetVolume(h, volume) : MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiOutSetVolume(HMIDIOUT h, DWORD volume) {
    if (IsRealityMidiHandle(h)) {
        NativeMidiSetVolume(volume);
        Logf("WinMM MIDI: synthetic volume handle=%p value=%08lX", h,
             static_cast<unsigned long>(volume));
        return MMSYSERR_NOERROR;
    }
    return RealMidiOutSetVolume ? RealMidiOutSetVolume(h, volume) : MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiConnect(HMIDI hmi, HMIDIOUT hmo, LPVOID reserved) {
    if (IsRealityMidiHandle(hmo)) {
        g_connectedMidi = hmi;
        Logf("WinMM MIDI: midiConnect input=%p -> synthetic Reality output=%p; user-mode input callback already owns routing", hmi, hmo);
        return MMSYSERR_NOERROR;
    }
    return RealMidiConnect ? RealMidiConnect(hmi, hmo, reserved) : MMSYSERR_INVALHANDLE;
}

static MMRESULT WINAPI HookMidiDisconnect(HMIDI hmi, HMIDIOUT hmo, LPVOID reserved) {
    if (IsRealityMidiHandle(hmo)) {
        Logf("WinMM MIDI: midiDisconnect input=%p -> synthetic Reality output=%p", hmi, hmo);
        if (g_connectedMidi == hmi) g_connectedMidi = nullptr;
        return MMSYSERR_NOERROR;
    }
    return RealMidiDisconnect ? RealMidiDisconnect(hmi, hmo, reserved) : MMSYSERR_INVALHANDLE;
}

static UINT WINAPI HookMidiInGetNumDevs() {
    UINT n = RealMidiInGetNumDevs ? RealMidiInGetNumDevs() : 0;
    Logf("WinMM MIDI-IN: midiInGetNumDevs=%u", n);
    return n;
}

static MMRESULT WINAPI HookMidiInGetDevCapsA(UINT_PTR id, LPMIDIINCAPSA caps, UINT cb) {
    MMRESULT r = RealMidiInGetDevCapsA ? RealMidiInGetDevCapsA(id, caps, cb) : MMSYSERR_NODRIVER;
    if (r == MMSYSERR_NOERROR && caps)
        Logf("WinMM MIDI-IN: caps id=%lu name=%s mid=%u pid=%u", static_cast<unsigned long>(id),
             caps->szPname, static_cast<unsigned>(caps->wMid), static_cast<unsigned>(caps->wPid));
    else
        Logf("WinMM MIDI-IN: caps id=%lu failed=%u", static_cast<unsigned long>(id), static_cast<unsigned>(r));
    return r;
}

static MMRESULT WINAPI HookMidiInOpen(LPHMIDIIN out, UINT id, DWORD_PTR callback,
                                      DWORD_PTR instance, DWORD flags) {
    if (!RealMidiInOpen) return MMSYSERR_NODRIVER;
    // Reality 1.5 opens its MIDI input with CALLBACK_NULL and then depended on
    // midiConnect to route that input into SSYNMIDI.DRV.  A process-local fake
    // MIDI output cannot participate in the kernel's WinMM routing graph, so
    // attach our callback at the input source instead.  The returned HMIDIIN is
    // still the genuine Windows input handle and Reality can Start/Stop/Close it.
    const DWORD callbackType = flags & CALLBACK_TYPEMASK;
    if (callback == 0 && callbackType == CALLBACK_NULL) {
        // Preserve every non-callback flag supplied by Reality.  Only replace
        // the callback-type bits; dropping the other bits can subtly change how
        // a real WinMM/loopMIDI driver delivers data.
        const DWORD bridgeFlags = (flags & ~CALLBACK_TYPEMASK) | CALLBACK_FUNCTION;
        MMRESULT r = RealMidiInOpen(out, id, reinterpret_cast<DWORD_PTR>(&BridgeMidiInCallback),
                                    0, bridgeFlags);
        Logf("WinMM MIDI-IN: open Reality id=%u CALLBACK_NULL -> bridge callback flags=%08lX result=%u handle=%p",
             id, static_cast<unsigned long>(bridgeFlags), static_cast<unsigned>(r), out ? *out : nullptr);
        return r;
    }
    MMRESULT r = RealMidiInOpen(out, id, callback, instance, flags);
    Logf("WinMM MIDI-IN: pass-through open id=%u callback=%p flags=%08lX result=%u handle=%p",
         id, reinterpret_cast<void*>(callback), static_cast<unsigned long>(flags),
         static_cast<unsigned>(r), out ? *out : nullptr);
    return r;
}

static MMRESULT WINAPI HookMidiInStart(HMIDIIN h) {
    Logf("WinMM MIDI-IN: start handle=%p", h);
    MMRESULT r = RealMidiInStart ? RealMidiInStart(h) : MMSYSERR_INVALHANDLE;
    Logf("WinMM MIDI-IN: start result=%u", static_cast<unsigned>(r));
    return r;
}
static MMRESULT WINAPI HookMidiInStop(HMIDIIN h) {
    Logf("WinMM MIDI-IN: stop handle=%p", h);
    MMRESULT r = RealMidiInStop ? RealMidiInStop(h) : MMSYSERR_INVALHANDLE;
    Logf("WinMM MIDI-IN: stop result=%u", static_cast<unsigned>(r));
    return r;
}
static MMRESULT WINAPI HookMidiInClose(HMIDIIN h) {
    Logf("WinMM MIDI-IN: close handle=%p", h);
    MMRESULT r = RealMidiInClose ? RealMidiInClose(h) : MMSYSERR_INVALHANDLE;
    Logf("WinMM MIDI-IN: close result=%u", static_cast<unsigned>(r));
    return r;
}

FARPROC WrapRealityMidiWinmmProc(const char* name, FARPROC realProc) {
    if (!name || (reinterpret_cast<ULONG_PTR>(name) >> 16) == 0) return realProc;
#define MIDI_WRAP(n, f) if (_stricmp(name, n) == 0) return reinterpret_cast<FARPROC>(&f)
    MIDI_WRAP("midiOutGetNumDevs", HookMidiOutGetNumDevs);
    MIDI_WRAP("midiOutGetDevCapsA", HookMidiOutGetDevCapsA);
    MIDI_WRAP("midiOutOpen", HookMidiOutOpen);
    MIDI_WRAP("midiOutClose", HookMidiOutClose);
    MIDI_WRAP("midiOutShortMsg", HookMidiOutShortMsg);
    MIDI_WRAP("midiOutLongMsg", HookMidiOutLongMsg);
    MIDI_WRAP("midiOutReset", HookMidiOutReset);
    MIDI_WRAP("midiOutGetVolume", HookMidiOutGetVolume);
    MIDI_WRAP("midiOutSetVolume", HookMidiOutSetVolume);
    MIDI_WRAP("midiConnect", HookMidiConnect);
    MIDI_WRAP("midiDisconnect", HookMidiDisconnect);
    MIDI_WRAP("midiInGetNumDevs", HookMidiInGetNumDevs);
    MIDI_WRAP("midiInGetDevCapsA", HookMidiInGetDevCapsA);
    MIDI_WRAP("midiInOpen", HookMidiInOpen);
    MIDI_WRAP("midiInStart", HookMidiInStart);
    MIDI_WRAP("midiInStop", HookMidiInStop);
    MIDI_WRAP("midiInClose", HookMidiInClose);
#undef MIDI_WRAP
    return realProc;
}

bool PatchRealityMidiWinmm(HMODULE synMid) {
    if (!synMid) return false;
    Logf("SynMid WinMM MIDI patch begin base=%p (loader-lock-safe: IAT only)", synMid);
    void* old = nullptr;
#define PATCH_MM(sym, hook, realvar, okvar) \
    old=nullptr; bool okvar=PatchImport(synMid,"WINMM.dll",sym,(void*)&hook,&old); \
    if(okvar && old) realvar=reinterpret_cast<decltype(realvar)>(old); \
    Logf("SynMid WinMM patch %s=%d", sym, okvar)
    PATCH_MM("midiOutGetNumDevs", HookMidiOutGetNumDevs, RealMidiOutGetNumDevs, a);
    PATCH_MM("midiOutGetDevCapsA", HookMidiOutGetDevCapsA, RealMidiOutGetDevCapsA, b);
    PATCH_MM("midiOutOpen", HookMidiOutOpen, RealMidiOutOpen, c);
    PATCH_MM("midiOutClose", HookMidiOutClose, RealMidiOutClose, d);
    PATCH_MM("midiOutShortMsg", HookMidiOutShortMsg, RealMidiOutShortMsg, e);
    PATCH_MM("midiOutLongMsg", HookMidiOutLongMsg, RealMidiOutLongMsg, q);
    PATCH_MM("midiOutReset", HookMidiOutReset, RealMidiOutReset, f);
    PATCH_MM("midiOutGetVolume", HookMidiOutGetVolume, RealMidiOutGetVolume, g);
    PATCH_MM("midiOutSetVolume", HookMidiOutSetVolume, RealMidiOutSetVolume, h);
    PATCH_MM("midiConnect", HookMidiConnect, RealMidiConnect, i);
    PATCH_MM("midiDisconnect", HookMidiDisconnect, RealMidiDisconnect, j);
    PATCH_MM("midiInGetNumDevs", HookMidiInGetNumDevs, RealMidiInGetNumDevs, k);
    PATCH_MM("midiInGetDevCapsA", HookMidiInGetDevCapsA, RealMidiInGetDevCapsA, l);
    PATCH_MM("midiInOpen", HookMidiInOpen, RealMidiInOpen, m);
    PATCH_MM("midiInStart", HookMidiInStart, RealMidiInStart, n);
    PATCH_MM("midiInStop", HookMidiInStop, RealMidiInStop, o);
    PATCH_MM("midiInClose", HookMidiInClose, RealMidiInClose, p);
#undef PATCH_MM
    Logf("SynMid WinMM MIDI patch complete out-core=%d%d%d%d out-data=%d%d%d%d%d conn=%d%d in=%d%d%d%d%d%d",
         a,b,c,d,e,q,f,g,h,i,j,k,l,m,n,o,p);
    // Old SynMid does not import every data-path function (the v4 trace showed
    // short/long/reset as absent IAT entries).  That is not a failure: dynamic
    // resolution is covered by WrapRealityMidiWinmmProc and the SeerCtl32 bit92
    // path handles the driver's direct short-MIDI transport.  Require only the
    // device-open/routing/input core that is actually present in this module.
    return a && b && c && d && i && j && k && l && m && n && o && p;
}
