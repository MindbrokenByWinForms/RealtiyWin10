#include "virtual_registry.h"
#include "iathook.h"
#include "log.h"
#include <cstring>
#include <string>

static decltype(&RegOpenKeyA) RealRegOpenKeyA = RegOpenKeyA;
static decltype(&RegOpenKeyExA) RealRegOpenKeyExA = RegOpenKeyExA;
static decltype(&RegCreateKeyA) RealRegCreateKeyA = RegCreateKeyA;
static decltype(&RegCreateKeyExA) RealRegCreateKeyExA = RegCreateKeyExA;
static decltype(&RegQueryValueA) RealRegQueryValueA = RegQueryValueA;
static decltype(&RegQueryValueExA) RealRegQueryValueExA = RegQueryValueExA;
static decltype(&RegSetValueA) RealRegSetValueA = RegSetValueA;
static decltype(&RegSetValueExA) RealRegSetValueExA = RegSetValueExA;
static decltype(&RegDeleteValueA) RealRegDeleteValueA = RegDeleteValueA;
static decltype(&RegDeleteKeyA) RealRegDeleteKeyA = RegDeleteKeyA;
static decltype(&RegCloseKey) RealRegCloseKey = RegCloseKey;
static decltype(&GetPrivateProfileStringA) RealGetPrivateProfileStringA = GetPrivateProfileStringA;

enum class VirtualRoot : unsigned char { Classes, LocalMachine, CurrentUser, Unknown };

struct VirtualKey {
    bool active;
    VirtualRoot root;
    HKEY backing;
    char path[1024];
};

static SRWLOCK g_lock = SRWLOCK_INIT;
static VirtualKey g_keys[64] = {};
static HMODULE g_patchedModules[32] = {};
static std::string g_root;
static std::string g_rootSlash;
static std::string g_exe;
static std::string g_banksets;
static std::string g_magic;

static bool ForceAlwaysLockedMemory() {
    char value[32]{};
    const DWORD n = GetEnvironmentVariableA("REALITY_COMPAT_FORCE_ALWAYS_LOCKED", value, sizeof(value));
    if (!n || n >= sizeof(value)) return false;
    return _stricmp(value, "1") == 0 || _stricmp(value, "true") == 0 ||
           _stricmp(value, "yes") == 0 || _stricmp(value, "on") == 0;
}

static void OverrideLockOnDemandResult(LPDWORD type, LPBYTE data, LPDWORD dataBytes) {
    if (!dataBytes || !data) return;
    // Reality 1.5 normally stores this setting as the two-byte ANSI string
    // "0"/"1".  Also support REG_DWORD defensively for installations that
    // were migrated by later setup tools.
    if (type && *type == REG_DWORD && *dataBytes >= sizeof(DWORD)) {
        const DWORD zero = 0;
        std::memcpy(data, &zero, sizeof(zero));
        *dataBytes = sizeof(zero);
    } else if (*dataBytes >= 2) {
        data[0] = static_cast<BYTE>('0');
        data[1] = 0;
        *dataBytes = 2;
    }
}

static std::string Narrow(const std::wstring& value) {
    if (value.empty()) return {};
    const int needed = WideCharToMultiByte(CP_ACP, 0, value.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (needed <= 1) return {};
    std::string out(static_cast<size_t>(needed), '\0');
    WideCharToMultiByte(CP_ACP, 0, value.c_str(), -1, &out[0], needed, nullptr, nullptr);
    out.resize(static_cast<size_t>(needed - 1));
    return out;
}

static const char* RootName(VirtualRoot root) {
    switch (root) {
    case VirtualRoot::Classes: return "HKCR";
    case VirtualRoot::LocalMachine: return "HKLM";
    case VirtualRoot::CurrentUser: return "HKCU";
    default: return "HKEY?";
    }
}

static VirtualRoot DecodePredefinedRoot(HKEY key) {
    if (key == HKEY_CLASSES_ROOT) return VirtualRoot::Classes;
    if (key == HKEY_LOCAL_MACHINE) return VirtualRoot::LocalMachine;
    if (key == HKEY_CURRENT_USER) return VirtualRoot::CurrentUser;
    return VirtualRoot::Unknown;
}

static void NormalizePath(std::string& path) {
    for (char& c : path) if (c == '/') c = '\\';
    while (!path.empty() && path.front() == '\\') path.erase(path.begin());
    while (!path.empty() && path.back() == '\\') path.pop_back();
    for (size_t i = 1; i < path.size();) {
        if (path[i] == '\\' && path[i - 1] == '\\') path.erase(i, 1);
        else ++i;
    }
}

static std::string JoinPath(const char* parent, LPCSTR child) {
    std::string out = parent ? parent : "";
    if (child && *child) {
        if (!out.empty() && out.back() != '\\') out.push_back('\\');
        out += child;
    }
    NormalizePath(out);
    return out;
}

static bool Same(const std::string& a, const char* b) {
    return b && _stricmp(a.c_str(), b) == 0;
}

static bool IsSameOrAncestor(const std::string& possibleParent, const char* child) {
    if (!child) return false;
    const size_t n = possibleParent.size();
    const size_t childLength = std::strlen(child);
    if (n > childLength) return false;
    return _strnicmp(possibleParent.c_str(), child, n) == 0 &&
           (child[n] == '\0' || (n != 0 && child[n] == '\\'));
}

static bool IsVirtualNamespace(VirtualRoot root, const std::string& path) {
    static const char* const classKeys[] = {
        "SeerSystems\\PathFromCustEngCode",
        "SeerSystems\\CustEngCodeFromPath",
        "SeerSystems\\BanksetsPathFromCustEngCode",
        "SeerSystems\\InstalledApps\\Reality",
    };
    static const char* const machineKeys[] = {
        "Software\\Seer Systems, Inc.\\Synthesis Engine",
        "Software\\Seer Systems, Inc.\\SynthEngine",
    };
    const char* const* keys = nullptr;
    size_t count = 0;
    if (root == VirtualRoot::Classes) {
        keys = classKeys;
        count = sizeof(classKeys) / sizeof(classKeys[0]);
    } else if (root == VirtualRoot::LocalMachine) {
        keys = machineKeys;
        count = sizeof(machineKeys) / sizeof(machineKeys[0]);
    }
    for (size_t i = 0; i < count; ++i) {
        if (IsSameOrAncestor(path, keys[i])) return true;
    }
    return false;
}

static VirtualKey* AsVirtualKey(HKEY key) {
    const ULONG_PTR address = reinterpret_cast<ULONG_PTR>(key);
    const ULONG_PTR first = reinterpret_cast<ULONG_PTR>(&g_keys[0]);
    const ULONG_PTR end = reinterpret_cast<ULONG_PTR>(&g_keys[64]);
    if (address < first || address >= end || ((address - first) % sizeof(VirtualKey)) != 0)
        return nullptr;
    auto* candidate = reinterpret_cast<VirtualKey*>(key);
    return candidate->active ? candidate : nullptr;
}

static VirtualKey* AllocateKey(VirtualRoot root, const std::string& path, HKEY backing) {
    AcquireSRWLockExclusive(&g_lock);
    VirtualKey* result = nullptr;
    for (auto& slot : g_keys) {
        if (slot.active) continue;
        slot.root = root;
        slot.backing = backing;
        strncpy_s(slot.path, sizeof(slot.path), path.c_str(), _TRUNCATE);
        slot.active = true;
        result = &slot;
        break;
    }
    ReleaseSRWLockExclusive(&g_lock);
    return result;
}

static LSTATUS OpenVirtualKey(HKEY key, LPCSTR subkey, REGSAM access, PHKEY result,
                              const char* api) {
    if (!result) return ERROR_INVALID_PARAMETER;
    *result = nullptr;

    VirtualRoot root = DecodePredefinedRoot(key);
    VirtualKey* parent = nullptr;
    std::string path;
    HKEY backingParent = nullptr;
    if (root != VirtualRoot::Unknown) {
        path = JoinPath(nullptr, subkey);
        backingParent = key;
    } else if ((parent = AsVirtualKey(key)) != nullptr) {
        root = parent->root;
        path = JoinPath(parent->path, subkey);
        backingParent = parent->backing;
    } else {
        return ERROR_CALL_NOT_IMPLEMENTED;
    }

    if (!IsVirtualNamespace(root, path)) return ERROR_CALL_NOT_IMPLEMENTED;

    HKEY backing = nullptr;
    if (backingParent && RealRegOpenKeyExA) {
        // A backing handle is used only to preserve unrelated existing values.
        // Always open it read-only even when legacy code requested write access.
        RealRegOpenKeyExA(backingParent, subkey && *subkey ? subkey : "", 0, KEY_READ, &backing);
    }
    VirtualKey* fake = AllocateKey(root, path, backing);
    if (!fake) {
        if (backing && RealRegCloseKey) RealRegCloseKey(backing);
        Logf("VirtualRegistry: %s %s\\%s -> ERROR_TOO_MANY_OPEN_FILES",
             api, RootName(root), path.c_str());
        return ERROR_TOO_MANY_OPEN_FILES;
    }
    *result = reinterpret_cast<HKEY>(fake);
    Logf("VirtualRegistry: %s %s\\%s -> fake=%p realBacking=%p (read-only, no registry write)",
         api, RootName(root), path.c_str(), fake, backing);
    return ERROR_SUCCESS;
}

static LSTATUS WINAPI HookRegOpenKeyExA(HKEY key, LPCSTR subkey, DWORD options,
                                        REGSAM access, PHKEY result) {
    const LSTATUS vr = OpenVirtualKey(key, subkey, access, result, "RegOpenKeyExA");
    if (vr != ERROR_CALL_NOT_IMPLEMENTED) return vr;
    const LSTATUS r = RealRegOpenKeyExA ?
        RealRegOpenKeyExA(key, subkey, options, access, result) : ERROR_PROC_NOT_FOUND;
    Logf("RegistryTrace: RegOpenKeyExA root=%p subkey=%s access=%08lX -> %ld handle=%p",
         key, subkey ? subkey : "(null)", access, r, result ? *result : nullptr);
    return r;
}

static LSTATUS WINAPI HookRegOpenKeyA(HKEY key, LPCSTR subkey, PHKEY result) {
    const LSTATUS vr = OpenVirtualKey(key, subkey, KEY_READ, result, "RegOpenKeyA");
    if (vr != ERROR_CALL_NOT_IMPLEMENTED) return vr;
    const LSTATUS r = RealRegOpenKeyA ? RealRegOpenKeyA(key, subkey, result) : ERROR_PROC_NOT_FOUND;
    Logf("RegistryTrace: RegOpenKeyA root=%p subkey=%s -> %ld handle=%p",
         key, subkey ? subkey : "(null)", r, result ? *result : nullptr);
    return r;
}

static LSTATUS WINAPI HookRegCreateKeyA(HKEY key, LPCSTR subkey, PHKEY result) {
    const LSTATUS vr = OpenVirtualKey(key, subkey, KEY_READ, result, "RegCreateKeyA");
    if (vr != ERROR_CALL_NOT_IMPLEMENTED) {
        Logf("VirtualRegistry: RegCreateKeyA request was satisfied in process; real create suppressed");
        return vr;
    }
    return RealRegCreateKeyA ? RealRegCreateKeyA(key, subkey, result) : ERROR_PROC_NOT_FOUND;
}

static LSTATUS WINAPI HookRegCreateKeyExA(HKEY key, LPCSTR subkey, DWORD reserved,
                                          LPSTR keyClass, DWORD options, REGSAM access,
                                          LPSECURITY_ATTRIBUTES security, PHKEY result,
                                          LPDWORD disposition) {
    const LSTATUS vr = OpenVirtualKey(key, subkey, access, result, "RegCreateKeyExA");
    if (vr != ERROR_CALL_NOT_IMPLEMENTED) {
        if (disposition) *disposition = REG_OPENED_EXISTING_KEY;
        Logf("VirtualRegistry: RegCreateKeyExA request was satisfied in process; real create suppressed");
        return vr;
    }
    return RealRegCreateKeyExA ?
        RealRegCreateKeyExA(key, subkey, reserved, keyClass, options, access,
                            security, result, disposition) : ERROR_PROC_NOT_FOUND;
}

static bool LookupVirtualValue(const VirtualKey* key, LPCSTR valueName, std::string& value) {
    value.clear();
    const std::string path = key ? key->path : "";
    const char* name = valueName ? valueName : "";
    if (key && key->root == VirtualRoot::Classes) {
        if (Same(path, "SeerSystems\\PathFromCustEngCode") && _stricmp(name, "SSYN") == 0)
            value = g_root;
        else if (Same(path, "SeerSystems\\CustEngCodeFromPath") &&
                 (_stricmp(name, g_root.c_str()) == 0 ||
                  _stricmp(name, g_rootSlash.c_str()) == 0 ||
                  _stricmp(name, g_exe.c_str()) == 0))
            value = "SSYN";
        else if (Same(path, "SeerSystems\\BanksetsPathFromCustEngCode") &&
                 _stricmp(name, "SSYN") == 0)
            value = g_banksets;
        else if (Same(path, "SeerSystems\\InstalledApps\\Reality") &&
                 _stricmp(name, "Magic") == 0)
            value = g_magic;
    } else if (key && key->root == VirtualRoot::LocalMachine) {
        if ((Same(path, "Software\\Seer Systems, Inc.\\Synthesis Engine") ||
             Same(path, "Software\\Seer Systems, Inc.\\SynthEngine")) &&
            _stricmp(name, "Version") == 0)
            value = "1.5.5";
    }
    return !value.empty();
}

static LSTATUS CopyVirtualString(const std::string& value, LPDWORD type,
                                 LPBYTE data, LPDWORD dataBytes) {
    if (type) *type = REG_SZ;
    if (!dataBytes) return data ? ERROR_INVALID_PARAMETER : ERROR_SUCCESS;
    const DWORD required = static_cast<DWORD>(value.size() + 1);
    if (!data) {
        *dataBytes = required;
        return ERROR_SUCCESS;
    }
    if (*dataBytes < required) {
        *dataBytes = required;
        return ERROR_MORE_DATA;
    }
    std::memcpy(data, value.c_str(), required);
    *dataBytes = required;
    return ERROR_SUCCESS;
}

static LSTATUS WINAPI HookRegQueryValueExA(HKEY key, LPCSTR valueName, LPDWORD reserved,
                                           LPDWORD type, LPBYTE data, LPDWORD dataBytes) {
    // Reality 1.5 stores its user-selected bankset directory in a normal HKCU
    // value named "Banksets".  Old installations commonly point this at a
    // historical \Banks directory even when the actual files were restored to
    // \Banksets.  Because this compatibility layer has already discovered the
    // directory containing the real *.SeerBankset files, expose that directory
    // for this one legacy value regardless of which Reality settings key owns
    // the handle.  This is process-local/read-only and does not alter the real
    // registry.
    if (valueName && _stricmp(valueName, "Banksets") == 0 && !g_banksets.empty()) {
        const LSTATUS r = CopyVirtualString(g_banksets, type, data, dataBytes);
        Logf("VirtualRegistry: override legacy Banksets value key=%p -> %ld bytes=%lu data=%s",
             key, r, dataBytes ? *dataBytes : 0ul, g_banksets.c_str());
        return r;
    }

    VirtualKey* fake = AsVirtualKey(key);
    if (fake) {
        std::string value;
        if (LookupVirtualValue(fake, valueName, value)) {
            const LSTATUS r = CopyVirtualString(value, type, data, dataBytes);
            Logf("VirtualRegistry: RegQueryValueExA %s\\%s value=%s -> %ld type=REG_SZ bytes=%lu data=%s",
                 RootName(fake->root), fake->path, valueName ? valueName : "(default)", r,
                 dataBytes ? *dataBytes : 0ul,
                 Same(fake->path, "SeerSystems\\InstalledApps\\Reality") ? "<portable-marker-hidden>" : value.c_str());
            return r;
        }
        if (fake->backing && RealRegQueryValueExA) {
            const LSTATUS r = RealRegQueryValueExA(fake->backing, valueName, reserved, type, data, dataBytes);
            Logf("RegistryTrace: virtual-key real fallback %s\\%s value=%s -> %ld bytes=%lu",
                 RootName(fake->root), fake->path, valueName ? valueName : "(default)", r,
                 dataBytes ? *dataBytes : 0ul);
            return r;
        }
        Logf("VirtualRegistry: RegQueryValueExA %s\\%s value=%s -> ERROR_FILE_NOT_FOUND",
             RootName(fake->root), fake->path, valueName ? valueName : "(default)");
        return ERROR_FILE_NOT_FOUND;
    }
    const LSTATUS r = RealRegQueryValueExA ?
        RealRegQueryValueExA(key, valueName, reserved, type, data, dataBytes) : ERROR_PROC_NOT_FOUND;
    if (r == ERROR_SUCCESS && valueName && _stricmp(valueName, "LockOnDemand") == 0 &&
        ForceAlwaysLockedMemory()) {
        OverrideLockOnDemandResult(type, data, dataBytes);
        Logf("VirtualRegistry: compatibility override LockOnDemand=0 (Always/resident) key=%p type=%lu bytes=%lu env=REALITY_COMPAT_FORCE_ALWAYS_LOCKED",
             key, type ? *type : 0ul, dataBytes ? *dataBytes : 0ul);
        return r;
    }
    Logf("RegistryTrace: RegQueryValueExA key=%p value=%s -> %ld type=%lu bytes=%lu",
         key, valueName ? valueName : "(default)", r, type ? *type : 0ul,
         dataBytes ? *dataBytes : 0ul);
    return r;
}

static LSTATUS WINAPI HookRegQueryValueA(HKEY key, LPCSTR subkey, LPSTR data, PLONG dataBytes) {
    VirtualKey* fake = AsVirtualKey(key);
    if (fake && (!subkey || !*subkey)) {
        if (fake->backing && RealRegQueryValueA) {
            const LSTATUS r = RealRegQueryValueA(fake->backing, subkey, data, dataBytes);
            Logf("RegistryTrace: RegQueryValueA virtual-key real fallback %s\\%s default -> %ld bytes=%ld",
                 RootName(fake->root), fake->path, r, dataBytes ? *dataBytes : 0l);
            return r;
        }
        Logf("VirtualRegistry: RegQueryValueA %s\\%s default -> ERROR_FILE_NOT_FOUND",
             RootName(fake->root), fake->path);
        return ERROR_FILE_NOT_FOUND;
    }
    const LSTATUS r = RealRegQueryValueA ?
        RealRegQueryValueA(key, subkey, data, dataBytes) : ERROR_PROC_NOT_FOUND;
    Logf("RegistryTrace: RegQueryValueA key=%p subkey=%s -> %ld bytes=%ld",
         key, subkey ? subkey : "(null)", r, dataBytes ? *dataBytes : 0l);
    return r;
}

static LSTATUS WINAPI HookRegSetValueA(HKEY key, LPCSTR subkey, DWORD type,
                                       LPCSTR data, DWORD dataBytes) {
    VirtualKey* fake = AsVirtualKey(key);
    if (fake) {
        Logf("VirtualRegistry: RegSetValueA %s\\%s subkey=%s type=%lu bytes=%lu -> success (real write suppressed)",
             RootName(fake->root), fake->path, subkey ? subkey : "(default)", type, dataBytes);
        return ERROR_SUCCESS;
    }
    return RealRegSetValueA ? RealRegSetValueA(key, subkey, type, data, dataBytes) : ERROR_PROC_NOT_FOUND;
}

static LSTATUS WINAPI HookRegSetValueExA(HKEY key, LPCSTR valueName, DWORD reserved,
                                         DWORD type, const BYTE* data, DWORD dataBytes) {
    VirtualKey* fake = AsVirtualKey(key);
    if (fake) {
        Logf("VirtualRegistry: RegSetValueExA %s\\%s value=%s type=%lu bytes=%lu -> success (real write suppressed)",
             RootName(fake->root), fake->path, valueName ? valueName : "(default)", type, dataBytes);
        return ERROR_SUCCESS;
    }
    return RealRegSetValueExA ?
        RealRegSetValueExA(key, valueName, reserved, type, data, dataBytes) : ERROR_PROC_NOT_FOUND;
}

static LSTATUS WINAPI HookRegDeleteValueA(HKEY key, LPCSTR valueName) {
    VirtualKey* fake = AsVirtualKey(key);
    if (fake) {
        Logf("VirtualRegistry: RegDeleteValueA %s\\%s value=%s -> success (real delete suppressed)",
             RootName(fake->root), fake->path, valueName ? valueName : "(default)");
        return ERROR_SUCCESS;
    }
    return RealRegDeleteValueA ? RealRegDeleteValueA(key, valueName) : ERROR_PROC_NOT_FOUND;
}

static LSTATUS WINAPI HookRegDeleteKeyA(HKEY key, LPCSTR subkey) {
    VirtualRoot root = DecodePredefinedRoot(key);
    VirtualKey* fake = root == VirtualRoot::Unknown ? AsVirtualKey(key) : nullptr;
    std::string path;
    if (fake) {
        root = fake->root;
        path = JoinPath(fake->path, subkey);
    } else if (root != VirtualRoot::Unknown) {
        path = JoinPath(nullptr, subkey);
    }
    if (fake || (root != VirtualRoot::Unknown && IsVirtualNamespace(root, path))) {
        Logf("VirtualRegistry: RegDeleteKeyA %s\\%s -> success (real delete suppressed)",
             RootName(root), path.c_str());
        return ERROR_SUCCESS;
    }
    return RealRegDeleteKeyA ? RealRegDeleteKeyA(key, subkey) : ERROR_PROC_NOT_FOUND;
}

static LSTATUS WINAPI HookRegCloseKey(HKEY key) {
    VirtualKey* fake = AsVirtualKey(key);
    if (!fake) return RealRegCloseKey ? RealRegCloseKey(key) : ERROR_PROC_NOT_FOUND;
    HKEY backing = nullptr;
    AcquireSRWLockExclusive(&g_lock);
    if (fake->active) {
        backing = fake->backing;
        fake->active = false;
        fake->backing = nullptr;
        fake->path[0] = '\0';
    }
    ReleaseSRWLockExclusive(&g_lock);
    if (backing && RealRegCloseKey) RealRegCloseKey(backing);
    Logf("VirtualRegistry: RegCloseKey fake=%p -> success", key);
    return ERROR_SUCCESS;
}

static DWORD WINAPI HookGetPrivateProfileStringA(LPCSTR section, LPCSTR key, LPCSTR defaultValue,
                                                  LPSTR output, DWORD outputChars, LPCSTR filename) {
    if (section && key && _stricmp(section, "UserKey") == 0 && _stricmp(key, "Value") == 0) {
        if (!output || outputChars == 0) return 0;
        strncpy_s(output, outputChars, g_magic.c_str(), _TRUNCATE);
        const DWORD copied = static_cast<DWORD>(std::strlen(output));
        Logf("VirtualRegistry: GetPrivateProfileStringA [UserKey] Value file=%s -> portable marker length=%lu (no file/registry write)",
             filename ? filename : "(null)", static_cast<unsigned long>(copied));
        return copied;
    }
    return RealGetPrivateProfileStringA ?
        RealGetPrivateProfileStringA(section, key, defaultValue, output, outputChars, filename) : 0;
}

FARPROC WrapRealityRegistryProc(LPCSTR name, FARPROC proc) {
    if (!name || !proc || (reinterpret_cast<ULONG_PTR>(name) >> 16) == 0) return proc;
    if (_stricmp(name, "RegOpenKeyA") == 0) {
        RealRegOpenKeyA = reinterpret_cast<decltype(RealRegOpenKeyA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegOpenKeyA);
    }
    if (_stricmp(name, "RegOpenKeyExA") == 0) {
        RealRegOpenKeyExA = reinterpret_cast<decltype(RealRegOpenKeyExA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegOpenKeyExA);
    }
    if (_stricmp(name, "RegCreateKeyA") == 0) {
        RealRegCreateKeyA = reinterpret_cast<decltype(RealRegCreateKeyA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegCreateKeyA);
    }
    if (_stricmp(name, "RegCreateKeyExA") == 0) {
        RealRegCreateKeyExA = reinterpret_cast<decltype(RealRegCreateKeyExA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegCreateKeyExA);
    }
    if (_stricmp(name, "RegQueryValueA") == 0) {
        RealRegQueryValueA = reinterpret_cast<decltype(RealRegQueryValueA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegQueryValueA);
    }
    if (_stricmp(name, "RegQueryValueExA") == 0) {
        RealRegQueryValueExA = reinterpret_cast<decltype(RealRegQueryValueExA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegQueryValueExA);
    }
    if (_stricmp(name, "RegSetValueA") == 0) {
        RealRegSetValueA = reinterpret_cast<decltype(RealRegSetValueA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegSetValueA);
    }
    if (_stricmp(name, "RegSetValueExA") == 0) {
        RealRegSetValueExA = reinterpret_cast<decltype(RealRegSetValueExA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegSetValueExA);
    }
    if (_stricmp(name, "RegDeleteValueA") == 0) {
        RealRegDeleteValueA = reinterpret_cast<decltype(RealRegDeleteValueA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegDeleteValueA);
    }
    if (_stricmp(name, "RegDeleteKeyA") == 0) {
        RealRegDeleteKeyA = reinterpret_cast<decltype(RealRegDeleteKeyA)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegDeleteKeyA);
    }
    if (_stricmp(name, "RegCloseKey") == 0) {
        RealRegCloseKey = reinterpret_cast<decltype(RealRegCloseKey)>(proc);
        return reinterpret_cast<FARPROC>(&HookRegCloseKey);
    }
    if (_stricmp(name, "GetPrivateProfileStringA") == 0) {
        RealGetPrivateProfileStringA = reinterpret_cast<decltype(RealGetPrivateProfileStringA)>(proc);
        return reinterpret_cast<FARPROC>(&HookGetPrivateProfileStringA);
    }
    return proc;
}

static bool DirectoryExistsA(const std::string& path) {
    const DWORD attributes = GetFileAttributesA(path.c_str());
    return attributes != INVALID_FILE_ATTRIBUTES && (attributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

static bool DirectoryHasSeerBankset(const std::string& path) {
    if (!DirectoryExistsA(path)) return false;
    std::string pattern = path;
    if (!pattern.empty() && pattern.back() != '\\') pattern.push_back('\\');
    pattern += "*.SeerBankset";
    WIN32_FIND_DATAA fd{};
    HANDLE h = FindFirstFileA(pattern.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return false;
    bool found = false;
    do {
        if ((fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0) { found = true; break; }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return found;
}

void InitializeRealityVirtualRegistry(const std::wstring& realityRoot) {
    g_root = Narrow(realityRoot);
    NormalizePath(g_root);
    g_rootSlash = g_root;
    if (!g_rootSlash.empty()) g_rootSlash.push_back('\\');

    wchar_t exeW[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, exeW, MAX_PATH);
    g_exe = Narrow(exeW);

    std::string banksetSource = "fallback-root";
    char overridePath[MAX_PATH * 4] = {};
    const DWORD overrideLen = GetEnvironmentVariableA("REALITY_BANKSETS", overridePath,
                                                       static_cast<DWORD>(sizeof(overridePath)));
    if (overrideLen && overrideLen < sizeof(overridePath) && DirectoryExistsA(overridePath)) {
        g_banksets = overridePath;
        NormalizePath(g_banksets);
        banksetSource = "REALITY_BANKSETS";
    } else {
        const std::string candidates[] = {
            g_root + "\\Banksets",
            g_root + "\\Bankset",
            g_root + "\\Shared\\Banksets",
            g_root + "\\Reality\\Banksets",
            g_root + "\\Reality\\Bankset",
            g_root + "\\Reality",
            g_root,
        };
        g_banksets = g_root;
        for (const auto& candidate : candidates) {
            if (DirectoryHasSeerBankset(candidate)) {
                g_banksets = candidate;
                banksetSource = "contains-SeerBankset";
                break;
            }
        }
        if (banksetSource == "fallback-root") {
            for (const auto& candidate : candidates) {
                if (DirectoryExistsA(candidate) && _stricmp(candidate.c_str(), g_root.c_str()) != 0) {
                    g_banksets = candidate;
                    banksetSource = "existing-directory";
                    break;
                }
            }
        }
    }

    const std::string runDat = g_root + "\\run.dat";
    char marker[1024] = {};
    const DWORD n = RealGetPrivateProfileStringA ?
        RealGetPrivateProfileStringA("UserKey", "Value", "", marker,
                                     static_cast<DWORD>(sizeof(marker)), runDat.c_str()) : 0;
    g_magic = n && marker[0] ? std::string(marker, n) : "RealityWin10Port-SSYN-1.5.5";

    const bool hasBankset = DirectoryHasSeerBankset(g_banksets);
    Logf("VirtualRegistry: initialized root=%s banksets=%s banksetSource=%s hasSeerBankset=%u markerSource=%s markerLength=%lu mode=read-only/in-process",
         g_root.c_str(), g_banksets.c_str(), banksetSource.c_str(), hasBankset ? 1u : 0u,
         n && marker[0] ? "run.dat" : "portable-default",
         static_cast<unsigned long>(g_magic.size()));
    if (!hasBankset)
        Logf("VirtualRegistry: WARNING no *.SeerBankset found in selected bankset directory; set REALITY_BANKSETS to the folder containing GmOnly.SeerBankset or other Reality banksets");
}

static bool RememberPatchedModule(HMODULE module) {
    AcquireSRWLockExclusive(&g_lock);
    for (HMODULE existing : g_patchedModules) {
        if (existing == module) {
            ReleaseSRWLockExclusive(&g_lock);
            return false;
        }
    }
    for (HMODULE& slot : g_patchedModules) {
        if (!slot) {
            slot = module;
            ReleaseSRWLockExclusive(&g_lock);
            return true;
        }
    }
    ReleaseSRWLockExclusive(&g_lock);
    return false;
}

template <typename T>
static bool PatchOne(HMODULE module, const char* dll, const char* name, void* hook, T& real) {
    void* old = nullptr;
    const bool patched = PatchImport(module, dll, name, hook, &old);
    if (patched && old && old != hook) real = reinterpret_cast<T>(old);
    return patched;
}

bool PatchRealityVirtualRegistry(HMODULE module, const char* moduleName) {
    if (!module || !RememberPatchedModule(module)) return false;
    const bool a = PatchOne(module, "ADVAPI32.dll", "RegOpenKeyA",
                            reinterpret_cast<void*>(&HookRegOpenKeyA), RealRegOpenKeyA);
    const bool b = PatchOne(module, "ADVAPI32.dll", "RegOpenKeyExA",
                            reinterpret_cast<void*>(&HookRegOpenKeyExA), RealRegOpenKeyExA);
    const bool create = PatchOne(module, "ADVAPI32.dll", "RegCreateKeyA",
                                 reinterpret_cast<void*>(&HookRegCreateKeyA), RealRegCreateKeyA);
    const bool createEx = PatchOne(module, "ADVAPI32.dll", "RegCreateKeyExA",
                                   reinterpret_cast<void*>(&HookRegCreateKeyExA), RealRegCreateKeyExA);
    const bool c = PatchOne(module, "ADVAPI32.dll", "RegQueryValueA",
                            reinterpret_cast<void*>(&HookRegQueryValueA), RealRegQueryValueA);
    const bool d = PatchOne(module, "ADVAPI32.dll", "RegQueryValueExA",
                            reinterpret_cast<void*>(&HookRegQueryValueExA), RealRegQueryValueExA);
    const bool set = PatchOne(module, "ADVAPI32.dll", "RegSetValueA",
                              reinterpret_cast<void*>(&HookRegSetValueA), RealRegSetValueA);
    const bool setEx = PatchOne(module, "ADVAPI32.dll", "RegSetValueExA",
                                reinterpret_cast<void*>(&HookRegSetValueExA), RealRegSetValueExA);
    const bool delValue = PatchOne(module, "ADVAPI32.dll", "RegDeleteValueA",
                                   reinterpret_cast<void*>(&HookRegDeleteValueA), RealRegDeleteValueA);
    const bool delKey = PatchOne(module, "ADVAPI32.dll", "RegDeleteKeyA",
                                 reinterpret_cast<void*>(&HookRegDeleteKeyA), RealRegDeleteKeyA);
    const bool e = PatchOne(module, "ADVAPI32.dll", "RegCloseKey",
                            reinterpret_cast<void*>(&HookRegCloseKey), RealRegCloseKey);
    const bool f = PatchOne(module, "KERNEL32.dll", "GetPrivateProfileStringA",
                            reinterpret_cast<void*>(&HookGetPrivateProfileStringA), RealGetPrivateProfileStringA);
    Logf("VirtualRegistry: patched module=%s base=%p Open=%d OpenEx=%d Create=%d CreateEx=%d Query=%d QueryEx=%d Set=%d SetEx=%d DeleteValue=%d DeleteKey=%d Close=%d Profile=%d",
         moduleName ? moduleName : "(unknown)", module, a, b, create, createEx,
         c, d, set, setEx, delValue, delKey, e, f);
    return a || b || create || createEx || c || d || set || setEx ||
           delValue || delKey || e || f;
}
