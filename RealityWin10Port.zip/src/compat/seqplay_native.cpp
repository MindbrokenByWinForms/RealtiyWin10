#include "seqplay_native.h"
#include "native_midi.h"
#include "log.h"
#include <windows.h>
#include <mmsystem.h>
#include <commctrl.h>
#include <cstdio>
#include <cstdint>
#include <vector>
#include <mutex>
#include <algorithm>
#include <cstring>
#include <limits>
#include <new>
#include <memory>

namespace {

// Original SeqPlay returns this for successful control operations.
constexpr DWORD kSeqOk = 0x1068;

// SynHigh stores the DWORD returned by SetupSeq at object+0x30 and directly
// reads WORD [that_pointer] in its IsDone test. Keep the first word stable and
// readable. 0 means stopped/done, 1 means active.
struct SeqStatus {
    volatile WORD active = 0;
    WORD reserved0 = 0;
    DWORD positionMs = 0;
    DWORD tempo = 120;
    DWORD flags = 0;
    DWORD reserved[12] = {};
};

struct ScheduledMidiEvent {
    std::uint64_t usec = 0;
    DWORD message = 0;
};

struct SeqChannelUiState {
    BYTE program = 0;
    BYTE volume = 100;
    BYTE pan = 64;
    bool haveProgram = false;
    bool haveVolume = false;
    bool havePan = false;
};

struct UiControlCache {
    HWND program[16] = {};
    HWND volumeSlider[16] = {};
    HWND volumeEdit[16] = {};
    HWND panSlider[16] = {};
    HWND panEdit[16] = {};
    DWORD lastScanTick = 0;
    bool logged = false;
};

struct SeqState {
    SeqStatus status;
    std::vector<unsigned char> bytes;
    std::vector<ScheduledMidiEvent> events;
    DWORD setupWord0 = 0;
    DWORD setupWord1 = 0;
    DWORD durationMs = 0;
    LONG generation = 0;
    bool initialized = false;
    bool parsed = false;
    SeqChannelUiState ui[16];
};

SeqState g_seq;
std::mutex g_seqMutex;
std::mutex g_uiMutex;
UiControlCache g_ui;
HMODULE g_patchedModule = nullptr;

static bool SafeCopy(void* dst, const void* src, size_t n) {
    __try {
        std::memcpy(dst, src, n);
        return true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static bool SequenceUiMirrorEnabled() {
    char value[16] = {};
    const DWORD n = GetEnvironmentVariableA("REALITY_SEQ_UI_MIRROR", value, sizeof(value));
    if (!n || n >= sizeof(value)) return false; // v13.2: opt-in; do not fight manual patch selection
    return _stricmp(value, "0") != 0 && _stricmp(value, "false") != 0 &&
           _stricmp(value, "no") != 0 && _stricmp(value, "off") != 0;
}

static void ResetSequenceUiStateLocked() {
    for (auto& c : g_seq.ui) c = SeqChannelUiState{};
}

struct UiScanContext { DWORD pid; UiControlCache* cache; };
static BOOL CALLBACK ScanUiChild(HWND hwnd, LPARAM lp) {
    auto* ctx = reinterpret_cast<UiScanContext*>(lp);
    if (!ctx || !ctx->cache || !IsWindow(hwnd)) return TRUE;
    const int id = GetDlgCtrlID(hwnd);
    if (id >= 8200 && id < 8216) ctx->cache->program[id - 8200] = hwnd;
    else if (id >= 8300 && id < 8316) ctx->cache->volumeEdit[id - 8300] = hwnd;
    else if (id >= 8400 && id < 8416) ctx->cache->panEdit[id - 8400] = hwnd;
    else if (id >= 8500 && id < 8516) ctx->cache->volumeSlider[id - 8500] = hwnd;
    else if (id >= 8600 && id < 8616) ctx->cache->panSlider[id - 8600] = hwnd;
    return TRUE;
}
static BOOL CALLBACK ScanUiTop(HWND hwnd, LPARAM lp) {
    auto* ctx = reinterpret_cast<UiScanContext*>(lp);
    if (!ctx) return TRUE;
    DWORD pid = 0; GetWindowThreadProcessId(hwnd, &pid);
    if (pid == ctx->pid) EnumChildWindows(hwnd, ScanUiChild, lp);
    return TRUE;
}
static unsigned CountValid(const HWND* p) {
    unsigned n = 0;
    for (unsigned i=0;i<16;++i) if (p[i] && IsWindow(p[i])) ++n;
    return n;
}
static void RefreshUiControlCacheLocked(bool force) {
    const DWORD now = GetTickCount();
    if (!force && now - g_ui.lastScanTick < 500u &&
        (CountValid(g_ui.program) || CountValid(g_ui.volumeEdit) || CountValid(g_ui.panEdit))) return;
    UiControlCache fresh{};
    fresh.lastScanTick = now;
    UiScanContext ctx{GetCurrentProcessId(), &fresh};
    EnumWindows(ScanUiTop, reinterpret_cast<LPARAM>(&ctx));
    fresh.logged = g_ui.logged;
    g_ui = fresh;
    if (!g_ui.logged) {
        Logf("NativeSeqPlay: UI mirror controls program=%u volumeSlider=%u volumeEdit=%u panSlider=%u panEdit=%u",
             CountValid(g_ui.program), CountValid(g_ui.volumeSlider), CountValid(g_ui.volumeEdit),
             CountValid(g_ui.panSlider), CountValid(g_ui.panEdit));
        g_ui.logged = true;
    }
}
static void SendTimeout(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (!hwnd || !IsWindow(hwnd)) return;
    DWORD_PTR ignored = 0;
    SendMessageTimeoutA(hwnd, msg, w, l, SMTO_ABORTIFHUNG | SMTO_BLOCK, 20, &ignored);
}
static void SetTrackbarValue(HWND hwnd, int rawValue, bool pan) {
    if (!hwnd || !IsWindow(hwnd)) return;
    const LRESULT lo = SendMessageA(hwnd, TBM_GETRANGEMIN, 0, 0);
    const LRESULT hi = SendMessageA(hwnd, TBM_GETRANGEMAX, 0, 0);
    int value = rawValue;
    if (pan && lo < 0) value = rawValue - 64;
    value = std::max<int>(static_cast<int>(lo), std::min<int>(static_cast<int>(hi), value));
    SendTimeout(hwnd, TBM_SETPOS, TRUE, static_cast<LPARAM>(value));
}
static void SetEditNumber(HWND hwnd, int value) {
    if (!hwnd || !IsWindow(hwnd)) return;
    char text[24] = {};
    std::snprintf(text, sizeof(text), "%d", value);
    SendTimeout(hwnd, WM_SETTEXT, 0, reinterpret_cast<LPARAM>(text));
}
static void ApplySequenceUiChannel(unsigned ch, const SeqChannelUiState& state) {
    if (!SequenceUiMirrorEnabled() || ch >= 16) return;
    std::lock_guard<std::mutex> lock(g_uiMutex);
    bool invalid = false;
    if (state.haveProgram && (!g_ui.program[ch] || !IsWindow(g_ui.program[ch]))) invalid = true;
    if (state.haveVolume && ((!g_ui.volumeSlider[ch] || !IsWindow(g_ui.volumeSlider[ch])) ||
                             (!g_ui.volumeEdit[ch] || !IsWindow(g_ui.volumeEdit[ch])))) invalid = true;
    if (state.havePan && ((!g_ui.panSlider[ch] || !IsWindow(g_ui.panSlider[ch])) ||
                          (!g_ui.panEdit[ch] || !IsWindow(g_ui.panEdit[ch])))) invalid = true;
    RefreshUiControlCacheLocked(invalid);
    if (state.haveProgram && g_ui.program[ch] && IsWindow(g_ui.program[ch])) {
        DWORD_PTR count = 0;
        SendMessageTimeoutA(g_ui.program[ch], CB_GETCOUNT, 0, 0, SMTO_ABORTIFHUNG | SMTO_BLOCK, 20, &count);
        if (static_cast<int>(count) > static_cast<int>(state.program))
            SendTimeout(g_ui.program[ch], CB_SETCURSEL, state.program, 0);
    }
    if (state.haveVolume) {
        SetTrackbarValue(g_ui.volumeSlider[ch], state.volume, false);
        SetEditNumber(g_ui.volumeEdit[ch], state.volume);
    }
    if (state.havePan) {
        SetTrackbarValue(g_ui.panSlider[ch], state.pan, true);
        // Reality's pan edit uses the familiar -64..+63 presentation while
        // MIDI CC10 is 0..127; center 64 therefore displays as 0.
        SetEditNumber(g_ui.panEdit[ch], static_cast<int>(state.pan) - 64);
    }
}
static void MirrorSequenceMessage(DWORD message) {
    if (!SequenceUiMirrorEnabled()) return;
    const BYTE status = static_cast<BYTE>(message & 0xffu);
    if (status < 0x80u || status >= 0xF0u) return;
    const unsigned ch = status & 0x0Fu;
    const BYTE hi = status & 0xF0u;
    const BYTE d1 = static_cast<BYTE>((message >> 8) & 0x7fu);
    const BYTE d2 = static_cast<BYTE>((message >> 16) & 0x7fu);
    SeqChannelUiState snapshot{};
    bool changed = false;
    {
        std::lock_guard<std::mutex> lock(g_seqMutex);
        auto& st = g_seq.ui[ch];
        if (hi == 0xC0u) { st.program = d1; st.haveProgram = true; changed = true; }
        else if (hi == 0xB0u && d1 == 7u) { st.volume = d2; st.haveVolume = true; changed = true; }
        else if (hi == 0xB0u && d1 == 10u) { st.pan = d2; st.havePan = true; changed = true; }
        snapshot = st;
    }
    // UI application runs on a separate low-rate mirror thread so cross-thread
    // window messages never delay the MIDI scheduler itself.
    (void)changed;
}
static void MirrorAllSequenceUi() {
    if (!SequenceUiMirrorEnabled()) return;
    SeqChannelUiState snapshot[16];
    {
        std::lock_guard<std::mutex> lock(g_seqMutex);
        for (unsigned i=0;i<16;++i) snapshot[i] = g_seq.ui[i];
    }
    for (unsigned i=0;i<16;++i)
        if (snapshot[i].haveProgram || snapshot[i].haveVolume || snapshot[i].havePan)
            ApplySequenceUiChannel(i, snapshot[i]);
}

static std::uint16_t Be16(const unsigned char* p) {
    return static_cast<std::uint16_t>((static_cast<unsigned>(p[0]) << 8) | p[1]);
}
static std::uint32_t Be32(const unsigned char* p) {
    return (static_cast<std::uint32_t>(p[0]) << 24) |
           (static_cast<std::uint32_t>(p[1]) << 16) |
           (static_cast<std::uint32_t>(p[2]) << 8) |
           static_cast<std::uint32_t>(p[3]);
}

static bool ReadVlq(const unsigned char*& p, const unsigned char* end, std::uint32_t& value) {
    value = 0;
    for (unsigned i = 0; i < 4; ++i) {
        if (p >= end) return false;
        const unsigned char b = *p++;
        value = (value << 7) | (b & 0x7fu);
        if ((b & 0x80u) == 0) return true;
    }
    return false;
}

enum class ParseResult { Incomplete, Invalid, Complete };

struct RawMidiEvent {
    std::uint64_t tick = 0;
    std::uint64_t order = 0;
    DWORD message = 0;
};
struct TempoEvent {
    std::uint64_t tick = 0;
    std::uint64_t order = 0;
    std::uint32_t usecPerQuarter = 500000;
};
struct TimelineItem {
    std::uint64_t tick = 0;
    std::uint64_t order = 0;
    bool tempo = false;
    std::uint32_t value = 0; // tempo or packed MIDI
};

static ParseResult ParseSmf(const std::vector<unsigned char>& bytes,
                            std::vector<ScheduledMidiEvent>& scheduled,
                            DWORD& durationMs, unsigned& formatOut,
                            unsigned& tracksOut, unsigned& divisionOut) {
    scheduled.clear();
    durationMs = 0;
    formatOut = tracksOut = divisionOut = 0;
    if (bytes.size() < 14) return ParseResult::Incomplete;
    if (std::memcmp(bytes.data(), "MThd", 4) != 0) return ParseResult::Invalid;
    const std::uint32_t headerLen = Be32(bytes.data() + 4);
    if (headerLen < 6) return ParseResult::Invalid;
    if (bytes.size() < 8u + headerLen) return ParseResult::Incomplete;

    const unsigned format = Be16(bytes.data() + 8);
    const unsigned tracks = Be16(bytes.data() + 10);
    const unsigned division = Be16(bytes.data() + 12);
    if (tracks == 0 || format > 2) return ParseResult::Invalid;
    formatOut = format; tracksOut = tracks; divisionOut = division;

    size_t pos = 8u + headerLen;
    std::vector<std::pair<const unsigned char*, const unsigned char*>> trackRanges;
    trackRanges.reserve(tracks);
    for (unsigned t = 0; t < tracks; ++t) {
        if (pos + 8 > bytes.size()) return ParseResult::Incomplete;
        if (std::memcmp(bytes.data() + pos, "MTrk", 4) != 0) return ParseResult::Invalid;
        const std::uint32_t len = Be32(bytes.data() + pos + 4);
        pos += 8;
        if (static_cast<std::uint64_t>(pos) + len > bytes.size()) return ParseResult::Incomplete;
        trackRanges.push_back({bytes.data() + pos, bytes.data() + pos + len});
        pos += len;
    }

    std::vector<RawMidiEvent> midi;
    std::vector<TempoEvent> tempos;
    std::uint64_t order = 0;
    for (const auto& range : trackRanges) {
        const unsigned char* p = range.first;
        const unsigned char* end = range.second;
        std::uint64_t tick = 0;
        unsigned char running = 0;
        while (p < end) {
            std::uint32_t delta = 0;
            if (!ReadVlq(p, end, delta)) return ParseResult::Invalid;
            tick += delta;
            if (p >= end) return ParseResult::Invalid;

            unsigned char status = *p++;
            bool usedRunning = false;
            unsigned char firstData = 0;
            if (status < 0x80u) {
                if (running < 0x80u || running >= 0xF0u) return ParseResult::Invalid;
                usedRunning = true;
                firstData = status;
                status = running;
            } else if (status < 0xF0u) {
                running = status;
            } else {
                running = 0;
            }

            if (status == 0xFFu) {
                if (p >= end) return ParseResult::Invalid;
                const unsigned char type = *p++;
                std::uint32_t len = 0;
                if (!ReadVlq(p, end, len) || static_cast<std::uint64_t>(end - p) < len)
                    return ParseResult::Invalid;
                if (type == 0x51u && len == 3) {
                    const std::uint32_t us = (static_cast<std::uint32_t>(p[0]) << 16) |
                                             (static_cast<std::uint32_t>(p[1]) << 8) | p[2];
                    if (us) tempos.push_back({tick, order++, us});
                } else {
                    ++order;
                }
                p += len;
                if (type == 0x2Fu) break;
                continue;
            }
            if (status == 0xF0u || status == 0xF7u) {
                std::uint32_t len = 0;
                if (!ReadVlq(p, end, len) || static_cast<std::uint64_t>(end - p) < len)
                    return ParseResult::Invalid;
                p += len;
                ++order;
                continue;
            }
            if (status >= 0xF0u) {
                // Rare system-common/realtime bytes in an SMF. Consume their
                // defined payload and ignore them; channel voice data is what
                // SSYNENG's recovered short-message decoder needs here.
                unsigned n = 0;
                if (status == 0xF1u || status == 0xF3u) n = 1;
                else if (status == 0xF2u) n = 2;
                if (static_cast<size_t>(end - p) < n) return ParseResult::Invalid;
                p += n;
                ++order;
                continue;
            }

            const unsigned hi = status & 0xF0u;
            const unsigned dataCount = (hi == 0xC0u || hi == 0xD0u) ? 1u : 2u;
            unsigned char d1 = 0, d2 = 0;
            if (usedRunning) {
                d1 = firstData;
            } else {
                if (p >= end) return ParseResult::Invalid;
                d1 = *p++;
            }
            if (dataCount == 2) {
                if (p >= end) return ParseResult::Invalid;
                d2 = *p++;
            }
            const DWORD packed = static_cast<DWORD>(status) |
                                 (static_cast<DWORD>(d1 & 0x7fu) << 8) |
                                 (static_cast<DWORD>(d2 & 0x7fu) << 16);
            midi.push_back({tick, order++, packed});
        }
    }

    if (midi.empty()) return ParseResult::Complete;

    if ((division & 0x8000u) == 0) {
        const std::uint32_t ppqn = division ? division : 480u;
        std::vector<TimelineItem> timeline;
        timeline.reserve(midi.size() + tempos.size());
        for (const auto& t : tempos) timeline.push_back({t.tick, t.order, true, t.usecPerQuarter});
        for (const auto& m : midi) timeline.push_back({m.tick, m.order, false, m.message});
        std::sort(timeline.begin(), timeline.end(), [](const TimelineItem& a, const TimelineItem& b) {
            if (a.tick != b.tick) return a.tick < b.tick;
            return a.order < b.order;
        });
        std::uint64_t currentTick = 0;
        std::uint64_t currentUs = 0;
        std::uint32_t tempo = 500000u;
        for (const auto& item : timeline) {
            const std::uint64_t dt = item.tick - currentTick;
            currentUs += (dt * static_cast<std::uint64_t>(tempo)) / ppqn;
            currentTick = item.tick;
            if (item.tempo) {
                tempo = item.value ? item.value : 500000u;
            } else {
                scheduled.push_back({currentUs, item.value});
            }
        }
    } else {
        const int fpsCode = -static_cast<int>(static_cast<signed char>((division >> 8) & 0xffu));
        const unsigned ticksPerFrame = division & 0xffu;
        const double fps = fpsCode == 29 ? 29.97 : static_cast<double>(fpsCode > 0 ? fpsCode : 30);
        const double ticksPerSecond = fps * static_cast<double>(ticksPerFrame ? ticksPerFrame : 1u);
        std::sort(midi.begin(), midi.end(), [](const RawMidiEvent& a, const RawMidiEvent& b) {
            if (a.tick != b.tick) return a.tick < b.tick;
            return a.order < b.order;
        });
        for (const auto& m : midi) {
            const std::uint64_t us = static_cast<std::uint64_t>((static_cast<double>(m.tick) * 1000000.0) / ticksPerSecond);
            scheduled.push_back({us, m.message});
        }
    }

    if (!scheduled.empty()) durationMs = static_cast<DWORD>((scheduled.back().usec + 999u) / 1000u);
    return ParseResult::Complete;
}

struct SchedulerJob {
    std::vector<ScheduledMidiEvent> events;
    LONG generation = 0;
    DWORD durationMs = 0;
};

static bool GenerationCurrent(LONG generation) {
    std::lock_guard<std::mutex> lock(g_seqMutex);
    return g_seq.generation == generation && g_seq.status.active != 0;
}

static DWORD WINAPI SequenceUiMirrorThread(void* param) {
    const LONG generation = static_cast<LONG>(reinterpret_cast<INT_PTR>(param));
    Logf("NativeSeqPlay: UI mirror thread started generation=%ld", generation);
    while (GenerationCurrent(generation)) {
        MirrorAllSequenceUi();
        Sleep(50);
    }
    Logf("NativeSeqPlay: UI mirror thread stopped generation=%ld", generation);
    return 0;
}

static DWORD WINAPI SchedulerThread(void* param) {
    std::unique_ptr<SchedulerJob> job(static_cast<SchedulerJob*>(param));
    if (!job) return 0;

    // A sequence can be fed a fraction of a second before SynHigh finishes its
    // bank/program registration. Do not block Reality's UI thread; wait here.
    for (unsigned i = 0; i < 500 && GenerationCurrent(job->generation); ++i) {
        if (NativeMidiProgramDatabase() != 0) break;
        Sleep(10);
    }
    if (!GenerationCurrent(job->generation)) return 0;

    timeBeginPeriod(1);
    const DWORD start = timeGetTime();
    unsigned injected = 0, failed = 0;
    Logf("NativeSeqPlay: scheduler started generation=%ld events=%lu durationMs=%lu db=%08lX",
         job->generation, static_cast<unsigned long>(job->events.size()),
         static_cast<unsigned long>(job->durationMs), NativeMidiProgramDatabase());

    for (const auto& ev : job->events) {
        if (!GenerationCurrent(job->generation)) break;
        const DWORD dueMs = static_cast<DWORD>(ev.usec / 1000u);
        for (;;) {
            if (!GenerationCurrent(job->generation)) break;
            const DWORD elapsed = timeGetTime() - start;
            if (elapsed >= dueMs) break;
            const DWORD remain = dueMs - elapsed;
            Sleep(remain > 4u ? 4u : (remain ? remain : 1u));
        }
        if (!GenerationCurrent(job->generation)) break;
        if (NativeMidiInjectShort(ev.message, timeGetTime())) {
            ++injected;
            MirrorSequenceMessage(ev.message);
        } else {
            ++failed;
            if (failed <= 8)
                Logf("NativeSeqPlay: scheduler MIDI inject failed msg=%08lX error=%lu",
                     static_cast<unsigned long>(ev.message), GetLastError());
        }
        {
            std::lock_guard<std::mutex> lock(g_seqMutex);
            if (g_seq.generation == job->generation)
                g_seq.status.positionMs = dueMs;
        }
    }
    timeEndPeriod(1);

    {
        std::lock_guard<std::mutex> lock(g_seqMutex);
        if (g_seq.generation == job->generation) {
            g_seq.status.positionMs = job->durationMs;
            g_seq.status.active = 0;
        }
    }
    Logf("NativeSeqPlay: scheduler finished generation=%ld injected=%u failed=%u",
         job->generation, injected, failed);
    return 0;
}

static bool StartSchedulerLocked(const char* reason) {
    if (!g_seq.parsed || g_seq.events.empty()) {
        Logf("NativeSeqPlay: scheduler start deferred reason=%s parsed=%u events=%lu",
             reason ? reason : "(none)", g_seq.parsed ? 1u : 0u,
             static_cast<unsigned long>(g_seq.events.size()));
        return false;
    }
    ++g_seq.generation;
    g_seq.status.active = 1;
    g_seq.status.positionMs = 0;
    auto* job = new (std::nothrow) SchedulerJob();
    if (!job) {
        g_seq.status.active = 0;
        return false;
    }
    job->events = g_seq.events;
    job->generation = g_seq.generation;
    job->durationMs = g_seq.durationMs;
    HANDLE thread = CreateThread(nullptr, 0, SchedulerThread, job, 0, nullptr);
    if (!thread) {
        delete job;
        g_seq.status.active = 0;
        return false;
    }
    CloseHandle(thread);
    if (SequenceUiMirrorEnabled()) {
        HANDLE uiThread = CreateThread(nullptr, 0, SequenceUiMirrorThread,
                                       reinterpret_cast<void*>(static_cast<INT_PTR>(g_seq.generation)), 0, nullptr);
        if (uiThread) CloseHandle(uiThread);
        else Logf("NativeSeqPlay: UI mirror thread create failed error=%lu", GetLastError());
    }
    Logf("NativeSeqPlay: scheduler launch reason=%s generation=%ld events=%lu durationMs=%lu",
         reason ? reason : "(none)", g_seq.generation,
         static_cast<unsigned long>(g_seq.events.size()),
         static_cast<unsigned long>(g_seq.durationMs));
    return true;
}

static void StopSchedulerLocked(const char* reason) {
    ++g_seq.generation;
    g_seq.status.active = 0;
    Logf("NativeSeqPlay: scheduler stop reason=%s generation=%ld",
         reason ? reason : "(none)", g_seq.generation);
}

extern "C" DWORD WINAPI NativeSeqSetup(void* config) {
    std::lock_guard<std::mutex> lock(g_seqMutex);
    StopSchedulerLocked("SetupSeq");
    g_seq.bytes.clear();
    g_seq.events.clear();
    g_seq.status.positionMs = 0;
    g_seq.status.tempo = 120;
    g_seq.status.flags = 0;
    g_seq.initialized = true;
    g_seq.parsed = false;
    g_seq.durationMs = 0;
    ResetSequenceUiStateLocked();

    unsigned char cfg[16] = {};
    if (config && SafeCopy(cfg, config, sizeof(cfg))) {
        g_seq.setupWord0 = *reinterpret_cast<const WORD*>(cfg + 0);
        g_seq.setupWord1 = *reinterpret_cast<const WORD*>(cfg + 2);
        Logf("NativeSeqPlay: SetupSeq config=%p words=[%u,%u] bytes=%02X %02X %02X %02X %02X %02X %02X %02X",
             config, (unsigned)g_seq.setupWord0, (unsigned)g_seq.setupWord1,
             cfg[0],cfg[1],cfg[2],cfg[3],cfg[4],cfg[5],cfg[6],cfg[7]);
    } else {
        Logf("NativeSeqPlay: SetupSeq config=%p (unreadable/null)", config);
    }
    Logf("NativeSeqPlay: SetupSeq -> native status=%p", &g_seq.status);
    return static_cast<DWORD>(reinterpret_cast<ULONG_PTR>(&g_seq.status));
}

extern "C" DWORD WINAPI NativeSeqFeed(const void* data, DWORD len) {
    if (!data && len) {
        Logf("NativeSeqPlay: PlaySeq feed rejected null data len=%lu", len);
        return 0;
    }
    if (len > 16u * 1024u * 1024u) {
        Logf("NativeSeqPlay: PlaySeq feed rejected unreasonable len=%lu", len);
        return 0;
    }

    std::vector<unsigned char> temp(len);
    if (len && !SafeCopy(temp.data(), data, len)) {
        Logf("NativeSeqPlay: PlaySeq feed unreadable data=%p len=%lu", data, len);
        return 0;
    }

    std::lock_guard<std::mutex> lock(g_seqMutex);
    const size_t oldSize = g_seq.bytes.size();
    if (oldSize + len > 64u * 1024u * 1024u) {
        Logf("NativeSeqPlay: PlaySeq aggregate limit exceeded old=%lu add=%lu", (unsigned long)oldSize, len);
        return 0;
    }
    g_seq.bytes.insert(g_seq.bytes.end(), temp.begin(), temp.end());

    char sig[5] = {};
    if (oldSize == 0 && len >= 4) {
        for (int i=0;i<4;i++) sig[i] = (temp[i] >= 32 && temp[i] < 127) ? (char)temp[i] : '.';
    }
    Logf("NativeSeqPlay: PlaySeq feed data=%p len=%lu total=%lu%s%s",
         data, len, (unsigned long)g_seq.bytes.size(),
         oldSize == 0 && len >= 4 ? " first4=" : "",
         oldSize == 0 && len >= 4 ? sig : "");

    std::vector<ScheduledMidiEvent> parsedEvents;
    DWORD durationMs = 0; unsigned format=0, tracks=0, division=0;
    const ParseResult parse = ParseSmf(g_seq.bytes, parsedEvents, durationMs, format, tracks, division);
    if (parse == ParseResult::Complete) {
        const bool newlyComplete = !g_seq.parsed;
        g_seq.events.swap(parsedEvents);
        g_seq.durationMs = durationMs;
        g_seq.parsed = true;
        Logf("NativeSeqPlay: SMF parsed format=%u tracks=%u division=%u events=%lu durationMs=%lu completeBytes=%lu",
             format, tracks, division, static_cast<unsigned long>(g_seq.events.size()),
             static_cast<unsigned long>(durationMs), static_cast<unsigned long>(g_seq.bytes.size()));
        // In the observed Reality 1.5 path no legacy 0x0FA1 command follows the
        // two PlaySeq data feeds. The old 16-bit SeqPlay DLL started once the
        // complete SMF had been handed over. Reproduce that behavior here.
        if (newlyComplete && !g_seq.events.empty()) StartSchedulerLocked("complete PlaySeq SMF");
    } else if (parse == ParseResult::Invalid) {
        Logf("NativeSeqPlay: buffered sequence is not a valid/complete SMF total=%lu",
             static_cast<unsigned long>(g_seq.bytes.size()));
    }
    return 1;
}

extern "C" DWORD WINAPI NativeSeqControl(DWORD command, DWORD param) {
    std::lock_guard<std::mutex> lock(g_seqMutex);
    Logf("NativeSeqPlay: ControlSeq command=%04lX param=%08lX buffered=%lu active=%u parsed=%u events=%lu",
         command, param, (unsigned long)g_seq.bytes.size(), (unsigned)g_seq.status.active,
         g_seq.parsed ? 1u : 0u, static_cast<unsigned long>(g_seq.events.size()));

    switch (command) {
        case 0x1004: // configuration/open option used by SynHigh
            return kSeqOk;
        case 0x1005: // initialize/open
            g_seq.initialized = true;
            return kSeqOk;
        case 0x1006: // shutdown/free
            StopSchedulerLocked("ControlSeq 1006");
            g_seq.initialized = false;
            g_seq.bytes.clear();
            g_seq.events.clear();
            g_seq.parsed = false;
            return kSeqOk;
        case 0x0FA1: // explicit start on variants that still issue it
            StartSchedulerLocked("ControlSeq 0FA1");
            return kSeqOk;
        case 0x0FA2: // stop
            StopSchedulerLocked("ControlSeq 0FA2");
            return kSeqOk;
        case 0x0FA5:
        case 0x0FA8:
            g_seq.status.positionMs = param;
            return kSeqOk;
        case 0x0FA6:
            return g_seq.status.positionMs;
        case 0x0FA7:
            return 0;
        case 0x0FA9:
            return g_seq.status.tempo;
        case 0x0FA3: case 0x0FA4: case 0x0FAA: case 0x0FAB:
        case 0x0FAC: case 0x0FAD: case 0x0FAE: case 0x0FAF:
            return kSeqOk;
        default:
            return kSeqOk;
    }
}

static bool PatchJump(HMODULE module, DWORD rva, const unsigned char* expected,
                      size_t expectedLen, void* target, const char* label) {
    unsigned char* p = reinterpret_cast<unsigned char*>(module) + rva;
    if (expectedLen && std::memcmp(p, expected, expectedLen) != 0) {
        Logf("NativeSeqPlay: %s signature mismatch at %p RVA=%08lX; not patching", label, p, rva);
        return false;
    }
    const int64_t delta64 = static_cast<int64_t>(reinterpret_cast<uintptr_t>(target)) -
                            static_cast<int64_t>(reinterpret_cast<uintptr_t>(p + 5));
    if (delta64 < static_cast<int64_t>(std::numeric_limits<int32_t>::min()) ||
        delta64 > static_cast<int64_t>(std::numeric_limits<int32_t>::max())) {
        Logf("NativeSeqPlay: %s JMP target out of rel32 range source=%p target=%p", label, p, target);
        return false;
    }
    DWORD oldProt = 0;
    if (!VirtualProtect(p, 16, PAGE_EXECUTE_READWRITE, &oldProt)) {
        Logf("NativeSeqPlay: %s VirtualProtect failed error=%lu", label, GetLastError());
        return false;
    }
    p[0] = 0xE9;
    *reinterpret_cast<int32_t*>(p + 1) = static_cast<int32_t>(delta64);
    for (size_t i=5; i<expectedLen; ++i) p[i] = 0x90;
    FlushInstructionCache(GetCurrentProcess(), p, expectedLen ? expectedLen : 5);
    DWORD tmp = 0; VirtualProtect(p, 16, oldProt, &tmp);
    Logf("NativeSeqPlay: patched %s SynHighRVA=%08lX -> %p", label, rva, target);
    return true;
}

} // namespace

bool PatchSynHighNativeSeqPlay(HMODULE synHigh) {
    if (!synHigh) return false;
    if (g_patchedModule == synHigh) return true;

    static const unsigned char setupSig[] = {
        0x8B,0x44,0x24,0x04,0x50,0xE8,0x03,0x58,0x00,0x00,0xC2,0x04,0x00
    };
    static const unsigned char feedSig[] = {
        0x8B,0x44,0x24,0x08,0x8B,0x4C,0x24,0x04,0x50,0x51,0xE8,0x15,0x58,0x00,0x00,0xC2,0x08,0x00
    };
    static const unsigned char ctlSig[] = {
        0x8B,0x44,0x24,0x08,0x8B,0x4C,0x24,0x04,0x50,0x51,0xE8,0x1D,0x58,0x00,0x00,0xC2,0x08,0x00
    };

    bool a = PatchJump(synHigh, 0x000191B0, setupSig, sizeof(setupSig), (void*)&NativeSeqSetup, "SetupSeqThunk wrapper");
    bool b = PatchJump(synHigh, 0x000191C0, feedSig, sizeof(feedSig), (void*)&NativeSeqFeed, "PlaySeqThunk wrapper");
    bool c = PatchJump(synHigh, 0x000191E0, ctlSig, sizeof(ctlSig), (void*)&NativeSeqControl, "ControlSeqThunk wrapper");
    if (a && b && c) {
        g_patchedModule = synHigh;
        Logf("NativeSeqPlay: all three Win16 SeqPlay thunk wrappers replaced; native SMF scheduler enabled");
        return true;
    }
    return false;
}
