#include "native_midi.h"
#include "log.h"
#include "ssyneng_api.h"
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <mmsystem.h>
#include <array>

namespace {
struct EngineApi {
    SSynEng_ControlState_t control = nullptr;
    SSynEng_Start_t start = nullptr;
    SSynEng_Stop_t stop = nullptr;
    SSynEng_ResetMidi_t reset = nullptr;
    SSynEng_InjectMidiShort_t inject = nullptr;
    SSynEng_DumpSynthState_t dump = nullptr;
    SSynEng_GetProgramDatabase_t getDb = nullptr;
    SSynEng_RegisterProgramRoot_t registerRoot = nullptr;
    LONG resolved = 0;
} g_api;

LONG g_engineStarted = 0;
LONG g_bruteforcePrimed = 0;
LONG g_postDbProbeSent = 0;
// Recovered SSYNMIDI.DRV device/callback table.  The Win16 driver has exactly
// four 0x32-byte records at data:03D4.  Command 0x59 stores a 16-bit callback
// window/token at record+08.  Open/close/unregister notifications are custom
// USER messages 0x489/0x48A/0x48B; +0A and +0C are their sequence counters.
struct DriverDeviceRecord {
    WORD id = 0xffffu;
    WORD callbackToken = 0;
    WORD openNotifySeq = 0;
    WORD closeNotifySeq = 0;
    bool allocated = false;
    bool open = false;
    DWORD_PTR winmmCallback = 0;
    DWORD_PTR winmmInstance = 0;
    DWORD winmmFlags = 0;
};
std::array<DriverDeviceRecord,4> g_driverDevices{};
SRWLOCK g_driverLock = SRWLOCK_INIT;
LONG g_openDeviceCount = 0;
LONG g_timePeriodHeld = 0;
DWORD g_driverVolume = 0xffffffffu;

DriverDeviceRecord* FindDeviceRecordUnlocked(unsigned id, bool create) {
    for (auto& r : g_driverDevices) {
        if (r.allocated && r.id == static_cast<WORD>(id)) return &r;
    }
    if (!create) return nullptr;
    for (auto& r : g_driverDevices) {
        if (!r.allocated) {
            r = DriverDeviceRecord{};
            r.allocated = true;
            r.id = static_cast<WORD>(id);
            return &r;
        }
    }
    return nullptr;
}

struct WindowSearchCtx { WORD token; DWORD pid; HWND found; };
BOOL CALLBACK FindLegacyChildWindow(HWND hwnd, LPARAM lp) {
    auto* c = reinterpret_cast<WindowSearchCtx*>(lp);
    DWORD pid = 0; GetWindowThreadProcessId(hwnd, &pid);
    if (pid == c->pid && LOWORD(reinterpret_cast<ULONG_PTR>(hwnd)) == c->token) {
        c->found = hwnd; return FALSE;
    }
    return TRUE;
}
BOOL CALLBACK FindLegacyTopWindow(HWND hwnd, LPARAM lp) {
    auto* c = reinterpret_cast<WindowSearchCtx*>(lp);
    DWORD pid = 0; GetWindowThreadProcessId(hwnd, &pid);
    if (pid == c->pid && LOWORD(reinterpret_cast<ULONG_PTR>(hwnd)) == c->token) {
        c->found = hwnd; return FALSE;
    }
    EnumChildWindows(hwnd, FindLegacyChildWindow, lp);
    return c->found ? FALSE : TRUE;
}

HWND ResolveLegacyCallbackWindow(WORD token) {
    if (!token) return nullptr;
    HWND direct = reinterpret_cast<HWND>(static_cast<ULONG_PTR>(token));
    if (IsWindow(direct)) return direct;
    WindowSearchCtx c{token, GetCurrentProcessId(), nullptr};
    EnumWindows(FindLegacyTopWindow, reinterpret_cast<LPARAM>(&c));
    return c.found;
}

struct WindowInventoryCtx { DWORD pid; unsigned shown; };
BOOL CALLBACK LogTopWindow(HWND hwnd, LPARAM lp) {
    auto* c = reinterpret_cast<WindowInventoryCtx*>(lp);
    DWORD pid = 0; GetWindowThreadProcessId(hwnd, &pid);
    if (pid != c->pid || c->shown >= 24) return TRUE;
    char cls[96]{}, title[160]{};
    GetClassNameA(hwnd, cls, static_cast<int>(sizeof(cls)));
    GetWindowTextA(hwnd, title, static_cast<int>(sizeof(title)));
    Logf("SSYNMIDI32: callback-window candidate hwnd=%p low16=%04X class=%s title=%s visible=%u",
         hwnd, LOWORD(reinterpret_cast<ULONG_PTR>(hwnd)), cls, title, IsWindowVisible(hwnd)?1u:0u);
    ++c->shown;
    return TRUE;
}
void LogProcessWindowInventoryOnce() {
    static LONG once = 0;
    if (InterlockedCompareExchange(&once,1,0) != 0) return;
    WindowInventoryCtx c{GetCurrentProcessId(),0};
    EnumWindows(LogTopWindow, reinterpret_cast<LPARAM>(&c));
}

void SendLegacyDriverNotification(unsigned id, UINT msg) {
    WORD token = 0, sequence = 0;
    AcquireSRWLockExclusive(&g_driverLock);
    DriverDeviceRecord* r = FindDeviceRecordUnlocked(id, false);
    if (r && r->callbackToken) {
        token = r->callbackToken;
        if (msg == 0x489) sequence = ++r->openNotifySeq;
        else if (msg == 0x48A) sequence = ++r->closeNotifySeq;
    }
    ReleaseSRWLockExclusive(&g_driverLock);
    if (!token) return;
    HWND hwnd = ResolveLegacyCallbackWindow(token);
    if (!hwnd) {
        Logf("SSYNMIDI32: callback message=%03X id=%u token=%04X unresolved (kept registered)",
             msg, id, static_cast<unsigned>(token));
        LogProcessWindowInventoryOnce();
        return;
    }
    const WPARAM wp = (msg == 0x48B) ? 0 : sequence;
    const LRESULT result = SendMessageA(hwnd, msg, wp, 0);
    Logf("SSYNMIDI32: callback message=%03X id=%u token=%04X hwnd=%p seq=%u sendResult=%08lX",
         msg, id, static_cast<unsigned>(token), hwnd, static_cast<unsigned>(wp),
         static_cast<unsigned long>(result));
}

bool ResolveEngineApi();

bool EnvEnabled(const char* name) {
    char value[16]{};
    const DWORD n = GetEnvironmentVariableA(name, value, sizeof(value));
    if (!n || n >= sizeof(value)) return false;
    return _stricmp(value, "1") == 0 || _stricmp(value, "true") == 0 ||
           _stricmp(value, "yes") == 0 || _stricmp(value, "on") == 0;
}

DWORD WINAPI ProbeNoteOffThread(void* param) {
    // Give the original SSYNENG worker time to consume the Program Change and
    // Note On.  v7 dumps before and after Note Off so the ring read/consume
    // counters prove whether the recovered MIDI worker is actually running,
    // rather than merely accepting writes into the queue.
    Sleep(250);
    if (ResolveEngineApi() && g_api.dump) {
        Logf("NativeMidi: probe pre-NoteOff engine dump (expect MIDI ring consumption)");
        g_api.dump();
    }
    Sleep(100);
    const DWORD msg = param ? static_cast<DWORD>(reinterpret_cast<uintptr_t>(param)) : 0x00003C80u;
    if (ResolveEngineApi() && g_api.inject) {
        g_api.inject(msg, timeGetTime());
        Logf("NativeMidi: probe NoteOff queued msg=%08lX", static_cast<unsigned long>(msg));
        Sleep(100);
        if (g_api.dump) {
            Logf("NativeMidi: probe post-NoteOff engine dump");
            g_api.dump();
        }
    }
    return 0;
}

FARPROC ResolveProc(HMODULE m, const char* plain, const char* decorated) {
    FARPROC p = m ? GetProcAddress(m, plain) : nullptr;
#if defined(_M_IX86)
    if (!p && m && decorated) p = GetProcAddress(m, decorated);
#else
    (void)decorated;
#endif
    return p;
}

bool ResolveEngineApi() {
    if (g_api.resolved > 0) return true;
    HMODULE m = GetModuleHandleW(L"SSYNENG.dll");
    if (!m) return false;
    g_api.control = reinterpret_cast<SSynEng_ControlState_t>(ResolveProc(m,"SSynEng_ControlState","_SSynEng_ControlState@8"));
    g_api.start   = reinterpret_cast<SSynEng_Start_t>(ResolveProc(m,"SSynEng_Start","_SSynEng_Start@0"));
    g_api.stop    = reinterpret_cast<SSynEng_Stop_t>(ResolveProc(m,"SSynEng_Stop","_SSynEng_Stop@0"));
    g_api.reset   = reinterpret_cast<SSynEng_ResetMidi_t>(ResolveProc(m,"SSynEng_ResetMidi","_SSynEng_ResetMidi@4"));
    g_api.inject  = reinterpret_cast<SSynEng_InjectMidiShort_t>(ResolveProc(m,"SSynEng_InjectMidiShort","_SSynEng_InjectMidiShort@8"));
    g_api.dump    = reinterpret_cast<SSynEng_DumpSynthState_t>(ResolveProc(m,"SSynEng_DumpSynthState","_SSynEng_DumpSynthState@0"));
    g_api.getDb   = reinterpret_cast<SSynEng_GetProgramDatabase_t>(ResolveProc(m,"SSynEng_GetProgramDatabase","_SSynEng_GetProgramDatabase@0"));
    g_api.registerRoot = reinterpret_cast<SSynEng_RegisterProgramRoot_t>(ResolveProc(m,"SSynEng_RegisterProgramRoot","_SSynEng_RegisterProgramRoot@8"));
    const bool ok = g_api.control && g_api.start && g_api.stop && g_api.reset && g_api.inject &&
                    g_api.getDb && g_api.registerRoot;
    InterlockedExchange(&g_api.resolved, ok ? 1 : -1);
    Logf("NativeMidi: engine API resolve module=%p control=%p start=%p stop=%p reset=%p inject=%p dump=%p getDb=%p registerRoot=%p ok=%u",
         m, g_api.control, g_api.start, g_api.stop, g_api.reset, g_api.inject, g_api.dump,
         g_api.getDb, g_api.registerRoot, ok ? 1u : 0u);
    return ok;
}

bool CommandSet(const std::uint32_t* bits, unsigned cmd) {
    return bits && cmd < 256 && (bits[cmd >> 5] & (1u << (cmd & 31))) != 0;
}

template <typename T> T& Field(std::uint8_t* b, size_t off) {
    return *reinterpret_cast<T*>(b + off);
}

void LogCommands(const std::uint32_t* bits, std::uint8_t* b) {
    char text[768]{}; size_t used = 0;
    for (unsigned c=0;c<256;++c) {
        if (!CommandSet(bits,c)) continue;
        const int n=std::snprintf(text+used,sizeof(text)-used,"%s%02X",used?",":"",c);
        if (n<=0) break; used += static_cast<size_t>(n);
        if (used >= sizeof(text)-16) break;
    }
    Logf("NativeMidi: SeerCtl32 block=%p commands=[%s] query=%u midiId=%u",
         b,text,CommandSet(bits,0)?1u:0u,static_cast<unsigned>(Field<std::uint16_t>(b,0x5CC)));
}
}

extern "C" WORD WINAPI SeerCtl32(void* sharedBlock) {
    if (!sharedBlock || !ResolveEngineApi()) return 1;
#if defined(_MSC_VER)
    __try {
#endif
        auto* b = static_cast<std::uint8_t*>(sharedBlock);
        auto* masks = reinterpret_cast<std::uint32_t*>(b);
        std::uint32_t originalMasks[8]{};
        std::memcpy(originalMasks, masks, sizeof(originalMasks));
        LogCommands(originalMasks,b);
        const bool query = CommandSet(originalMasks,0);

        // SSYNMIDI.DRV handles SET bit 92 entirely inside the MIDI driver and
        // returns immediately; it never reaches SSYNENG service 17.  Reproduce
        // that ordering instead of merely stripping the bit from a later call.
        const bool fastMidi = !query && (originalMasks[2] & 0x10000000u) != 0;
        if (fastMidi) {
            const DWORD packedMidi = Field<DWORD>(b,0x5D8);
            const BOOL midiOk = g_api.inject(packedMidi, timeGetTime());
            Logf("NativeMidi: SeerCtl32 bit92 fast MIDI msg=%08lX -> %u", packedMidi, midiOk?1u:0u);
            return midiOk ? 0 : 1;
        }

        // These are SSYNMIDI-local side effects recovered from the original
        // Win16 driver.  The original performs them BEFORE forwarding the same
        // control block to SSYNENG service 17, so preserve both the local work
        // and the subsequent VxD transfer.
        if (CommandSet(originalMasks,0x20)) {
            Field<std::uint16_t>(b,0x1A4) = ResolveEngineApi() ? 1 : 0;
            Logf("NativeMidi: cmd20 local driver status id=%u -> %u",
                 static_cast<unsigned>(Field<std::uint16_t>(b,0x5CC)),
                 static_cast<unsigned>(Field<std::uint16_t>(b,0x1A4)));
        }
        if (CommandSet(originalMasks,0x32) && query) {
            Field<std::uint16_t>(b,0x1D4)=0x2001;
            Field<std::uint16_t>(b,0x1D6)=0x0403;
            Logf("NativeMidi: cmd32 local driver version=2001/0403");
        }
        if (CommandSet(originalMasks,0x33)) {
            if (query) {
                Field<std::uint16_t>(b,0x1D8) = InterlockedCompareExchange(&g_engineStarted,0,0) ? 1 : 0;
                Logf("NativeMidi: cmd33 local driver-open query id=%u -> %u",
                     static_cast<unsigned>(Field<std::uint16_t>(b,0x5CC)),
                     static_cast<unsigned>(Field<std::uint16_t>(b,0x1D8)));
            } else {
                const bool started = NativeMidiStartEngine();
                Field<std::uint16_t>(b,0x1D8)=started?1:0;
                Logf("NativeMidi: cmd33 local driver-open id=%u start=%u",
                     static_cast<unsigned>(Field<std::uint16_t>(b,0x5CC)),started?1u:0u);
                if (!started) return 1;
            }
        }
        if (!query && CommandSet(originalMasks,0x59)) {
            const unsigned midiId = static_cast<unsigned>(Field<std::uint16_t>(b,0x5CC));
            const WORD token = Field<std::uint16_t>(b,0x5CE);
            bool openNow = false;
            AcquireSRWLockExclusive(&g_driverLock);
            DriverDeviceRecord* r = FindDeviceRecordUnlocked(midiId, true);
            if (r) {
                r->callbackToken = token;
                openNow = r->open;
            }
            ReleaseSRWLockExclusive(&g_driverLock);
            // Uploaded SSYNMIDI.DRV seg1:22CC stores +5CE at per-device
            // record+08.  If the matching device is already active it immediately
            // calls seg1:235E, which synchronously sends USER message 0x489 to that token.
            // A zero token unregisters the local callback without fabricating a
            // timer interval.  The same service-17 block is still forwarded.
            Logf("SSYNMIDI32: cmd59 callback registration id=%u token=%04X open=%u (service17 follows)",
                 midiId, static_cast<unsigned>(token), openNow ? 1u : 0u);
            if (token && openNow) SendLegacyDriverNotification(midiId, 0x489);
        }

        // Recovered service-17 command 0x41 (overall mask bit 65) carries the
        // deeper program/root pointer at +0x540 and a 1-based MIDI-channel hint
        // at +0x554.  On Win9x this only worked after a separate bit-64/IOCTL4001
        // SetProgramDatabase handoff.  The NT trace shows SynHigh is successfully
        // constructing the program/root objects but that final database wrapper
        // handoff is gone.  Reconstruct the missing 0x18-byte DB records from the
        // exact roots SynHigh is already registering, then forward command 41 to
        // original service 17 so its own 0x92250 channel-binding helper runs.
        bool postDbProbeCandidate = false;
        unsigned postDbProbeChannel = 0;
        bool postDbNeedsProgramChange = false;
        if (!query && CommandSet(originalMasks,0x41)) {
            const DWORD root = Field<DWORD>(b,0x540);
            const WORD channelHint = Field<WORD>(b,0x554);
            DWORD key = 0xffffffffu;
#if defined(_MSC_VER)
            __try {
                if (root) key = *reinterpret_cast<const DWORD*>(static_cast<uintptr_t>(root) + 0xA0u);
            } __except(EXCEPTION_EXECUTE_HANDLER) {
                key = 0xffffffffu;
            }
#endif
            const DWORD dbBefore = g_api.getDb ? g_api.getDb() : 0;
            BOOL rootOk = FALSE;
            if (root && g_api.registerRoot)
                rootOk = g_api.registerRoot(root, channelHint);
            const DWORD dbAfter = g_api.getDb ? g_api.getDb() : 0;
            Logf("NativeMidi: cmd41 program-root root=%08lX key=%08lX channel=%u db=%08lX->%08lX reconstruct=%u",
                 static_cast<unsigned long>(root), static_cast<unsigned long>(key),
                 static_cast<unsigned>(channelHint), static_cast<unsigned long>(dbBefore),
                 static_cast<unsigned long>(dbAfter), rootOk ? 1u : 0u);

            // We probe only when we have a deterministic playable selection:
            // (a) command 41 explicitly names a channel, in which case original
            //     service17 will bind this exact root after the forward below; or
            // (b) this is bank 0 / program 0, which SetProgramDatabase resolves
            //     for Reality's freshly initialized channels by itself.
            const DWORD patchKey = key & 0x001fffffu;
            if (rootOk && dbAfter && EnvEnabled("REALITY_SYNTH_PROBE")) {
                if (channelHint >= 1 && channelHint <= 16) {
                    postDbProbeCandidate = true;
                    postDbProbeChannel = channelHint - 1u;
                } else if (key != 0xffffffffu && patchKey == 0u) {
                    postDbProbeCandidate = true;
                    postDbProbeChannel = 0u;
                    postDbNeedsProgramChange = true;
                }
            }
        }

        // SynMid allocates this shared control block as one 4 KiB Win9x shared
        // page.  The original SSYNMIDI driver forwards the block after its local
        // processing, allowing the real service-17 implementation to handle all
        // engine-owned fields (including program database/status fields).
        BOOL controlOk = g_api.control(sharedBlock, 0x1000u);
        if (!controlOk) {
            Logf("NativeMidi: SeerCtl32 engine operation failed error=%lu",GetLastError());
            return 1;
        }

        if (postDbProbeCandidate && g_api.inject &&
            InterlockedCompareExchange(&g_postDbProbeSent,1,0)==0) {
            const DWORD status = 0x90u | (postDbProbeChannel & 0x0fu);
            const DWORD noteOn = status | (0x3Cu << 8) | (0x64u << 16);
            // For the bank0/program0 fallback case, repeat PC0 after the DB exists
            // so the original A5820 lookup definitely runs against the new DB.
            if (postDbNeedsProgramChange) {
                const DWORD pc = 0xC0u | (postDbProbeChannel & 0x0fu);
                const BOOL pcOk = g_api.inject(pc, timeGetTime());
                Logf("NativeMidi: post-DB ProgramChange ch=%u program=0 queued=%u",
                     postDbProbeChannel + 1u, pcOk ? 1u : 0u);
            }
            const BOOL on = g_api.inject(noteOn, timeGetTime()+1u);
            Logf("NativeMidi: post-DB probe channel=%u NoteOn=%08lX queued=%u",
                 postDbProbeChannel + 1u, static_cast<unsigned long>(noteOn), on ? 1u : 0u);
            if (on) {
                const DWORD noteOff = (0x80u | (postDbProbeChannel & 0x0fu)) | (0x3Cu << 8);
                HANDLE t = CreateThread(nullptr,0,ProbeNoteOffThread,
                                        reinterpret_cast<void*>(static_cast<uintptr_t>(noteOff)),0,nullptr);
                if (t) CloseHandle(t);
            }
            if (g_api.dump) g_api.dump();
        }
        return 0;
#if defined(_MSC_VER)
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        Logf("NativeMidi: exception processing shared block=%p code=%08lX",sharedBlock,GetExceptionCode());
        return 1;
    }
#endif
}

bool NativeMidiStartEngine() {
    if (InterlockedCompareExchange(&g_engineStarted,0,0)) return true;
    const bool ok = ResolveEngineApi() && g_api.start && g_api.start()!=FALSE;
    if (!ok) return false;
    InterlockedExchange(&g_engineStarted,1);
    if (InterlockedCompareExchange(&g_timePeriodHeld,1,0)==0) {
        const MMRESULT tr = timeBeginPeriod(1);
        if (tr != TIMERR_NOERROR) InterlockedExchange(&g_timePeriodHeld,0);
        Logf("SSYNMIDI32: timing granularity begin period=1ms result=%u", static_cast<unsigned>(tr));
    }

    // Optional aggressive bring-up mode.  It deliberately uses only recovered
    // public engine operations; it does not fabricate a program-database pointer.
    if (EnvEnabled("REALITY_SYNTH_BRUTEFORCE") &&
        InterlockedCompareExchange(&g_bruteforcePrimed,1,0)==0) {
        const bool resetOk = g_api.reset && g_api.reset(TRUE)!=FALSE;
        Logf("NativeMidi: brute-force prime full GM/GS reset -> %u", resetOk?1u:0u);
        if (EnvEnabled("REALITY_SYNTH_PROBE") && g_api.inject) {
            const DWORD now = timeGetTime();
            const BOOL pc = g_api.inject(0x000000C0u, now);      // program 0, ch1
            const BOOL on = g_api.inject(0x00643C90u, now + 1); // C4 velocity 100
            Logf("NativeMidi: brute-force probe PC0=%u NoteOn=%u", pc?1u:0u, on?1u:0u);
            if (on) {
                HANDLE t = CreateThread(nullptr,0,ProbeNoteOffThread,
                                        reinterpret_cast<void*>(static_cast<uintptr_t>(0x00003C80u)),0,nullptr);
                if (t) CloseHandle(t);
            }
        }
        if (g_api.dump) g_api.dump();
    }
    return true;
}
bool NativeMidiStopEngine() {
    if (!InterlockedCompareExchange(&g_engineStarted,0,0)) return true;
    const bool ok = ResolveEngineApi() && g_api.stop && g_api.stop()!=FALSE;
    if (ok) InterlockedExchange(&g_engineStarted,0);
    if (InterlockedCompareExchange(&g_timePeriodHeld,0,1)==1) {
        const MMRESULT tr = timeEndPeriod(1);
        Logf("SSYNMIDI32: timing granularity end period=1ms result=%u", static_cast<unsigned>(tr));
    }
    return ok;
}
bool NativeMidiReset(bool fullGmGsReset) {
    return ResolveEngineApi() && g_api.reset && g_api.reset(fullGmGsReset?TRUE:FALSE)!=FALSE;
}
void NativeMidiDumpSynthState() {
    if (ResolveEngineApi() && g_api.dump) g_api.dump();
}

bool NativeMidiInjectShort(DWORD packedMessage, DWORD timestampMs) {
    return ResolveEngineApi() && g_api.inject &&
           g_api.inject(packedMessage, timestampMs) != FALSE;
}

DWORD NativeMidiProgramDatabase() {
    return ResolveEngineApi() && g_api.getDb ? g_api.getDb() : 0u;
}

void NativeMidiCaptureShort(DWORD packedMessage, DWORD timestampMs) {
    const unsigned status=packedMessage&0xffu, d1=(packedMessage>>8)&0x7fu, d2=(packedMessage>>16)&0x7fu;
    Logf("NativeMidi: short msg=%08lX time=%lu status=%02X ch=%u d1=%u d2=%u",
         packedMessage,timestampMs,status,(status&0x0f)+1,d1,d2);
    if (!ResolveEngineApi() || !g_api.inject || !g_api.inject(packedMessage,timestampMs))
        Logf("NativeMidi: short-message injection failed error=%lu",GetLastError());
}

namespace {
bool IsGmOrGsResetNative(const BYTE* p, DWORD n) {
    if (!p || n < 6) return false;
    if (n >= 6 && p[0]==0xF0 && p[1]==0x7E && p[3]==0x09 && p[4]==0x01) return true;
    if (n >= 10 && p[0]==0xF0 && p[1]==0x41 && p[2]==0x10 && p[3]==0x42 &&
        p[4]==0x12 && p[5]==0x40 && p[6]==0x00 && p[7]==0x7F && p[8]==0x00) return true;
    return false;
}

void ForwardRecoveredLongStream(const BYTE* p, DWORD n, DWORD timestampMs) {
    BYTE running = 0;
    DWORD i = 0, eventIndex = 0;
    while (i < n) {
        BYTE status = p[i++];
        if (status >= 0xF8) {
            NativeMidiInjectShort(status, timestampMs + eventIndex++);
            continue;
        }
        if (status == 0xF0) {
            while (i < n && p[i++] != 0xF7) {}
            running = 0;
            continue;
        }
        if (status & 0x80) {
            if (status >= 0xF0) { running = 0; continue; }
            running = status;
        } else {
            if (!running) continue;
            --i;
            status = running;
        }
        const BYTE hi = status & 0xF0;
        if (hi < 0x80 || hi > 0xE0) { running = 0; continue; }
        const DWORD need = (hi == 0xC0 || hi == 0xD0) ? 1u : 2u;
        if (i + need > n) break;
        const BYTE d1 = p[i++] & 0x7F;
        const BYTE d2 = need == 2 ? (p[i++] & 0x7F) : 0;
        const DWORD packed = static_cast<DWORD>(status) |
                             (static_cast<DWORD>(d1) << 8) |
                             (static_cast<DWORD>(d2) << 16);
        NativeMidiInjectShort(packed, timestampMs + eventIndex++);
    }
}
}

bool NativeMidiOpenDevice(unsigned midiId, DWORD_PTR callback, DWORD_PTR instance, DWORD flags) {
    bool alreadyOpen = false;
    AcquireSRWLockExclusive(&g_driverLock);
    DriverDeviceRecord* r = FindDeviceRecordUnlocked(midiId, true);
    if (!r) {
        ReleaseSRWLockExclusive(&g_driverLock);
        SetLastError(ERROR_TOO_MANY_OPEN_FILES);
        Logf("SSYNMIDI32: open id=%u failed: all four recovered device records are in use", midiId);
        return false;
    }
    alreadyOpen = r->open;
    r->winmmCallback = callback;
    r->winmmInstance = instance;
    r->winmmFlags = flags;
    r->open = true;
    ReleaseSRWLockExclusive(&g_driverLock);

    if (!alreadyOpen) {
        const LONG count = InterlockedIncrement(&g_openDeviceCount);
        if (count == 1 && !NativeMidiStartEngine()) {
            InterlockedDecrement(&g_openDeviceCount);
            AcquireSRWLockExclusive(&g_driverLock);
            r = FindDeviceRecordUnlocked(midiId, false);
            if (r) r->open = false;
            ReleaseSRWLockExclusive(&g_driverLock);
            return false;
        }
    }
    Logf("SSYNMIDI32: device open id=%u callback=%p instance=%p flags=%08lX openCount=%ld",
         midiId, reinterpret_cast<void*>(callback), reinterpret_cast<void*>(instance),
         static_cast<unsigned long>(flags), InterlockedCompareExchange(&g_openDeviceCount,0,0));
    SendLegacyDriverNotification(midiId, 0x489);
    return true;
}

bool NativeMidiCloseDevice(unsigned midiId) {
    bool wasOpen = false;
    AcquireSRWLockShared(&g_driverLock);
    DriverDeviceRecord* r = FindDeviceRecordUnlocked(midiId, false);
    wasOpen = r && r->open;
    ReleaseSRWLockShared(&g_driverLock);
    if (!wasOpen) return true;

    // Original MODM_CLOSE calls seg1:23B4 while the record (including +08
    // callback token) is still valid, then releases the instance.
    SendLegacyDriverNotification(midiId, 0x48A);
    AcquireSRWLockExclusive(&g_driverLock);
    r = FindDeviceRecordUnlocked(midiId, false);
    if (r) {
        r->open = false;
        r->winmmCallback = 0;
        r->winmmInstance = 0;
        r->winmmFlags = 0;
    }
    ReleaseSRWLockExclusive(&g_driverLock);

    LONG count = InterlockedDecrement(&g_openDeviceCount);
    if (count < 0) { InterlockedExchange(&g_openDeviceCount,0); count = 0; }

    // v13.17: MODM_CLOSE is not an SSYNENG service-4 boundary on the NT
    // rehost.  Reality closes and reopens the synthetic "Reality" MIDI
    // output while changing MIDI INPUT devices.  v13.16 translated that
    // transient close into NativeMidiStopEngine(), which stopped the AA9B0
    // pump, ran the recovered service-4/final-cleanup path and discarded the
    // live 0x7002 audio-registration state.  The immediately following MIDI
    // reopen then performed a fresh service-3 lifecycle init while DirectSound
    // was in the middle of its own options-dialog reconfiguration.  The real
    // runtime log shows that restart coming back with outputRunning=0 and
    // midiProcessGate=0 even though configuredRate/outputMode remain 44100/4.
    // That is the actual MIDI-input-switch regression; it is not rate-field
    // drift.
    //
    // Keep the recovered synth/DSP lifecycle alive across ordinary MIDI-device
    // closes.  The four SSYNMIDI device records are still closed exactly as
    // before and a later MODM_OPEN simply reconnects to the already-running
    // engine.  Full engine teardown remains owned by NativeMidiShutdownDriver()
    // (WEP/driver unload) and SSYNENG's ordered process-exit shutdown, both of
    // which still call NativeMidiStopEngine()/StopEngine explicitly.
    const bool ok = true;
    Logf("SSYNMIDI32: device close id=%u openCount=%ld engineStop=deferred-to-driver-shutdown",
         midiId, count);
    return ok;
}

MMRESULT NativeMidiHandleLongData(const BYTE* data, DWORD bytes, DWORD timestampMs) {
    if (!data && bytes) return MMSYSERR_INVALPARAM;
    if (IsGmOrGsResetNative(data, bytes)) {
        const bool ok = NativeMidiReset(true);
        Logf("SSYNMIDI32: long MIDI recognized GM/GS reset bytes=%lu -> %u",
             static_cast<unsigned long>(bytes), ok?1u:0u);
        return ok ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    }
    ForwardRecoveredLongStream(data, bytes, timestampMs);
    Logf("SSYNMIDI32: long MIDI parsed bytes=%lu running-status/system-realtime path",
         static_cast<unsigned long>(bytes));
    return MMSYSERR_NOERROR;
}

DWORD NativeMidiGetVolume() { return g_driverVolume; }
void NativeMidiSetVolume(DWORD volume) {
    g_driverVolume = volume;
    Logf("SSYNMIDI32: local MIDI volume=%08lX", static_cast<unsigned long>(volume));
}

void NativeMidiShutdownDriver() {
    // Original helper seg1:245A walks exactly four records and calls seg1:240A,
    // which synchronously sends 0x48B and clears record+08.
    for (unsigned i=0;i<4;++i) {
        unsigned id = 0xffffu;
        bool haveToken = false;
        AcquireSRWLockShared(&g_driverLock);
        const auto& r = g_driverDevices[i];
        if (r.allocated) { id = r.id; haveToken = r.callbackToken != 0; }
        ReleaseSRWLockShared(&g_driverLock);
        if (id != 0xffffu && haveToken) SendLegacyDriverNotification(id, 0x48B);
    }
    AcquireSRWLockExclusive(&g_driverLock);
    for (auto& r : g_driverDevices) r = DriverDeviceRecord{};
    ReleaseSRWLockExclusive(&g_driverLock);
    InterlockedExchange(&g_openDeviceCount,0);
    NativeMidiStopEngine();
    Logf("SSYNMIDI32: driver shutdown complete; four callback records released");
}

DWORD NativeMidiModMessage(UINT deviceId, UINT message, DWORD_PTR user, DWORD_PTR param1, DWORD_PTR param2) {
    (void)user;
    // Numeric messages intentionally mirror the uploaded Win16 modMessage
    // switch at segment 1:06AC: 1..13 plus 0x64..0x67 lifecycle messages.
    switch (message) {
    case 1: // MODM_GETNUMDEVS
        return 1;
    case 2: { // MODM_GETDEVCAPS
        if (!param1 || !param2) return MMSYSERR_INVALPARAM;
        MIDIOUTCAPSA caps{};
        caps.wMid = 0x00FF; caps.wPid = 0x0001; caps.vDriverVersion = 0x00050105;
        std::strncpy(caps.szPname, "Reality", MAXPNAMELEN-1);
        caps.wTechnology = MOD_SYNTH; caps.wVoices = 64; caps.wNotes = 64;
        caps.wChannelMask = 0xFFFF; caps.dwSupport = MIDICAPS_VOLUME;
        const size_t cb = static_cast<size_t>(param2) < sizeof(caps) ? static_cast<size_t>(param2) : sizeof(caps);
        std::memcpy(reinterpret_cast<void*>(param1), &caps, cb);
        return MMSYSERR_NOERROR;
    }
    case 3: // MODM_OPEN
        return NativeMidiOpenDevice(deviceId, 0, 0, 0) ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    case 4: // MODM_CLOSE
        return NativeMidiCloseDevice(deviceId) ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    case 5: // MODM_PREPARE
    case 6: // MODM_UNPREPARE
        return MMSYSERR_NOTSUPPORTED;
    case 7: // MODM_DATA
        return NativeMidiInjectShort(static_cast<DWORD>(param1), timeGetTime()) ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    case 8: { // MODM_LONGDATA
        auto* hdr = reinterpret_cast<MIDIHDR*>(param1);
        if (!hdr || !hdr->lpData) return MMSYSERR_INVALPARAM;
        return NativeMidiHandleLongData(reinterpret_cast<const BYTE*>(hdr->lpData), hdr->dwBufferLength, timeGetTime());
    }
    case 9: // MODM_RESET
        return NativeMidiReset(false) ? MMSYSERR_NOERROR : MMSYSERR_ERROR;
    case 10: // MODM_GETVOLUME
        if (!param1) return MMSYSERR_INVALPARAM;
        *reinterpret_cast<DWORD*>(param1) = NativeMidiGetVolume();
        return MMSYSERR_NOERROR;
    case 11: // MODM_SETVOLUME
        NativeMidiSetVolume(static_cast<DWORD>(param1)); return MMSYSERR_NOERROR;
    case 12: // MODM_CACHEPATCHES -- local cache path not needed by Reality UI rehost
    case 13: // MODM_CACHEDRUMPATCHES
        return MMSYSERR_NOTSUPPORTED;
    case 0x64: case 0x65: case 0x66: case 0x67:
        // Original driver maintains install/enable counters here.  There is no
        // Win16 driver-manager instance in the native rehost, so acknowledge.
        Logf("SSYNMIDI32: driver lifecycle message=%02X acknowledged", message);
        return MMSYSERR_NOERROR;
    default:
        return MMSYSERR_NOTSUPPORTED;
    }
}
