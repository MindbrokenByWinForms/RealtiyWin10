#pragma once
#include <windows.h>

// Compatibility/diagnostic bridge for Reality 1.5's WaveDeviceMgr.
// It exposes the normal WinMM devices and appends one "Windows Default Audio"
// entry which maps to WAVE_MAPPER.  This guarantees that the legacy audio
// choice list has a modern default endpoint even when WinMM returns no
// concrete numbered endpoints on a current Windows installation.
bool PatchRealityAudioWinmm(HMODULE synMid);

// Reality resolves DirectSound dynamically.  HookGetProcAddress calls this
// helper so the compatibility layer can trace the COM calls that actually
// select/open an output device and soften obsolete exclusive-mode requests.
FARPROC WrapRealityDirectSoundProc(LPCSTR name, FARPROC proc);

// Runtime health used by the legacy-dialog compatibility hook.  Reality 1.5's
// DirectSound warning logic predates NT's software mixer and can report that
// the primary buffer failed even after modern dsound.dll has successfully
// created/formatted it.
bool RealityAudioDirectSoundPrimaryHealthy();
bool RealityAudioDirectSoundTransportHealthy();
bool RealityAudioDirectSoundUsingPrimaryFallback();

// v13.4: query the live DirectSound play/write cursors for the buffer region
// currently handed to SSYNENG through IOCTL 0x7002.  The engine resolves this
// export dynamically so SSYNENG.dll does not link against RealityCompat.dll.
extern "C" BOOL WINAPI RealityCompat_QueryDirectSoundPosition(
    LPVOID mappedBase, DWORD mappedBytes, LPDWORD playCursor, LPDWORD writeCursor);
