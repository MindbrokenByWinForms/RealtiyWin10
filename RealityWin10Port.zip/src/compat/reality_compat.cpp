#include <windows.h>
#include <winternl.h>
#include <cstdint>
#include <cstring>
#include <cwchar>
#include <limits>
#include <string>
#include "iathook.h"
#include "log.h"
#include "ssyneng_api.h"
#include "synhigh_patch.h"
#include "seqplay_native.h"
#include "native_midi.h"
#include "midi_winmm.h"
#include "audio_winmm.h"
#include "virtual_registry.h"

static decltype(&CreateFileA) RealCreateFileA = CreateFileA;
static decltype(&DeviceIoControl) RealDeviceIoControl = DeviceIoControl;
static decltype(&CloseHandle) RealCloseHandle = CloseHandle;
static decltype(&GetFileType) RealGetFileType = GetFileType;
static decltype(&VirtualAlloc) RealVirtualAlloc = VirtualAlloc;
static decltype(&LoadLibraryA) RealLoadLibraryA = LoadLibraryA;
static decltype(&GetProcAddress) RealGetProcAddress = GetProcAddress;
static decltype(&GetShortPathNameA) RealGetShortPathNameA = GetShortPathNameA;
static decltype(&MessageBoxA) RealMessageBoxA = MessageBoxA;
static decltype(&MessageBoxW) RealMessageBoxW = MessageBoxW;
static decltype(&EnableWindow) RealEnableWindow = EnableWindow;
static HMODULE g_self = nullptr;
static bool g_patched = false;
static bool g_initialized = false;
static bool g_realityPatched = false;
static std::wstring g_synHighCompatPath;
static PVOID g_cookie = nullptr;
static HMODULE g_pinnedSelf = nullptr;
static volatile LONG g_uiEnableTraceCount = 0;

static HANDLE WINAPI HookCreateFileA(LPCSTR name, DWORD access, DWORD share, LPSECURITY_ATTRIBUTES sa,
                                     DWORD creation, DWORD flags, HANDLE templ);

// SynMid 1.5.5 startup health predicate.  The original method is called from
// the initialization routine near RVA 0x33989 and rejects startup when its two
// Win9x device fields do not look usable.  Stage 32 keeps the original result
// unless both handles are compatibility handles that we created successfully.
using SynMidHealthFn = unsigned char (__thiscall*)(void*);
static SynMidHealthFn RealSynMidHealth = nullptr;

// RZEDUTIL.VXD is a tiny Win9x helper that SynMid opens separately from
// SSYNENG.  Reality's startup health check requires this handle to be valid
// even when the main SSYNENG handle has opened successfully.  On NT there is
// no VxD namespace, so model RZEDUTIL as a small user-mode utility device.
static HANDLE g_rzedHandles[16] = {};
static volatile LONG g_rzedUnlockTraceCount = 0;

static bool IsRzedHandle(HANDLE h) {
    if (!h || h == INVALID_HANDLE_VALUE) return false;
    for (HANDLE x : g_rzedHandles) if (x == h) return true;
    return false;
}
static HANDLE OpenRzedHandle() {
    HANDLE h = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!h) return INVALID_HANDLE_VALUE;
    for (HANDLE& x : g_rzedHandles) {
        if (!x) { x = h; return h; }
    }
    CloseHandle(h);
    SetLastError(ERROR_TOO_MANY_OPEN_FILES);
    return INVALID_HANDLE_VALUE;
}
static bool CloseRzedHandle(HANDLE h) {
    for (HANDLE& x : g_rzedHandles) {
        if (x == h) {
            x = nullptr;
            return RealCloseHandle(h) != FALSE;
        }
    }
    return false;
}
static bool ReadRzedDescriptor(const void* descriptor, DWORD* baseOut, DWORD* bytesOut) {
    if (!descriptor || !baseOut || !bytesOut) return false;
    DWORD base = 0, bytes = 0;
    bool ok = false;
#ifdef _MSC_VER
    __try {
        const DWORD* d = reinterpret_cast<const DWORD*>(descriptor);
        base = d[1];
        bytes = d[3];
        ok = true;
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        ok = false;
    }
#else
    const DWORD* d = reinterpret_cast<const DWORD*>(descriptor);
    base = d[1];
    bytes = d[3];
    ok = true;
#endif
    if (!ok || !base || !bytes) return false;
    *baseOut = base;
    *bytesOut = bytes;
    return true;
}

static DWORD RzedPageCount(DWORD base, DWORD bytes) {
    if (!base || !bytes) return 0;
    const ULONGLONG first = static_cast<ULONGLONG>(base) >> 12;
    const ULONGLONG last = (static_cast<ULONGLONG>(base) + bytes - 1ull) >> 12;
    const ULONGLONG count = last >= first ? (last - first + 1ull) : 0ull;
    return count <= 0xFFFFFFFFull ? static_cast<DWORD>(count) : 0u;
}

// Win9x RZEDUTIL locked pageable sample/resource ranges before the synth touched
// them.  NT does not need a VxD page-lock handle, but touching the pages now and
// optionally VirtualLock'ing them reproduces the important residency guarantee.
// VirtualLock is best-effort: its working-set quota is smaller than Reality's
// possible resident bank, so failure must never make a legacy 1004 fail.
static void WarmRzedRange(DWORD base, DWORD bytes, bool lockPages) {
    if (!base || !bytes) return;
#ifdef _MSC_VER
    __try {
        volatile const BYTE* p = reinterpret_cast<volatile const BYTE*>(static_cast<uintptr_t>(base));
        for (ULONGLONG off = 0; off < bytes; off += 4096ull) (void)p[static_cast<size_t>(off)];
        (void)p[bytes - 1u];
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return;
    }
#else
    volatile const BYTE* p = reinterpret_cast<volatile const BYTE*>(static_cast<uintptr_t>(base));
    for (ULONGLONG off = 0; off < bytes; off += 4096ull) (void)p[static_cast<size_t>(off)];
    (void)p[bytes - 1u];
#endif
    if (lockPages) VirtualLock(reinterpret_cast<LPVOID>(static_cast<uintptr_t>(base)), bytes);
}


static HMODULE g_engineDll = nullptr;
static SSynEng_GetApiVersion_t pGetApiVersion = nullptr;
static SSynEng_Initialize_t pEngineInitialize = nullptr;
static SSynEng_Shutdown_t pEngineShutdown = nullptr;
static SSynEng_OpenDevice_t pOpenDevice = nullptr;
static SSynEng_IsDeviceHandle_t pIsDeviceHandle = nullptr;
static SSynEng_CloseDevice_t pCloseDevice = nullptr;
static SSynEng_DeviceIoControl_t pEngineDio = nullptr;
static SSynEng_GetProgramDatabase_t pGetProgramDatabase = nullptr;

static std::wstring ModuleDir(HMODULE m) {
    wchar_t path[MAX_PATH] = {};
    DWORD n = GetModuleFileNameW(m, path, MAX_PATH);
    if (!n || n >= MAX_PATH) return L".";
    std::wstring s(path, n);
    auto p = s.find_last_of(L"\\/");
    return p == std::wstring::npos ? L"." : s.substr(0, p);
}
static bool EnvEnabled(const wchar_t* name) {
    wchar_t value[16] = {};
    DWORD n = GetEnvironmentVariableW(name, value, 16);
    if (!n || n >= 16) return false;
    return _wcsicmp(value, L"1") == 0 || _wcsicmp(value, L"true") == 0 || _wcsicmp(value, L"yes") == 0;
}

static bool UiProgramDatabaseReady() {
    return pGetProgramDatabase && pGetProgramDatabase() != 0;
}

static void DescribeUiWindow(HWND hwnd, char* cls, size_t clsBytes, char* text, size_t textBytes, int* id) {
    if (cls && clsBytes) { cls[0] = 0; GetClassNameA(hwnd, cls, static_cast<int>(clsBytes)); }
    if (text && textBytes) { text[0] = 0; GetWindowTextA(hwnd, text, static_cast<int>(textBytes)); }
    if (id) *id = GetDlgCtrlID(hwnd);
}

static BOOL WINAPI HookEnableWindow(HWND hwnd, BOOL enable) {
    const bool dbReady = UiProgramDatabaseReady();
    const bool probe = EnvEnabled(L"REALITY_UI_PROBE") || EnvEnabled(L"REALITY_UI_FORCE_ENABLE");
    const bool force = EnvEnabled(L"REALITY_UI_FORCE_ENABLE") && dbReady && !enable && hwnd && IsWindow(hwnd);
    if (probe && hwnd && IsWindow(hwnd)) {
        const BOOL beforeEnabled = IsWindowEnabled(hwnd);
        const LONG trace = InterlockedIncrement(&g_uiEnableTraceCount);
        // v7 logged every redundant UI refresh. During sequence playback Reality
        // can call EnableWindow thousands of times, turning the diagnostic itself
        // into a multi-second stall. Keep transitions/forced calls plus a sparse
        // heartbeat; REALITY_UI_TRACE_VERBOSE=1 restores the old firehose.
        const bool verbose = EnvEnabled(L"REALITY_UI_TRACE_VERBOSE");
        // Forced-disable suppression is intentionally repetitive: Reality can
        // request DisableWindow on the same strip controls tens of thousands
        // of times while they remain force-enabled.  Do not make every one of
        // those calls a synchronous log write; that can contend with the audio
        // render thread.
        const bool interesting = (!force && beforeEnabled != enable) || trace <= 64 ||
                                 (trace > 0 && (trace & (trace - 1)) == 0);
        if (verbose || interesting) {
            char cls[80] = {}, text[128] = {};
            int id = 0; DescribeUiWindow(hwnd, cls, sizeof(cls), text, sizeof(text), &id);
            Logf("UI EnableWindow #%ld hwnd=%p id=%d class=%s text=%s requested=%u before=%u dbReady=%u force=%u",
                 trace, hwnd, id, cls[0] ? cls : "(unknown)", text[0] ? text : "(none)",
                 enable ? 1u : 0u, beforeEnabled ? 1u : 0u, dbReady ? 1u : 0u, force ? 1u : 0u);
        }
    }
    if (force) return RealEnableWindow ? RealEnableWindow(hwnd, TRUE) : TRUE;
    return RealEnableWindow ? RealEnableWindow(hwnd, enable) : FALSE;
}

static void PatchUiState(HMODULE module, const char* moduleName) {
    if (!module) return;
    void* old = nullptr;
    const bool ok = PatchImport(module, "USER32.dll", "EnableWindow", (void*)&HookEnableWindow, &old);
    if (ok && old && old != reinterpret_cast<void*>(&HookEnableWindow))
        RealEnableWindow = reinterpret_cast<decltype(RealEnableWindow)>(old);
    if (ok || EnvEnabled(L"REALITY_UI_PROBE") || EnvEnabled(L"REALITY_UI_FORCE_ENABLE"))
        Logf("UI state patch module=%s EnableWindow=%u base=%p", moduleName ? moduleName : "(unknown)", ok ? 1u : 0u, module);
}

struct UiSweepContext { DWORD pid; bool force; unsigned disabled; unsigned enabled; };
static BOOL CALLBACK UiSweepChild(HWND hwnd, LPARAM lp) {
    auto* ctx = reinterpret_cast<UiSweepContext*>(lp);
    if (!ctx || !IsWindow(hwnd) || !IsWindowVisible(hwnd) || IsWindowEnabled(hwnd)) return TRUE;
    ++ctx->disabled;
    char cls[80] = {}, text[128] = {}; int id = 0;
    DescribeUiWindow(hwnd, cls, sizeof(cls), text, sizeof(text), &id);
    Logf("UI post-DB disabled child hwnd=%p id=%d class=%s text=%s force=%u",
         hwnd, id, cls[0] ? cls : "(unknown)", text[0] ? text : "(none)", ctx->force ? 1u : 0u);
    if (ctx->force && RealEnableWindow) {
        RealEnableWindow(hwnd, TRUE);
        if (IsWindowEnabled(hwnd)) ++ctx->enabled;
    }
    return TRUE;
}
static BOOL CALLBACK UiSweepTop(HWND hwnd, LPARAM lp) {
    auto* ctx = reinterpret_cast<UiSweepContext*>(lp);
    DWORD pid = 0; GetWindowThreadProcessId(hwnd, &pid);
    if (!ctx || pid != ctx->pid || !IsWindowVisible(hwnd)) return TRUE;
    char cls[80] = {}, text[128] = {}; int id = 0;
    DescribeUiWindow(hwnd, cls, sizeof(cls), text, sizeof(text), &id);
    Logf("UI post-DB top hwnd=%p class=%s text=%s enabled=%u",
         hwnd, cls[0] ? cls : "(unknown)", text[0] ? text : "(none)", IsWindowEnabled(hwnd) ? 1u : 0u);
    EnumChildWindows(hwnd, UiSweepChild, lp);
    return TRUE;
}
static DWORD WINAPI UiPostDbProbeThread(void*) {
    // Wait for the reconstructed or genuine database to become visible, then
    // inspect the UI after its normal startup/layout pass.  This is diagnostic
    // by default; REALITY_UI_FORCE_ENABLE=1 turns it into an opt-in brute-force
    // test that enables visible disabled child controls once.
    for (unsigned i = 0; i < 600; ++i) {
        if (UiProgramDatabaseReady()) {
            Sleep(300);
            UiSweepContext ctx{GetCurrentProcessId(), EnvEnabled(L"REALITY_UI_FORCE_ENABLE"), 0, 0};
            EnumWindows(UiSweepTop, reinterpret_cast<LPARAM>(&ctx));
            Logf("UI post-DB sweep complete db=%08lX disabledVisibleChildren=%u force=%u enabled=%u",
                 pGetProgramDatabase ? pGetProgramDatabase() : 0u, ctx.disabled, ctx.force ? 1u : 0u, ctx.enabled);
            return 0;
        }
        Sleep(50);
    }
    Logf("UI post-DB sweep timeout: no program database became visible within 30 seconds");
    return 0;
}

static bool IsSsynPath(LPCSTR p) {
    if (!p) return false;
    return _stricmp(p, "\\\\.\\SSYNENG") == 0 || _stricmp(p, "\\\\.\\SSYNENG.VXD") == 0;
}

static bool IsSeerBanksetPath(LPCSTR p) {
    if (!p || !*p) return false;
    const char* dot = strrchr(p, '.');
    return dot && _stricmp(dot, ".SeerBankset") == 0;
}

static bool IsRzedUtilPath(LPCSTR p) {
    if (!p || !*p) return false;

    // SynMid reaches RZEDUTIL in two forms:
    //   1) as the Win9x device path \\.\RZEDUTIL.VXD
    //   2) as a normal filename/full path while constructing the short name.
    // Match both so GetShortPathNameA and CreateFileA share one predicate.
    if (_stricmp(p, "\\\\.\\RZEDUTIL.VXD") == 0 ||
        _stricmp(p, "\\\\.\\RZEDUTIL") == 0)
        return true;

    const char* base = p;
    for (const char* q = p; *q; ++q)
        if (*q == '\\' || *q == '/') base = q + 1;

    return _stricmp(base, "RZEDUTIL.VXD") == 0 ||
           _stricmp(base, "RZEDUTIL") == 0;
}


static bool IsSynHighName(LPCSTR p) {
    if (!p) return false;
    const char* base = p;
    for (const char* q=p; *q; ++q) if (*q=='\\' || *q=='/') base=q+1;
    return _stricmp(base, "SynHigh.dll") == 0 || _stricmp(base, "SynHigh") == 0;
}

static bool IsSsynTkName(LPCSTR p) {
    if (!p) return false;
    const char* base = p;
    for (const char* q=p; *q; ++q) if (*q=='\\' || *q=='/') base=q+1;
    return _stricmp(base, "SSYNTK32.dll") == 0 || _stricmp(base, "SSYNTK32") == 0;
}

static bool IsSeerCcName(LPCSTR p) {
    if (!p || !*p) return false;
    const char* base = p;
    for (const char* q=p; *q; ++q) if (*q=='\\' || *q=='/') base=q+1;
    return _stricmp(base, "SeerCC.dll") == 0 || _stricmp(base, "SeerCC") == 0;
}

static HMODULE LoadPortableSeerCC(LPCSTR requested, DWORD originalError) {
    // Reality 1.5 does not load SeerCC from beside Reality.exe. Its path
    // helper resolves the Seer root from HKCR\SeerSystems, appends
    // "Shared", appends "SeerCC", then calls LoadLibraryA on that path.
    //
    // The launcher normally lives in build\Release while Reality.exe and its
    // portable Shared directory live in the project/install root. Therefore
    // ModuleDir(g_self) alone is not a valid definition of the portable root.
    // Prefer the directory containing Reality.exe, then also try the directory
    // containing RealityCompat.dll so installed and development layouts work.
    const std::wstring exeRoot = ModuleDir(GetModuleHandleW(nullptr));
    const std::wstring compatRoot = ModuleDir(g_self);

    std::wstring candidates[4] = {
        exeRoot + L"\\Shared\\SeerCC.dll",
        exeRoot + L"\\SeerCC.dll",
        compatRoot + L"\\Shared\\SeerCC.dll",
        compatRoot + L"\\SeerCC.dll"
    };

    DWORD last = originalError;
    for (size_t i = 0; i < 4; ++i) {
        const std::wstring& candidate = candidates[i];

        // Avoid logging/trying the same physical path twice when the launcher
        // and Reality binaries are colocated.
        bool duplicate = false;
        for (size_t j = 0; j < i; ++j) {
            if (_wcsicmp(candidate.c_str(), candidates[j].c_str()) == 0) {
                duplicate = true;
                break;
            }
        }
        if (duplicate) continue;

        DWORD attr = GetFileAttributesW(candidate.c_str());
        if (attr == INVALID_FILE_ATTRIBUTES || (attr & FILE_ATTRIBUTE_DIRECTORY)) {
            Logf("SeerCC portable loader: candidate missing %ls", candidate.c_str());
            continue;
        }

        SetLastError(ERROR_SUCCESS);
        HMODULE h = LoadLibraryW(candidate.c_str());
        DWORD err = h ? ERROR_SUCCESS : GetLastError();
        Logf("SeerCC portable loader: requested=%s originalError=%lu candidate=%ls -> module=%p error=%lu",
             requested ? requested : "(null)", originalError, candidate.c_str(), h, err);
        if (h) return h;
        last = err;
    }

    Logf("SeerCC portable loader: requested=%s originalError=%lu; no loadable SeerCC.dll; exeRoot=%ls compatRoot=%ls",
         requested ? requested : "(null)", originalError, exeRoot.c_str(), compatRoot.c_str());
    SetLastError(last ? last : ERROR_MOD_NOT_FOUND);
    return nullptr;
}

static bool IsDirectSoundProcName(LPCSTR name) {
    if (!name || (reinterpret_cast<ULONG_PTR>(name) >> 16) == 0) return false;
    return _stricmp(name, "DirectSoundEnumerateA") == 0 ||
           _stricmp(name, "DirectSoundCaptureEnumerateA") == 0 ||
           _stricmp(name, "DirectSoundCreate") == 0 ||
           _stricmp(name, "DirectSoundCaptureCreate") == 0;
}

static FARPROC WINAPI HookGetProcAddress(HMODULE module, LPCSTR name) {
    FARPROC p = RealGetProcAddress ? RealGetProcAddress(module, name) : nullptr;
    FARPROC registryWrapped = WrapRealityRegistryProc(name, p);
    if (registryWrapped != p) {
        Logf("VirtualRegistry: dynamic GetProcAddress proc=%s real=%p returned=%p",
             name, p, registryWrapped);
        p = registryWrapped;
    }
    FARPROC midiWrapped = WrapRealityMidiWinmmProc(name, p);
    if (midiWrapped != p) {
        Logf("WinMM MIDI: dynamic GetProcAddress proc=%s real=%p returned=%p", name, p, midiWrapped);
        return midiWrapped;
    }
    if (name && (reinterpret_cast<ULONG_PTR>(name) >> 16) != 0 && _stricmp(name, "EnableWindow") == 0) {
        Logf("UI state: dynamic GetProcAddress EnableWindow real=%p returned=%p", p, reinterpret_cast<void*>(&HookEnableWindow));
        return reinterpret_cast<FARPROC>(&HookEnableWindow);
    }
    if (IsDirectSoundProcName(name)) {
        FARPROC wrapped = WrapRealityDirectSoundProc(name, p);
        char modulePath[MAX_PATH] = {};
        if (module) GetModuleFileNameA(module, modulePath, MAX_PATH);
        Logf("AudioDirectSound: GetProcAddress module=%p path=%s proc=%s real=%p returned=%p",
             module, modulePath[0] ? modulePath : "(unknown)", name, p, wrapped);
        return wrapped;
    }
    return p;
}

static HMODULE WINAPI HookLoadLibraryA(LPCSTR name) {
    if (IsSeerCcName(name)) {
        // Preserve a genuine installed copy when it is available, but log the
        // real loader error and fall back to the portable Shared directory.
        SetLastError(ERROR_SUCCESS);
        HMODULE original = RealLoadLibraryA(name);
        DWORD originalError = original ? ERROR_SUCCESS : GetLastError();
        if (original) {
            Logf("LoadLibraryA(%s) -> SeerCC loaded normally module=%p", name ? name : "(null)", original);
            return original;
        }
        Logf("LoadLibraryA(%s) -> SeerCC normal load failed error=%lu; trying portable locations",
             name ? name : "(null)", originalError);
        return LoadPortableSeerCC(name, originalError);
    }
    if (IsSynHighName(name) && !g_synHighCompatPath.empty()) {
        Logf("LoadLibraryA(%s) -> redirecting to %ls", name ? name : "(null)", g_synHighCompatPath.c_str());
        HMODULE h = LoadLibraryW(g_synHighCompatPath.c_str());
        if (!h) Logf("SynHighNT LoadLibraryW failed error=%lu", GetLastError());
        else {
            Logf("SynHighNT loaded base=%p", h);
            if (!PatchSynHighNativeSeqPlay(h))
                Logf("NativeSeqPlay: SynHigh wrapper patch incomplete; internal MIDI player may remain unavailable");
        }
        return h;
    }
    if (IsSsynTkName(name)) {
        // SynMid can issue this LoadLibrary from its own process-attach path,
        // i.e. while the NT loader lock is already held.  Calling LoadLibraryW
        // recursively here is unsafe.  RealityCompat is pinned during our
        // synchronous initializer, so simply return the existing HMODULE.
        Logf("LoadLibraryA(%s) -> integrated native MIDI bridge module=%p (no recursive LoadLibrary)",
             name ? name : "(null)", g_self);
        return g_self;
    }
    if (name) {
        const char* base = name;
        for (const char* q=name; *q; ++q) if (*q=='\\' || *q=='/') base=q+1;
        if (_stricmp(base, "dsound.dll") == 0) {
            HMODULE h = RealLoadLibraryA(name);
            Logf("LoadLibraryA(%s) -> modern DirectSound module=%p error=%lu", name, h, h ? 0ul : GetLastError());
            return h;
        }
    }
    return RealLoadLibraryA(name);
}

static bool IsLegacyPrimaryBufferWarningA(LPCSTR text) {
    if (!text) return false;
    return std::strstr(text, "not able to open the 'primary' audio buffer") != nullptr ||
           std::strstr(text, "not able to open the \"primary\" audio buffer") != nullptr;
}

static bool IsLegacyPrimaryBufferWarningW(LPCWSTR text) {
    if (!text) return false;
    return std::wcsstr(text, L"not able to open the 'primary' audio buffer") != nullptr ||
           std::wcsstr(text, L"not able to open the \"primary\" audio buffer") != nullptr;
}

static int WINAPI HookMessageBoxA(HWND wnd, LPCSTR text, LPCSTR caption, UINT type) {
    Logf("Reality dialog: caption=%s text=%s type=%08X",
         caption ? caption : "(null)", text ? text : "(null)", type);
    if (IsLegacyPrimaryBufferWarningA(text) && RealityAudioDirectSoundPrimaryHealthy()) {
        Logf("Reality dialog: suppressing stale primary-buffer warning; modern DirectSound primary create+format already succeeded fallback=%u transport=%u",
             RealityAudioDirectSoundUsingPrimaryFallback() ? 1u : 0u,
             RealityAudioDirectSoundTransportHealthy() ? 1u : 0u);
        return IDOK;
    }
    return RealMessageBoxA(wnd, text, caption, type);
}

static int WINAPI HookMessageBoxW(HWND wnd, LPCWSTR text, LPCWSTR caption, UINT type) {
    Logf("Reality dialog: caption=%ls text=%ls type=%08X",
         caption ? caption : L"(null)", text ? text : L"(null)", type);
    if (IsLegacyPrimaryBufferWarningW(text) && RealityAudioDirectSoundPrimaryHealthy()) {
        Logf("Reality dialog: suppressing stale primary-buffer warning; modern DirectSound primary create+format already succeeded fallback=%u transport=%u",
             RealityAudioDirectSoundUsingPrimaryFallback() ? 1u : 0u,
             RealityAudioDirectSoundTransportHealthy() ? 1u : 0u);
        return IDOK;
    }
    return RealMessageBoxW(wnd, text, caption, type);
}

static void PatchLegacyDialogs(HMODULE module, const char* moduleName) {
    if (!module) return;
    void* old = nullptr;
    const bool a = PatchImport(module, "USER32.dll", "MessageBoxA", (void*)&HookMessageBoxA, &old);
    if (a && old && old != reinterpret_cast<void*>(&HookMessageBoxA))
        RealMessageBoxA = reinterpret_cast<decltype(RealMessageBoxA)>(old);
    old = nullptr;
    const bool w = PatchImport(module, "USER32.dll", "MessageBoxW", (void*)&HookMessageBoxW, &old);
    if (w && old && old != reinterpret_cast<void*>(&HookMessageBoxW))
        RealMessageBoxW = reinterpret_cast<decltype(RealMessageBoxW)>(old);
    Logf("Legacy dialog patch module=%s MessageBoxA=%d MessageBoxW=%d base=%p",
         moduleName ? moduleName : "(unknown)", a, w, module);
}

static void PatchRealityLoader() {
    if (g_realityPatched) return;
    HMODULE exe = GetModuleHandleW(nullptr);
    void* old=nullptr;
    bool createFile = PatchImport(exe, "KERNEL32.dll", "CreateFileA", (void*)&HookCreateFileA, &old);
    if (createFile && old) RealCreateFileA = reinterpret_cast<decltype(RealCreateFileA)>(old);
    old = nullptr;
    bool ok=PatchImport(exe, "KERNEL32.dll", "LoadLibraryA", (void*)&HookLoadLibraryA, &old);
    if (ok && old) RealLoadLibraryA=reinterpret_cast<decltype(RealLoadLibraryA)>(old);
    old = nullptr;
    bool msgA = PatchImport(exe, "USER32.dll", "MessageBoxA", (void*)&HookMessageBoxA, &old);
    if (msgA && old) RealMessageBoxA = reinterpret_cast<decltype(RealMessageBoxA)>(old);
    old = nullptr;
    bool msgW = PatchImport(exe, "USER32.dll", "MessageBoxW", (void*)&HookMessageBoxW, &old);
    if (msgW && old) RealMessageBoxW = reinterpret_cast<decltype(RealMessageBoxW)>(old);
    old = nullptr;
    bool getProc = PatchImport(exe, "KERNEL32.dll", "GetProcAddress", (void*)&HookGetProcAddress, &old);
    if (getProc && old) RealGetProcAddress = reinterpret_cast<decltype(RealGetProcAddress)>(old);
    PatchUiState(exe, "Reality.exe");
    PatchRealityVirtualRegistry(exe, "Reality.exe");
    g_realityPatched=ok;
    Logf("Reality.exe IAT patch CreateFileA=%d LoadLibraryA=%d MessageBoxA=%d MessageBoxW=%d GetProcAddress=%d base=%p",
         createFile, ok, msgA, msgW, getProc, exe);
}

static bool IsEngineHandle(HANDLE h) { return pIsDeviceHandle && pIsDeviceHandle(h); }

static HANDLE WINAPI HookCreateFileA(LPCSTR name, DWORD access, DWORD share, LPSECURITY_ATTRIBUTES sa,
                                     DWORD creation, DWORD flags, HANDLE templ) {
    if (IsSsynPath(name)) {
        HANDLE h = pOpenDevice ? pOpenDevice() : INVALID_HANDLE_VALUE;
        Logf("CreateFileA(%s access=%08lX share=%08lX create=%lu flags=%08lX) -> SSYNENG.dll handle=%p",
             name, access, share, creation, flags, h);
        return h;
    }
    if (IsRzedUtilPath(name)) {
        HANDLE h = OpenRzedHandle();
        Logf("CreateFileA(%s access=%08lX share=%08lX create=%lu flags=%08lX) -> native RZEDUTIL handle=%p",
             name ? name : "(null)", access, share, creation, flags, h);
        return h;
    }
    if (IsSeerBanksetPath(name)) {
        SetLastError(ERROR_SUCCESS);
        HANDLE h = RealCreateFileA(name, access, share, sa, creation, flags, templ);
        const DWORD error = (h == INVALID_HANDLE_VALUE) ? GetLastError() : ERROR_SUCCESS;
        Logf("SeerBankset open path=%s access=%08lX create=%lu -> handle=%p error=%lu",
             name, access, creation, h, error);
        SetLastError(error);
        return h;
    }
    return RealCreateFileA(name, access, share, sa, creation, flags, templ);
}
static BOOL WINAPI HookDeviceIoControl(HANDLE h, DWORD code, LPVOID inBuf, DWORD inLen,
                                       LPVOID outBuf, DWORD outLen, LPDWORD br, LPOVERLAPPED ov) {
    if (IsEngineHandle(h)) {
        if (br) *br = 0;
        SetLastError(ERROR_SUCCESS);
        const BOOL ok = pEngineDio ? pEngineDio(h, code, inBuf, inLen, outBuf, outLen, br) : FALSE;
        const DWORD error = ok ? ERROR_SUCCESS : GetLastError();
        Logf("SSYN engine boundary: DeviceIoControl handle=%p code=%08lX in=%p/%lu out=%p/%lu -> ok=%d error=%lu bytesReturned=%lu",
             h, code, inBuf, inLen, outBuf, outLen, ok, error, br ? *br : 0ul);
        SetLastError(error);
        return ok;
    }
    if (IsRzedHandle(h)) {
        // RZEDUTIL.VXD 1.5.5 page-residency bridge.
        //
        // 0x1004 receives the recovered 24-byte descriptor directly even
        // though SynMid declares a four-byte input.  New v13.3 traces finally
        // reveal 0x1005's missing ABI detail: its four-byte input is a POINTER
        // TO that same descriptor.  This extra indirection is why the old
        // unlock decoder produced the RZED handle/stack addresses as fake
        // base/length fields and why the On-Demand lifecycle never matched
        // Win9x.
        if (br) *br = 0;
        if (outBuf && outLen) std::memset(outBuf, 0, outLen);

        if (code == 0x1004) {
            DWORD base = 0, bytes = 0;
            const bool descriptorOk = ReadRzedDescriptor(inBuf, &base, &bytes);
            const DWORD pages = descriptorOk ? RzedPageCount(base, bytes) : 0u;
            if (!descriptorOk || !outBuf || outLen < sizeof(DWORD)) {
                Logf("RZEDUTIL 1004 lock rejected descriptor=%p inLen=%lu out=%p/%lu",
                     inBuf, inLen, outBuf, outLen);
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            }

            // Page-touch is always safe for a validated descriptor and makes
            // On-Demand deterministic. REALITY_RZED_VIRTUALLOCK=1 additionally
            // asks NT to pin the active range while it is in use; this is a
            // best-effort optimization rather than part of the return status.
            const bool doVirtualLock = EnvEnabled(L"REALITY_RZED_VIRTUALLOCK");
            WarmRzedRange(base, bytes, doVirtualLock);
            *reinterpret_cast<DWORD*>(outBuf) = pages;
            if (br) *br = sizeof(DWORD);
            Logf("RZEDUTIL 1004 lock descriptor=%p legacyInLen=%lu base=%08lX bytes=%lu pages=%lu virtualLock=%u -> result=%lu bytesReturned=4",
                 inBuf, inLen, base, bytes, pages, doVirtualLock ? 1u : 0u, pages);
            SetLastError(ERROR_SUCCESS);
            return TRUE;
        }

        if (code == 0x1005) {
            DWORD descriptorAddress = 0;
            bool indirectReadable = false;
#ifdef _MSC_VER
            __try {
                if (inBuf) {
                    descriptorAddress = *reinterpret_cast<const DWORD*>(inBuf);
                    indirectReadable = descriptorAddress != 0;
                }
            } __except(EXCEPTION_EXECUTE_HANDLER) {
                indirectReadable = false;
            }
#else
            if (inBuf) {
                descriptorAddress = *reinterpret_cast<const DWORD*>(inBuf);
                indirectReadable = descriptorAddress != 0;
            }
#endif
            DWORD base = 0, bytes = 0;
            const bool descriptorOk = indirectReadable &&
                ReadRzedDescriptor(reinterpret_cast<const void*>(static_cast<uintptr_t>(descriptorAddress)), &base, &bytes);
            const DWORD pages = descriptorOk ? RzedPageCount(base, bytes) : 0u;
            const bool doVirtualLock = EnvEnabled(L"REALITY_RZED_VIRTUALLOCK");
            BOOL unlocked = FALSE;
            if (descriptorOk && doVirtualLock) {
                // VirtualUnlock only removes NT's working-set pin.  It does not
                // decommit or invalidate the sample memory, matching the useful
                // part of the old VxD's On-Demand semantics.
                unlocked = VirtualUnlock(reinterpret_cast<LPVOID>(static_cast<uintptr_t>(base)), bytes);
            }

            const LONG n = InterlockedIncrement(&g_rzedUnlockTraceCount);
            const bool important = n <= 64 || (n & (n - 1)) == 0;
            if (important) {
                Logf("RZEDUTIL 1005 unlock indirect#%ld in=%p legacyInLen=%lu descriptor=%08lX valid=%u base=%08lX bytes=%lu pages=%lu virtualUnlock=%u error=%lu -> success",
                     n, inBuf, inLen, descriptorAddress, descriptorOk ? 1u : 0u,
                     base, bytes, pages, unlocked ? 1u : 0u,
                     doVirtualLock && descriptorOk && !unlocked ? GetLastError() : ERROR_SUCCESS);
            }
            // Legacy callers use this as a residency hint.  Invalid/stale
            // descriptors at teardown are therefore non-fatal just as the
            // earlier process-local shim was.
            SetLastError(ERROR_SUCCESS);
            return TRUE;
        }

        Logf("RZEDUTIL DeviceIoControl code=%08lX in=%p/%lu out=%p/%lu -> unknown legacy request accepted as no-op",
             code, inBuf, inLen, outBuf, outLen);
        SetLastError(ERROR_SUCCESS);
        return TRUE;
    }
    return RealDeviceIoControl(h, code, inBuf, inLen, outBuf, outLen, br, ov);
}
static BOOL WINAPI HookCloseHandle(HANDLE h) {
    if (IsEngineHandle(h)) {
        Logf("CloseHandle(SSYNENG.dll device handle=%p)", h);
        return pCloseDevice ? pCloseDevice(h) : FALSE;
    }
    if (IsRzedHandle(h)) {
        Logf("CloseHandle(native RZEDUTIL handle=%p)", h);
        return CloseRzedHandle(h) ? TRUE : FALSE;
    }
    return RealCloseHandle(h);
}
static DWORD WINAPI HookGetFileType(HANDLE h) {
    if (IsEngineHandle(h) || IsRzedHandle(h)) { SetLastError(ERROR_SUCCESS); return FILE_TYPE_CHAR; }
    return RealGetFileType(h);
}

static DWORD WINAPI HookGetShortPathNameA(LPCSTR longPath, LPSTR shortPath, DWORD cchBuffer) {
    if (IsRzedUtilPath(longPath)) {
        const char* leaf = "RZEDUTIL.VXD";
        const DWORD need = static_cast<DWORD>(std::strlen(leaf));
        // SynMid asks GetShortPathNameA to append the helper name after a
        // prebuilt "\\.\" prefix.  The file need not physically exist on
        // NT because the following CreateFile is redirected to our user-mode
        // utility handle.
        if (shortPath && cchBuffer) {
            if (need + 1 > cchBuffer) { SetLastError(ERROR_INSUFFICIENT_BUFFER); return need + 1; }
            std::memcpy(shortPath, leaf, need + 1);
        }
        SetLastError(ERROR_SUCCESS);
        Logf("GetShortPathNameA(%s) -> synthetic %s", longPath ? longPath : "(null)", leaf);
        return need;
    }
    return RealGetShortPathNameA(longPath, shortPath, cchBuffer);
}

static unsigned char __fastcall HookSynMidHealth(void* self, void*) {
    unsigned char original = RealSynMidHealth ? RealSynMidHealth(self) : 0;
    HANDLE engine = INVALID_HANDLE_VALUE;
    HANDLE rzed = INVALID_HANDLE_VALUE;
    bool readable = false;
#ifdef _MSC_VER
    __try {
#endif
        if (self) {
            const auto* b = static_cast<const unsigned char*>(self);
            engine = *reinterpret_cast<HANDLE const*>(b + 0x14);
            rzed = *reinterpret_cast<HANDLE const*>(b + 0x18);
            readable = true;
        }
#ifdef _MSC_VER
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        readable = false;
    }
#endif

    const bool engineCompat = readable && IsEngineHandle(engine);
    const bool rzedCompat = readable && IsRzedHandle(rzed);
    Logf("SynMid startup health: this=%p original=%u engine=%p compat=%u rzed=%p compat=%u",
         self, static_cast<unsigned>(original), engine, engineCompat ? 1u : 0u,
         rzed, rzedCompat ? 1u : 0u);

    if (!original && engineCompat && rzedCompat) {
        Logf("SynMid startup health: overriding false -> true; both native compatibility devices are valid");
        SetLastError(ERROR_SUCCESS);
        return 1;
    }
    return original;
}

static bool PatchSynMidStartupHealth(HMODULE module) {
    // Search the small, version-specific predicate window rather than assuming
    // the approximate 0x33989 address is the first byte of the CALL.  Accept a
    // site only when its decoded target is the recovered health method 0x29BA6.
    constexpr DWORD kStartRva = 0x00033960;
    constexpr DWORD kEndRva = 0x000339B0;
    constexpr DWORD kHealthRva = 0x00029BA6;
    auto* base = reinterpret_cast<unsigned char*>(module);

    for (DWORD rva = kStartRva; rva + 5 <= kEndRva; ++rva) {
        auto* p = base + rva;
        if (p[0] != 0xE8) continue;
        std::int32_t rel = 0;
        std::memcpy(&rel, p + 1, sizeof(rel));
        auto* target = p + 5 + rel;
        const DWORD targetRva = static_cast<DWORD>(target - base);
        if (targetRva != kHealthRva) continue;

        auto* hookAddress = reinterpret_cast<unsigned char*>(
            reinterpret_cast<void*>(&HookSynMidHealth));
        const std::intptr_t newDelta = hookAddress - (p + 5);
        if (newDelta < (std::numeric_limits<std::int32_t>::min)() ||
            newDelta > (std::numeric_limits<std::int32_t>::max)()) {
            Logf("SynMid startup health patch: hook out of rel32 range siteRVA=%08lX", rva);
            return false;
        }
        const std::int32_t newRel = static_cast<std::int32_t>(newDelta);
        DWORD oldProtect = 0;
        if (!VirtualProtect(p, 5, PAGE_EXECUTE_READWRITE, &oldProtect)) {
            Logf("SynMid startup health patch: VirtualProtect failed siteRVA=%08lX error=%lu",
                 rva, GetLastError());
            return false;
        }
        std::memcpy(p + 1, &newRel, sizeof(newRel));
        FlushInstructionCache(GetCurrentProcess(), p, 5);
        DWORD ignored = 0;
        VirtualProtect(p, 5, oldProtect, &ignored);
        RealSynMidHealth = reinterpret_cast<SynMidHealthFn>(target);
        Logf("SynMid startup health patch: callSiteRVA=%08lX targetRVA=%08lX hook=%p",
             rva, targetRva, reinterpret_cast<void*>(&HookSynMidHealth));
        return true;
    }

    Logf("SynMid startup health patch: no CALL to target RVA=%08lX in %08lX..%08lX; no override installed",
         kHealthRva, kStartRva, kEndRva);
    return false;
}

// Windows 9x process-shared allocation flag used by SynMid's SharedMemMgr.
static LPVOID WINAPI HookVirtualAlloc(LPVOID addr, SIZE_T size, DWORD allocType, DWORD protect) {
    constexpr DWORD kLegacyWin9xShared = 0x08000000u;
    DWORD translated = allocType;
    if (allocType & kLegacyWin9xShared) {
        translated &= ~kLegacyWin9xShared;
        if (addr == nullptr && (translated & MEM_COMMIT)) translated |= MEM_RESERVE;
        Logf("VirtualAlloc legacy Win9x shared request addr=%p size=%lu type=%08lX -> %08lX protect=%08lX",
             addr, (unsigned long)size, allocType, translated, protect);
    }
    LPVOID p = RealVirtualAlloc(addr, size, translated, protect);
    if ((allocType & kLegacyWin9xShared) || !p) Logf("VirtualAlloc result=%p lastError=%lu", p, GetLastError());
    return p;
}

static void PatchSynMid(HMODULE m) {
    if (!m || g_patched) return;
    PatchRealityVirtualRegistry(m, "SynMid.dll");
    PatchLegacyDialogs(m, "SynMid.dll");
    PatchUiState(m, "SynMid.dll");
    void* old = nullptr;
    bool a = PatchImport(m, "KERNEL32.dll", "CreateFileA", (void*)&HookCreateFileA, &old);
    if (a && old) RealCreateFileA = reinterpret_cast<decltype(RealCreateFileA)>(old);
    old = nullptr;
    bool b = PatchImport(m, "KERNEL32.dll", "DeviceIoControl", (void*)&HookDeviceIoControl, &old);
    if (b && old) RealDeviceIoControl = reinterpret_cast<decltype(RealDeviceIoControl)>(old);
    old = nullptr;
    bool c = PatchImport(m, "KERNEL32.dll", "CloseHandle", (void*)&HookCloseHandle, &old);
    if (c && old) RealCloseHandle = reinterpret_cast<decltype(RealCloseHandle)>(old);
    old = nullptr;
    bool d = PatchImport(m, "KERNEL32.dll", "GetFileType", (void*)&HookGetFileType, &old);
    if (d && old) RealGetFileType = reinterpret_cast<decltype(RealGetFileType)>(old);
    old = nullptr;
    bool e = PatchImport(m, "KERNEL32.dll", "VirtualAlloc", (void*)&HookVirtualAlloc, &old);
    if (e && old) RealVirtualAlloc = reinterpret_cast<decltype(RealVirtualAlloc)>(old);
    old = nullptr;
    bool f = PatchImport(m, "KERNEL32.dll", "LoadLibraryA", (void*)&HookLoadLibraryA, &old);
    if (f && old) RealLoadLibraryA = reinterpret_cast<decltype(RealLoadLibraryA)>(old);
    old = nullptr;
    bool g = PatchImport(m, "KERNEL32.dll", "GetShortPathNameA", (void*)&HookGetShortPathNameA, &old);
    if (g && old) RealGetShortPathNameA = reinterpret_cast<decltype(RealGetShortPathNameA)>(old);
    old = nullptr;
    bool h = PatchImport(m, "KERNEL32.dll", "GetProcAddress", (void*)&HookGetProcAddress, &old);
    if (h && old) RealGetProcAddress = reinterpret_cast<decltype(RealGetProcAddress)>(old);
    g_patched = a && b && e && f;
    Logf("SynMid IAT patch CreateFile=%d DeviceIoControl=%d CloseHandle=%d GetFileType=%d VirtualAlloc=%d LoadLibraryA=%d GetShortPathNameA=%d GetProcAddress=%d base=%p", a,b,c,d,e,f,g,h,m);
    PatchSynMidStartupHealth(m);
    PatchRealityMidiWinmm(m);
    PatchRealityAudioWinmm(m);
}

typedef struct _LDR_DLL_LOADED_NOTIFICATION_DATA_X {
    ULONG Flags; const UNICODE_STRING* FullDllName; const UNICODE_STRING* BaseDllName;
    PVOID DllBase; ULONG SizeOfImage;
} LDR_DLL_LOADED_NOTIFICATION_DATA_X;
typedef union _LDR_DLL_NOTIFICATION_DATA_X { LDR_DLL_LOADED_NOTIFICATION_DATA_X Loaded; } LDR_DLL_NOTIFICATION_DATA_X;
typedef VOID (CALLBACK *PLDR_DLL_NOTIFICATION_FUNCTION_X)(ULONG, const LDR_DLL_NOTIFICATION_DATA_X*, PVOID);
typedef NTSTATUS (NTAPI *LdrRegisterDllNotification_t)(ULONG, PLDR_DLL_NOTIFICATION_FUNCTION_X, PVOID, PVOID*);

static bool BaseNameIsSynMid(const UNICODE_STRING* s) {
    if (!s || !s->Buffer) return false;
    wchar_t tmp[64] = {}; USHORT n = s->Length / sizeof(wchar_t); if (n >= 63) n = 63;
    std::memcpy(tmp, s->Buffer, n*sizeof(wchar_t));
    return _wcsicmp(tmp, L"SynMid.dll") == 0;
}
static bool BaseNameIsLegacySeerModule(const UNICODE_STRING* s) {
    if (!s || !s->Buffer) return false;
    wchar_t tmp[64] = {};
    USHORT n = s->Length / sizeof(wchar_t);
    if (n >= 63) n = 63;
    std::memcpy(tmp, s->Buffer, n * sizeof(wchar_t));
    return _wcsicmp(tmp, L"SynMid.dll") == 0 ||
           _wcsicmp(tmp, L"SeerCC.dll") == 0 ||
           _wcsicmp(tmp, L"SynHigh.dll") == 0 ||
           _wcsicmp(tmp, L"SynHighNT.dll") == 0 ||
           _wcsicmp(tmp, L"SeerResources.dll") == 0;
}
static VOID CALLBACK DllNotify(ULONG reason, const LDR_DLL_NOTIFICATION_DATA_X* data, PVOID) {
    if (reason != 1 || !data) return;
    if (BaseNameIsLegacySeerModule(data->Loaded.BaseDllName)) {
        wchar_t wideName[64] = {};
        USHORT n = data->Loaded.BaseDllName->Length / sizeof(wchar_t);
        if (n >= 63) n = 63;
        std::memcpy(wideName, data->Loaded.BaseDllName->Buffer, n * sizeof(wchar_t));
        char name[128] = {};
        WideCharToMultiByte(CP_ACP, 0, wideName, -1, name, sizeof(name), nullptr, nullptr);
        PatchRealityVirtualRegistry((HMODULE)data->Loaded.DllBase, name);
        PatchLegacyDialogs((HMODULE)data->Loaded.DllBase, name);
        PatchUiState((HMODULE)data->Loaded.DllBase, name);
    }
    if (BaseNameIsSynMid(data->Loaded.BaseDllName)) PatchSynMid((HMODULE)data->Loaded.DllBase);
}

static LONG CALLBACK CompatVeh(EXCEPTION_POINTERS* ep) {
    if (ep && ep->ExceptionRecord) {
        auto* er = ep->ExceptionRecord;
        HMODULE syn = GetModuleHandleA("SynMid.dll");
        ULONG_PTR addr = reinterpret_cast<ULONG_PTR>(er->ExceptionAddress);
        ULONG_PTR synRva = syn ? addr - reinterpret_cast<ULONG_PTR>(syn) : 0;

        MEMORY_BASIC_INFORMATION mbi = {};
        HMODULE owner = nullptr;
        wchar_t ownerPath[MAX_PATH] = {};
        DWORD ownerRva = 0xFFFFFFFFu;
        if (VirtualQuery(er->ExceptionAddress, &mbi, sizeof(mbi)) == sizeof(mbi) && mbi.AllocationBase) {
            owner = reinterpret_cast<HMODULE>(mbi.AllocationBase);
            ownerRva = static_cast<DWORD>(addr - reinterpret_cast<ULONG_PTR>(owner));
            GetModuleFileNameW(owner, ownerPath, MAX_PATH);
        }
#ifdef _M_IX86
        CONTEXT* c = ep->ContextRecord;
        Logf("VEH exception code=%08lX address=%p module=%ls moduleRVA=%08lX SynMidRVA=%08lX flags=%08lX EAX=%08lX EBX=%08lX ECX=%08lX EDX=%08lX ESI=%08lX EDI=%08lX EBP=%08lX ESP=%08lX",
             er->ExceptionCode, er->ExceptionAddress, ownerPath[0] ? ownerPath : L"(unknown)", ownerRva,
             syn ? (DWORD)synRva : 0xFFFFFFFFu, er->ExceptionFlags,
             c->Eax, c->Ebx, c->Ecx, c->Edx, c->Esi, c->Edi, c->Ebp, c->Esp);
#else
        Logf("VEH exception code=%08lX address=%p module=%ls moduleRVA=%08lX SynMidRVA=%p flags=%08lX",
             er->ExceptionCode, er->ExceptionAddress, ownerPath[0] ? ownerPath : L"(unknown)", ownerRva,
             syn ? (void*)synRva : nullptr, er->ExceptionFlags);
#endif
        if (er->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && er->NumberParameters >= 2)
            Logf("  access violation: operation=%llu faultAddress=%p", (unsigned long long)er->ExceptionInformation[0], (void*)er->ExceptionInformation[1]);
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

static FARPROC GetEngineProc(const char* plain, const char* decorated) {
    FARPROC p = GetProcAddress(g_engineDll, plain);
#ifdef _M_IX86
    if (!p && decorated) p = GetProcAddress(g_engineDll, decorated);
#else
    (void)decorated;
#endif
    return p;
}


static bool LoadEngineDll() {
    std::wstring path = ModuleDir(g_self) + L"\\SSYNENG.dll";
    g_engineDll = LoadLibraryW(path.c_str());
    if (!g_engineDll) { Logf("LoadLibrary SSYNENG.dll failed error=%lu path=%ls", GetLastError(), path.c_str()); return false; }
    pGetApiVersion = reinterpret_cast<SSynEng_GetApiVersion_t>(GetEngineProc("SSynEng_GetApiVersion", "_SSynEng_GetApiVersion@0"));
    pEngineInitialize = reinterpret_cast<SSynEng_Initialize_t>(GetEngineProc("SSynEng_Initialize", "_SSynEng_Initialize@8"));
    pEngineShutdown = reinterpret_cast<SSynEng_Shutdown_t>(GetEngineProc("SSynEng_Shutdown", "_SSynEng_Shutdown@0"));
    pOpenDevice = reinterpret_cast<SSynEng_OpenDevice_t>(GetEngineProc("SSynEng_OpenDevice", "_SSynEng_OpenDevice@0"));
    pIsDeviceHandle = reinterpret_cast<SSynEng_IsDeviceHandle_t>(GetEngineProc("SSynEng_IsDeviceHandle", "_SSynEng_IsDeviceHandle@4"));
    pCloseDevice = reinterpret_cast<SSynEng_CloseDevice_t>(GetEngineProc("SSynEng_CloseDevice", "_SSynEng_CloseDevice@4"));
    pEngineDio = reinterpret_cast<SSynEng_DeviceIoControl_t>(GetEngineProc("SSynEng_DeviceIoControl", "_SSynEng_DeviceIoControl@28"));
    pGetProgramDatabase = reinterpret_cast<SSynEng_GetProgramDatabase_t>(GetEngineProc("SSynEng_GetProgramDatabase", "_SSynEng_GetProgramDatabase@0"));
    if (!pGetApiVersion || !pEngineInitialize || !pEngineShutdown || !pOpenDevice ||
        !pIsDeviceHandle || !pCloseDevice || !pEngineDio || !pGetProgramDatabase) {
        Logf("SSYNENG.dll is missing one or more required exports");
        return false;
    }
    DWORD v = pGetApiVersion();
    if (v != SSYNENG_API_VERSION) { Logf("SSYNENG.dll API mismatch got=%08lX want=%08X", v, SSYNENG_API_VERSION); return false; }
    return true;
}

// Called synchronously by the launcher while Reality's primary thread is still suspended.
extern "C" __declspec(dllexport) DWORD WINAPI RealityCompat_Initialize(void*) {
    if (g_initialized) return 0;
    LogInit(g_self);
    Logf("RealityCompat build=CleanRehost-v13.17-midi-input-lifecycle-fix-20260916");
    Logf("RealityCompat synchronous initialize, pid=%lu", GetCurrentProcessId());
    AddVectoredExceptionHandler(1, CompatVeh);

    // Pin this module before SynMid starts.  The legacy code believes the
    // HMODULE returned for SSYNTK32 is separately loadable/freeable; pinning
    // lets HookLoadLibraryA return g_self without ever recursing into the
    // loader from SynMid's DLL initialization path.
    wchar_t selfPath[MAX_PATH] = {};
    if (GetModuleFileNameW(g_self, selfPath, MAX_PATH) &&
        GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_PIN, selfPath, &g_pinnedSelf)) {
        Logf("RealityCompat pinned for integrated SSYNTK32 bridge module=%p", g_pinnedSelf);
    } else {
        Logf("RealityCompat pin failed error=%lu", GetLastError());
    }

    // Make the build directory visible while legacy DLL dependencies are resolved.
    // In particular, SynHighNT.dll imports RTHUNK32.dll from beside RealityCompat.dll.
    const std::wstring compatDir = ModuleDir(g_self);
    if (!SetDllDirectoryW(compatDir.c_str())) Logf("SetDllDirectoryW(%ls) failed error=%lu", compatDir.c_str(), GetLastError());
    else Logf("legacy dependency search directory=%ls", compatDir.c_str());

    // Stage 35 supplies the legacy installer/path values through IAT hooks.
    // Unlike Stages 25-34, this path performs no RegCreate/RegSet/RegDelete and
    // does not need administrator rights or leave per-user registry residue.
    InitializeRealityVirtualRegistry(ModuleDir(nullptr));

    // SynHigh imports the Win9x-only generic-thunk KERNEL32 exports. Create a
    // non-destructive NT copy and redirect Reality's dynamic load to it.
    if (!PrepareSynHighCompat(g_synHighCompatPath))
        Logf("SynHigh compatibility copy could not be prepared; original load may fail on NT");
    PatchRealityLoader();
    // Patch any MIDI entry points imported directly by Reality.exe as well as
    // SynMid's imports.  This catches UI/sequence paths that bypass SynMid's IAT.
    PatchRealityMidiWinmm(GetModuleHandleW(nullptr));

    // CRITICAL: patch SynMid before any expensive engine setup. Stage 4 did the
    // reverse in rehost mode, allowing SynMid's legacy shared-memory constructor
    // to race ahead and leave a 24-byte backing store NULL.
    if (auto m = GetModuleHandleA("SynMid.dll")) PatchSynMid(m);

    auto ntdll = GetModuleHandleW(L"ntdll.dll");
    auto reg = ntdll ? reinterpret_cast<LdrRegisterDllNotification_t>(GetProcAddress(ntdll, "LdrRegisterDllNotification")) : nullptr;
    if (reg) {
        auto st = reg(0, DllNotify, nullptr, &g_cookie);
        Logf("LdrRegisterDllNotification status=%08lX", (DWORD)st);
    }

    if (!LoadEngineDll()) return ERROR_DLL_INIT_FAILED;
    // Stage 37 still selected the non-synthesizing diagnostic stub whenever
    // REALITY_REHOST was absent. That made a normal launcher invocation look
    // healthy until the first 0x7002 synth/audio registration, which the stub
    // correctly rejects. The recovered engine is the product path now; stub
    // mode must be requested explicitly for diagnostics.
    const bool explicitStub = EnvEnabled(L"REALITY_STUB");
    DWORD flags = explicitStub ? 0 : SSYNENG_INIT_REHOST_ORIGINAL;
    Logf("SSYNENG backend selection explicitStub=%u legacyRehostEnv=%u effective=%s",
         explicitStub ? 1u : 0u, EnvEnabled(L"REALITY_REHOST") ? 1u : 0u,
         flags ? "original-engine rehost" : "diagnostic stub");
    if (!pEngineInitialize(ModuleDir(g_self).c_str(), flags)) {
        Logf("SSYNENG.dll initialize failed error=%lu", GetLastError());
        return GetLastError() ? GetLastError() : ERROR_DLL_INIT_FAILED;
    }
    Logf("SSYNENG.dll ready before Reality resume; backend=%s", flags ? "original-engine rehost" : "stub/native shell");
    if (EnvEnabled(L"REALITY_UI_PROBE") || EnvEnabled(L"REALITY_UI_FORCE_ENABLE")) {
        HANDLE thread = CreateThread(nullptr, 0, UiPostDbProbeThread, nullptr, 0, nullptr);
        if (thread) { CloseHandle(thread); Logf("UI post-DB probe thread armed force=%u", EnvEnabled(L"REALITY_UI_FORCE_ENABLE") ? 1u : 0u); }
        else Logf("UI post-DB probe thread creation failed error=%lu", GetLastError());
    }
    g_initialized = true;
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) { g_self = h; DisableThreadLibraryCalls(h); }
    return TRUE;
}
