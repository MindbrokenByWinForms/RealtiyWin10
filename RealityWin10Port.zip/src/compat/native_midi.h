#pragma once
#include <windows.h>
#include <mmsystem.h>

// Native Win32 replacement for SSYNTK32 -> SSYNTK16 -> SSYNMIDI.DRV.
extern "C" WORD WINAPI SeerCtl32(void* sharedBlock);

void NativeMidiCaptureShort(DWORD packedMessage, DWORD timestampMs);
// Low-noise injection path used by the native SMF scheduler.  It feeds the
// same recovered SSYNENG short-message transport without producing one log
// line per MIDI event.
bool NativeMidiInjectShort(DWORD packedMessage, DWORD timestampMs);
DWORD NativeMidiProgramDatabase();
bool NativeMidiStartEngine();
bool NativeMidiStopEngine();
bool NativeMidiReset(bool fullGmGsReset);
void NativeMidiDumpSynthState();


// Native reconstruction of the useful SSYNMIDI.DRV device state machine.
// The uploaded Win16 driver contains four device/callback records and sends
// custom 0x489/0x48A/0x48B window notifications around device lifetime.
bool NativeMidiOpenDevice(unsigned midiId, DWORD_PTR callback, DWORD_PTR instance, DWORD flags);
bool NativeMidiCloseDevice(unsigned midiId);
MMRESULT NativeMidiHandleLongData(const BYTE* data, DWORD bytes, DWORD timestampMs);
DWORD NativeMidiGetVolume();
void NativeMidiSetVolume(DWORD volume);
void NativeMidiShutdownDriver();

// Driver-message style API used by the standalone SSYNMIDI32.dll wrapper.
DWORD NativeMidiModMessage(UINT deviceId, UINT message, DWORD_PTR user, DWORD_PTR param1, DWORD_PTR param2);
