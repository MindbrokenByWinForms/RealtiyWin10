#pragma once
#include <windows.h>
#include <string>

// Read-only, process-local view of the installer registry used by Reality 1.5.
// No values are created, changed, or removed in the Windows registry.
void InitializeRealityVirtualRegistry(const std::wstring& realityRoot);

// Patch one legacy module's imported ANSI registry/profile functions. Missing
// imports are normal because the Seer DLLs each use a different subset.
bool PatchRealityVirtualRegistry(HMODULE module, const char* moduleName);

// Also covers legacy DLLs that resolve Advapi32 entry points dynamically.
FARPROC WrapRealityRegistryProc(LPCSTR name, FARPROC proc);
