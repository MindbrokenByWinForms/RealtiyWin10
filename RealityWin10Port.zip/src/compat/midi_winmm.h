#pragma once
#include <windows.h>

// Adds the process-local synthetic "Reality" MIDI output and also intercepts
// Reality's callback-less MIDI input open so incoming short messages can be
// observed in user mode. Synthetic midiOutShortMsg/reset calls are sent into
// the recovered SSYNENG raw MIDI ring. This replaces the routing and output
// jobs once performed by midiConnect -> SSYNMIDI.DRV.
bool PatchRealityMidiWinmm(HMODULE module);

// Wrap dynamically resolved WINMM MIDI entry points as well as IAT imports.
FARPROC WrapRealityMidiWinmmProc(const char* name, FARPROC realProc);
