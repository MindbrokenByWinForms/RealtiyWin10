#include "synhigh_patch.h"
#include "log.h"
#include <vector>
#include <string>
#include <algorithm>
#include <cstdint>
#include <cstdio>

static std::wstring ExeDir() {
    wchar_t path[MAX_PATH] = {};
    DWORD n = GetModuleFileNameW(nullptr, path, MAX_PATH);
    if (!n || n >= MAX_PATH) return L".";
    std::wstring s(path, n);
    auto p = s.find_last_of(L"\\/");
    return p == std::wstring::npos ? L"." : s.substr(0, p);
}

static bool ReadWhole(const std::wstring& path, std::vector<unsigned char>& b) {
    FILE* f = _wfopen(path.c_str(), L"rb");
    if (!f) return false;
    _fseeki64(f, 0, SEEK_END); auto n = _ftelli64(f); _fseeki64(f, 0, SEEK_SET);
    if (n <= 0 || n > 64ll*1024*1024) { fclose(f); return false; }
    b.resize((size_t)n);
    bool ok = fread(b.data(), 1, b.size(), f) == b.size();
    fclose(f); return ok;
}
static bool WriteWhole(const std::wstring& path, const std::vector<unsigned char>& b) {
    FILE* f = _wfopen(path.c_str(), L"wb");
    if (!f) return false;
    bool ok = fwrite(b.data(), 1, b.size(), f) == b.size();
    fclose(f); return ok;
}

struct SectionView { DWORD va, span, raw, rawSize; };
static bool RvaToOff(DWORD rva, const std::vector<SectionView>& secs, DWORD& off) {
    for (const auto& s : secs) {
        DWORD span = std::max(s.span, s.rawSize);
        if (rva >= s.va && rva < s.va + span) {
            DWORD d = rva - s.va;
            if (d >= s.rawSize) return false;
            off = s.raw + d; return true;
        }
    }
    return false;
}
static bool CStringEq(const std::vector<unsigned char>& b, DWORD off, const char* s) {
    size_t n = strlen(s);
    return off + n < b.size() && memcmp(b.data()+off, s, n+1) == 0;
}

bool PrepareSynHighCompat(std::wstring& outPatchedPath) {
    const std::wstring shared = ExeDir() + L"\\Shared";
    const std::wstring src = shared + L"\\SynHigh.dll";
    const std::wstring dst = shared + L"\\SynHighNT.dll";
    std::vector<unsigned char> b;
    if (!ReadWhole(src, b)) {
        Logf("SynHigh compat: unable to read %ls error=%lu", src.c_str(), GetLastError());
        return false;
    }
    if (b.size() < sizeof(IMAGE_DOS_HEADER)) return false;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(b.data());
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 ||
        (size_t)dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32) > b.size()) return false;
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS32*>(b.data() + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) return false;
    std::vector<SectionView> secs;
    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (unsigned i=0;i<nt->FileHeader.NumberOfSections;i++)
        secs.push_back({sec[i].VirtualAddress, sec[i].Misc.VirtualSize, sec[i].PointerToRawData, sec[i].SizeOfRawData});
    auto id = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    DWORD impOff=0;
    if (!id.VirtualAddress || !RvaToOff(id.VirtualAddress, secs, impOff)) return false;

    int redirected = 0;
    for (DWORD cur=impOff; cur + sizeof(IMAGE_IMPORT_DESCRIPTOR) <= b.size(); cur += sizeof(IMAGE_IMPORT_DESCRIPTOR)) {
        auto* d = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(b.data()+cur);
        if (!d->Name) break;
        DWORD nameOff=0;
        if (!RvaToOff(d->Name, secs, nameOff)) continue;
        if (!CStringEq(b, nameOff, "KERNEL32.dll")) continue;
        DWORD thunkRva = d->OriginalFirstThunk ? d->OriginalFirstThunk : d->FirstThunk;
        DWORD thunkOff=0; if (!RvaToOff(thunkRva, secs, thunkOff)) continue;
        bool hasWin9xThunk=false;
        for (DWORD t=thunkOff; t+4<=b.size(); t+=4) {
            DWORD v=*reinterpret_cast<DWORD*>(b.data()+t); if (!v) break;
            if (v & IMAGE_ORDINAL_FLAG32) continue;
            DWORD nOff=0; if (!RvaToOff(v, secs, nOff) || nOff+3>b.size()) continue;
            const char* nm=reinterpret_cast<const char*>(b.data()+nOff+2);
            if (!strcmp(nm,"ThunkConnect32") || !strcmp(nm,"MapSL") || !strcmp(nm,"SMapLS_IP_EBP_8") || !strcmp(nm,"SUnMapLS_IP_EBP_8")) {
                hasWin9xThunk=true; break;
            }
        }
        if (hasWin9xThunk) {
            static_assert(sizeof("RTHUNK32.dll") == sizeof("KERNEL32.dll"), "import names must be same size");
            memcpy(b.data()+nameOff, "RTHUNK32.dll", sizeof("RTHUNK32.dll"));
            redirected++;
        }
    }

    // SynHigh 1.5 calls the thunk-compiler connector at RVA 0x1E994 from
    // DllMain.  Do NOT patch the connector itself: its original absolute
    // immediates have PE base-relocation entries, so Windows would relocate
    // bytes inside any replacement instructions when SynHighNT is loaded away
    // from 0x10000000.  Instead bypass the call site at RVA 0x1DE4.  The six
    // bytes there are `push eax ; call rel32`, which have no absolute PE
    // relocation.  The generated adapter ultimately returns with `ret 24`; the caller has
    // already staged four arguments before entering the adapter.  Our bypass
    // removes the final `push eax`, so it must explicitly discard the three
    // earlier pushes (12 bytes) before reporting success.  Stage 11 failed to
    // do that and corrupted DllMain's return stack.
    int thunkCallerBypassed = 0;
    {
        DWORD off = 0;
        static const unsigned char expected[] = {
            0x50,                         // push eax
            0xE8, 0xAA, 0xCB, 0x01, 0x00 // call 0x1E994
        };
        // IMPORTANT: the four arguments already staged for the thunk call are:
        //   module16 (push eax at 0x1DE4), module32, hModule32, dwReason.
        // The generated adapter at 0x1E994 adds TD + thunkfun16 and then tail-
        // jumps to six-argument __stdcall ThunkConnect32, whose RET 24 removes
        // all six arguments.  Because this replacement removes the `push eax`
        // as well as the adapter call, three earlier caller arguments remain on
        // the stack.  Remove those 12 bytes before reporting success.
        //
        //   add esp,0x0c   ; discard module32, hModule32, dwReason
        //   xor eax,eax
        //   inc eax        ; TRUE
        //
        // Exactly six bytes, the same size as `push eax ; call rel32`.
        static const unsigned char replacement[] = {
            0x83, 0xC4, 0x0C, // add esp,0x0c
            0x33, 0xC0,       // xor eax,eax
            0x40              // inc eax
        };
        if (RvaToOff(0x00001DE4, secs, off) &&
            off + sizeof(expected) <= b.size() &&
            memcmp(b.data() + off, expected, sizeof(expected)) == 0) {
            memcpy(b.data() + off, replacement, sizeof(replacement));
            thunkCallerBypassed = 1;
        } else {
            Logf("SynHigh compat: thunk caller signature not found; relying on RTHUNK32 ABI");
        }
    }

    // Keep the original SeqPlay.dll string intact.  The Stage 11 assumption
    // that changing this filename would make SynHigh skip thunk setup was
    // wrong: RVA 0x194A0 is a pathname/string builder, not a file-existence
    // test.  The thunk path is disabled solely by the ABI-correct call-site
    // bypass above.
    int seqPatched = 0;
    if (!redirected) {
        Logf("SynHigh compat: no Win9x thunk import descriptor found; refusing to create misleading copy");
        return false;
    }
    if (!WriteWhole(dst,b)) {
        Logf("SynHigh compat: unable to write %ls error=%lu", dst.c_str(), GetLastError());
        return false;
    }
    Logf("SynHigh compat: created %ls; redirected KERNEL32 thunk descriptors=%d SeqPlay references modified=%d thunkCallerBypass=%d", dst.c_str(), redirected, seqPatched, thunkCallerBypassed);
    outPatchedPath=dst;
    return true;
}
