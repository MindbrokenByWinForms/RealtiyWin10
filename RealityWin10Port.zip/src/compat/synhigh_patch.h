#pragma once
#include <windows.h>
#include <string>

// Create a WinNT-loadable copy of Shared\\SynHigh.dll without modifying the
// user's original. The copy redirects only the legacy Win9x KERNEL32 thunk
// import descriptors to RTHUNK32.dll and disables the obsolete SeqPlay.dll
// (16-bit) thunk path.
bool PrepareSynHighCompat(std::wstring& outPatchedPath);
