#pragma once
#include <windows.h>

// Replaces SynHigh.dll's three tiny Win95 generic-thunk wrappers for the
// 16-bit SeqPlay.dll with native 32-bit implementations.  This prevents the
// old QT_Thunk placeholder (0xCC-filled on NT) from being executed.
bool PatchSynHighNativeSeqPlay(HMODULE synHigh);
