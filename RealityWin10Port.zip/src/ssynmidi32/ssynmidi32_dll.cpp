#include <windows.h>
#include <mmsystem.h>
#include "native_midi.h"
#include "log.h"

// Native 32-bit façade for the recovered SSYNMIDI.DRV interface.  Reality's
// integrated compatibility path uses the same core directly; this DLL is also
// built so the recovered driver entry points can be inspected/tested separately.

extern "C" DWORD WINAPI MODMESSAGE(UINT deviceId, UINT message, DWORD_PTR user,
                                    DWORD_PTR param1, DWORD_PTR param2) {
    return NativeMidiModMessage(deviceId, message, user, param1, param2);
}

extern "C" DWORD WINAPI WODMESSAGE(UINT deviceId, UINT message, DWORD_PTR user,
                                    DWORD_PTR param1, DWORD_PTR param2) {
    (void)deviceId; (void)message; (void)user; (void)param1; (void)param2;
    Logf("SSYNMIDI32: WODMESSAGE called; original export retained but wave-output transport is hosted by SynMid/RealityCompat");
    return MMSYSERR_NOTSUPPORTED;
}

extern "C" LRESULT WINAPI SsynMidiDriverProc(DWORD_PTR driverId, DWORD_PTR driverHandle,
                                      UINT message, LPARAM param1, LPARAM param2) {
    (void)driverId; (void)driverHandle; (void)param1; (void)param2;
    // The original DriverProc's 0x64..0x67 bookkeeping is represented by the
    // reconstructed modMessage lifecycle.  Normal load/enable/disable/free
    // notifications are acknowledged here for a native DLL host.
    Logf("SSYNMIDI32: DRIVERPROC message=%u", message);
    return 1;
}

extern "C" DWORD WINAPI CONFIGTIMERPROC(DWORD_PTR a, DWORD_PTR b, DWORD_PTR c,
                                         DWORD_PTR d, DWORD_PTR e) {
    (void)a; (void)b; (void)c; (void)d; (void)e;
    // Uploaded export seg2:0EC0 is a no-op returning with five Win16 words.
    return 0;
}

extern "C" DWORD WINAPI TIMEFUNC() {
    // SSYNMIDI's event producer timestamps each 8-byte ring record from the
    // multimedia timer path.  timeGetTime is the Win32 equivalent used by the
    // rehost and shares the 1-ms period requested while the engine is open.
    return timeGetTime();
}

extern "C" int WINAPI WEP(int) {
    NativeMidiShutdownDriver();
    return 1;
}

extern "C" DWORD WINAPI ExportedStub() { return 0; }

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        Logf("SSYNMIDI32: native rewrite loaded");
    }
    return TRUE;
}
